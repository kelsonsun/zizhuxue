// 零依赖静态服务器（本地试用 / 测试用）。用法：node server.js [端口]
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path'; import zlib from 'node:zlib';
const root = path.resolve(import.meta.dirname, 'public');
const port = +process.argv[2] || +process.env.PORT || 8080;
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.wasm': 'application/wasm', '.tsv': 'text/tab-separated-values; charset=utf-8', '.gz': 'application/octet-stream', '.txt': 'text/plain' };
const COMPRESS = new Set(['.html', '.js', '.css', '.json', '.webmanifest', '.tsv', '.svg']);
/** base：模拟 GitHub Pages 子路径部署（如 '/zizhuxue'），只服务该前缀下的文件 */
export function createServer({ base = '', override = null } = {}) {
  return http.createServer((req, res) => {
    let p = decodeURIComponent(new URL(req.url, 'http://x').pathname);
    if (base) { if (p === base) { res.writeHead(301, { Location: base + '/' }).end(); return; } if (!p.startsWith(base + '/')) { res.writeHead(404).end('Not found'); return; } p = p.slice(base.length); }
    if (p.endsWith('/')) p += 'index.html';
    const ov = override?.(p); if (ov != null) { res.writeHead(200, { 'Content-Type': MIME[path.extname(p)] || 'text/plain', 'Cache-Control': 'no-cache' }).end(ov); return; } // 测试用：模拟发布新版本
    const f = path.join(root, path.normalize(p));
    if (!f.startsWith(root)) { res.writeHead(403).end(); return; }
    fs.stat(f, (err, st) => {
      if (err || !st.isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }).end('Not found'); return; }
      const ext = path.extname(f); const h = { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': f.endsWith('sw.js') || f.endsWith('precache.json') || f.endsWith('index.html') ? 'no-cache' : 'public, max-age=3600', 'X-Content-Type-Options': 'nosniff' };
      const gz = COMPRESS.has(ext) && /\bgzip\b/.test(req.headers['accept-encoding'] || '');
      if (gz) { h['Content-Encoding'] = 'gzip'; h['Vary'] = 'Accept-Encoding'; res.writeHead(200, h); fs.createReadStream(f).pipe(zlib.createGzip()).pipe(res); }
      else { h['Content-Length'] = st.size; res.writeHead(200, h); fs.createReadStream(f).pipe(res); }
    });
  });
}
if (process.argv[1] === import.meta.filename) createServer().listen(port, '0.0.0.0', () => console.log('自主学 服务已启动： http://localhost:' + port));
