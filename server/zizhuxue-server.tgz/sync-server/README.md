# 自主学 同步服务器（v1.9.2）

零依赖（Node 22.5+ 自带 `node:sqlite`），一个 SQLite 文件存全部数据。现在是**原型**：已在本机测试，**还没有部署到真实服务器、没有域名/HTTPS、没有接真实邮件服务**。以后换成正式服务器时只改配置（`.env`），不改代码。

## 启动
```
node sync-server/server.js            # 读 sync-server/.env（没有就全用默认值），默认 http://localhost:8787/
docker compose -f sync-server/docker-compose.yml up -d   # 或用 Docker（先 cp sync-server/.env.example sync-server/.env）
```
- 接口：`/api/v1/*`；健康检查：`/healthz`（数据库可读才返回 200，Docker HEALTHCHECK 用它）、`/api/v1/health`（应用识别用）。
- 同端口也提供网页（`SERVE_APP=1`），这时网页的 `js/deploy.js` 会自动变成“同步可用 + PUBLIC_URL”。

## 换成正式服务器要做的事（都是配置）
1. 准备一台云服务器 + 域名，用 Caddy/Nginx 反向代理提供 HTTPS，`TRUST_PROXY=1`。
2. `.env`：`PUBLIC_URL=https://sync.你的域名`，`ALLOWED_ORIGINS=https://kelsonsun.github.io`（以及其他网页地址）。
3. 邮件：`MAIL_PROVIDER=smtp`（填 SMTP_*）或 `MAIL_PROVIDER=http`（填 MAIL_API_URL / MAIL_API_KEY）。
4. 网页版（GitHub Pages）：把 `public/js/deploy.js` 改成 `SYNC_AVAILABLE = true`、`SYNC_URL = 'https://sync.你的域名/api/v1/'`，重新发布；安卓/电脑客户端重新打包即可默认用它。

## 数据库迁移
`migrations.js` 用 `PRAGMA user_version` 记录版本，启动时自动按顺序执行未执行的步骤（事务内，失败回滚并报错）。加字段只在末尾追加新步骤。v1.2 原型的旧库会自动升级（已测试：账户、令牌、数据不丢）。

## 备份与恢复
- 在线备份（运行中可执行，不锁库）：`node sync-server/backup.js` → `data/backups/zizhuxue-日期.db`，自动只保留最近 `BACKUP_KEEP`（默认 14）份，并做完整性校验。
- Docker：`docker compose --profile backup up -d` 每天备份一次。
- **建议再把 backups 目录同步到另一个地方**（对象存储/另一台机器），同一台机器上的备份防不了硬盘坏。
- 恢复：停服务 → 用备份文件替换 `zizhuxue.db`（并删掉同目录的 `-wal`、`-shm` 文件）→ 启动。

## 安全要点
- 验证码 6 位、10 分钟有效、错 5 次作废；同一邮箱每小时 5 次、同一 IP 每小时 20 次、两次至少隔 30 秒。
- 配对码 8 位、10 分钟、一次性；同一 IP 每 10 分钟最多试 20 次。
- 访问令牌 1 小时；刷新令牌 365 天、每次续期轮换；旧刷新令牌有 120 秒宽限（防网络中断掉线），过后再用视为盗用并吊销该设备全部令牌。
- 令牌和验证码只存哈希。限流在内存里，只适合单实例；多实例部署需换共享存储（接口在 `ratelimit.js`）。

## 用户反馈接口（v1.6，已写好，未部署）
- `POST /api/v1/feedback`：`{type: bug|idea|other, text, contact?, page?, trail?, env?, screenshot?: "data:image/jpeg;base64,..."}` → `{ok, id}`。不需要登录（绑定过同步的设备会顺带记账户），每个 IP 每小时 10 条（`RATE_FEEDBACK_PER_IP`），截图 ≤1.5MB，同一编号重发不会重复入库。
- `GET /api/v1/feedback`（需 `Authorization: Bearer $FEEDBACK_ADMIN_TOKEN`）：最近 50 条；`?id=编号` 看单条和截图。没设口令时这个接口一律 401。
- 设了 `FEEDBACK_EMAIL` 且邮件服务可用（smtp/http）时，每条新反馈会发一封提醒邮件；网页里「用邮件发送」的收件人也用它（自托管时自动写进 `js/deploy.js`）。
- 数据库结构版本 3 新增 `feedback` 表，启动时自动迁移。

## 匿名使用统计 + 管理看板（v1.9.2，已写好，未部署）
想知道“有多少人在用、多少人真的在学、从哪儿来”——不用第三方统计，数据只在你自己的服务器上。

**收什么**：每台设备一个随机匿名编号（服务器只存加盐哈希，不存 IP）、事件类型（打开 / 导入 / 学课文 / 测验 / 复习 / 生成分享卡片）、来源类型（微信、QQ、微博、直接打开、主屏应用、安卓 / 电脑客户端、其他网站的**纯域名**）、平台、App 版本、时间。**不收**：学习内容、材料标题、姓名、邮箱、账号（和同步账号用的不是同一个编号，连不起来）。用户可在「我的 → 隐私」关掉。

**接口**
- `POST /api/v1/telemetry`：不用登录。`{d: 设备编号, v: 版本, src: 来源, ref?: 域名, p: 平台, e: [{e: 事件, t: 毫秒时间}]}`，一次最多 20 条、请求体 ≤6KB；同一 IP 每 10 分钟 120 次、同一设备每小时 60 次（`RATE_TELEMETRY_*`）。未知事件静默丢弃。App 端用 `sendBeacon` / `fetch keepalive` 发，失败不提示、不影响使用。
- `GET /api/v1/admin/stats`：需要 `ADMIN_TOKEN`（`Authorization: Bearer 口令` 或 `?token=口令`）。返回累计设备、今天 / 昨天 / 7 天 / 30 天打开人数、导入过的人、真正学习过的人（学课文 / 复习 / 测验）、转化漏斗、30 天每日表（打开、学习、导入、新设备）、来源分布（按每台设备第一次的来源）、来源网站域名、平台、版本、反馈列表、授权和同步概况。口令错同一 IP 10 分钟最多 20 次。
- `GET /admin/stats`：中文管理看板（手机、电脑都能看）。第一次输入口令，浏览器记住；右上角「刷新」「退出」。也可以直接打开 `https://你的服务器/admin/stats?token=口令`，口令会存下并从地址栏去掉。页面不被搜索引擎收录、不允许被嵌入、不缓存。
- 没设 `ADMIN_TOKEN` 时，看板和统计接口都返回 404（上报照常收，设好口令后就能看到历史）。

**口径**：“打开” = 这台设备当天打开过；“真正学习” = 当天学过课文 / 复习 / 测验。“人”其实是“设备 + 浏览器”：同一个人换手机、换浏览器、清浏览器数据，都会算成新的一台。“今天”按 `STATS_TZ_OFFSET_MIN`（默认北京时间）切分。数据库结构版本 7 新增 `telemetry`、`telemetry_devices` 两张表，启动时自动迁移。

## 一键部署（Docker）+ HTTPS
1. 云服务器装好 Docker，把仓库放上去：
   ```
   cd english_app/sync-server
   cp .env.example .env
   # 至少改：PUBLIC_URL、ALLOWED_ORIGINS、TRUST_PROXY=1、ADMIN_TOKEN（长随机串）
   docker compose up -d                     # 构建并启动，数据在 sync-server/data
   docker compose --profile backup up -d    # 可选：每天自动备份
   curl http://127.0.0.1:8787/healthz       # 返回 ok 就是起来了
   ```
2. 域名解析到服务器，用 Caddy 自动申请 HTTPS 证书（最省事）。`/etc/caddy/Caddyfile`：
   ```
   sync.你的域名 {
     reverse_proxy 127.0.0.1:8787
   }
   ```
   或 Nginx（证书用 certbot 申请）：
   ```
   server {
     listen 443 ssl http2; server_name sync.你的域名;
     ssl_certificate     /etc/letsencrypt/live/sync.你的域名/fullchain.pem;
     ssl_certificate_key /etc/letsencrypt/live/sync.你的域名/privkey.pem;
     client_max_body_size 60m;
     location / {
       proxy_pass http://127.0.0.1:8787;
       proxy_set_header Host $host;
       proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
       proxy_set_header X-Forwarded-Proto $scheme;
     }
   }
   ```
   在代理后面一定设 `TRUST_PROXY=1`，否则所有人都算同一个 IP，限流会误伤。防火墙只放 80/443，8787 不要对公网开放（可把 docker-compose 的端口写成 `127.0.0.1:8787:8787`）。
3. 打开管理看板：`https://sync.你的域名/admin/stats`，输入 `ADMIN_TOKEN`。
4. GitHub Pages 上的网页版：`public/js/deploy.js` 已单独配置 `TELEMETRY_URL` / `FEEDBACK_URL = https://zizhuxue.com/api/v1/…`（v1.9.2），和云同步开关 `SYNC_AVAILABLE`（仍是 false）分开，发布后就开始上报、反馈直接存进服务器。统计和提交反馈不受 `ALLOWED_ORIGINS` 限制。本机 / 局域网地址打开的网页和自动化测试浏览器默认不往公网报（`public/js/endpoint.js`）。
5. 用服务器自带的网页（`SERVE_APP=1`，直接访问 `https://sync.你的域名/`）时不用改任何东西，自动上报到本服务器。

## zizhuxue.com 正式上线（v1.9.2：单台 1 核 1G Ubuntu 24.04，不用 Docker）
文件在 `sync-server/deploy/`：`install.sh`（一键部署 / 升级）、`Caddyfile`（自动 HTTPS，www 跳转）、`zizhuxue.service`（systemd）。代码包用 `bash tools/pack_server.sh` 打到 `dist/server/`。
1. Cloudflare DNS：`zizhuxue.com`、`www.zizhuxue.com` 两条 A 记录 → 服务器 IP，**仅 DNS（灰色云朵）**。
2. 把 `dist/server/` 里的 `zizhuxue-server.tgz`、`zizhuxue-server.tgz.sha256`、`install.sh` 传到 GitHub Pages 的 `server/` 目录。
3. DigitalOcean 网页控制台（Droplet → Access → Launch Droplet Console）里执行：`curl -fsSL https://kelsonsun.github.io/zizhuxue/server/install.sh | bash`。最后会打印看板地址和管理口令。
   （不想放到公开网页：`scp dist/server/zizhuxue-server.tgz sync-server/deploy/install.sh root@IP:` 后执行 `bash install.sh /root/zizhuxue-server.tgz`。）
4. 用原生 Node.js 22 + systemd + Caddy（比 Docker 省内存）；1GB swap；UFW 只开 22/80/443；服务只监听 127.0.0.1:8787；数据库 `/var/lib/zizhuxue/zizhuxue.db`，每天 3 点备份到 `/var/lib/zizhuxue/backups`（留 14 份）；配置 `/etc/zizhuxue/zizhuxue.env`（`WEB_SYNC=0`：SMTP 配好之前网页不开云同步）。
5. 升级：重新打包、上传，再执行同一条命令（数据和口令保留，保留最近 3 个版本：`/opt/zizhuxue/releases`，回滚 = 把 `/opt/zizhuxue/current` 指回旧版本后 `systemctl restart zizhuxue`）。
