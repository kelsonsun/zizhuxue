// 同步服务器配置：全部来自环境变量（或 .env 文件），换成正式服务器时只改配置，不改代码。
// 每一项的含义和默认值见 .env.example。
import path from 'node:path'; import fs from 'node:fs';

const bool = v => /^(1|true|yes|on)$/i.test(String(v ?? '').trim());
const num = (v, d) => { const n = Number(v); return Number.isFinite(n) && String(v).trim() !== '' ? n : d; };
const list = v => String(v ?? '').split(',').map(s => s.trim()).filter(Boolean);

/** 读 .env（只填环境里还没有的变量；不支持多行值，够用即可） */
export function loadDotEnv(file, env = process.env) {
  if (!file || !fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/.exec(line); if (!m || line.trim().startsWith('#')) continue;
    let v = m[2]; if (/^(['"]).*\1$/.test(v)) v = v.slice(1, -1);
    if (env[m[1]] === undefined) env[m[1]] = v;
  }
}

export function loadConfig(env = process.env) {
  const publicUrl = String(env.PUBLIC_URL || '').trim().replace(/\/+$/, '');
  const cfg = {
    host: env.HOST || '0.0.0.0',
    port: num(env.PORT, 8787),
    dbFile: env.DB_FILE || path.join(import.meta.dirname, 'data/zizhuxue.db'),
    publicUrl,                                              // 对外地址，如 https://sync.example.com（用于邮件、/health、网页默认同步地址）
    allowedOrigins: list(env.ALLOWED_ORIGINS || '*'),       // 允许跨域访问接口的网页来源，逗号分隔；* = 全部（原型默认）
    serveApp: env.SERVE_APP === undefined ? true : bool(env.SERVE_APP), // 同端口提供网页（自托管一体）；只做接口时设 0
    webSync: env.WEB_SYNC === undefined ? true : bool(env.WEB_SYNC), // v1.9.2 同端口网页里打不打开「云同步」（要邮件验证码；SMTP 没配好时设 0）。统计和反馈不受影响
    trustProxy: bool(env.TRUST_PROXY),                      // 在 Nginx/Caddy 等反向代理后面时设 1，按 X-Forwarded-For 识别客户端 IP（限流用）
    accessTtl: num(env.ACCESS_TTL, 3600),                   // 访问令牌有效期（秒）
    refreshTtl: num(env.REFRESH_TTL, 365 * 86400),          // 刷新令牌有效期（秒，每次续期顺延）
    refreshGrace: num(env.REFRESH_GRACE, 120),              // 刷新令牌轮换后，旧令牌还能再用的宽限期（秒）：手机网络断在半路、没收到新令牌时不至于掉线
    codeTtl: num(env.CODE_TTL, 600),                        // 邮箱验证码有效期（秒）
    maxBodyMb: num(env.MAX_BODY_MB, 50),
    pageSize: num(env.SYNC_PAGE_SIZE, 500),
    rate: {                                                 // 限流：[次数, 时间窗(秒)]
      emailPerAddress: [num(env.RATE_EMAIL_PER_ADDRESS, 5), 3600],
      emailPerIp: [num(env.RATE_EMAIL_PER_IP, 20), 3600],
      emailCooldown: num(env.RATE_EMAIL_COOLDOWN, 30),
      verifyPerIp: [num(env.RATE_VERIFY_PER_IP, 30), 600],
      pairPerIp: [num(env.RATE_PAIR_PER_IP, 20), 600],
      apiPerIp: [num(env.RATE_API_PER_IP, 600), 60],
      feedbackPerIp: [num(env.RATE_FEEDBACK_PER_IP, 10), 3600],
      pushPerIp: [num(env.RATE_PUSH_PER_IP, 30), 600],
      licensePerIp: [num(env.RATE_LICENSE_PER_IP, 30), 600],
      telemetryPerIp: [num(env.RATE_TELEMETRY_PER_IP, 120), 600], // v1.9.2 匿名使用统计上报：每个 IP 10 分钟内最多几次（一次最多 20 条）
      telemetryPerDevice: [num(env.RATE_TELEMETRY_PER_DEVICE, 60), 3600],
    },
    feedbackEmail: env.FEEDBACK_EMAIL || '',                // v1.6 反馈收件邮箱：网页「用邮件发送」的收件人；邮件服务配好时，新反馈也抄送一封提醒
    push: {                                                 // v1.8 学习提醒推送（Web Push / VAPID）
      enabled: env.PUSH_ENABLED === undefined ? true : bool(env.PUSH_ENABLED),
      publicKey: env.VAPID_PUBLIC_KEY || '', privateKey: env.VAPID_PRIVATE_KEY || '', // 不填：首次启动自动生成并存进数据库（迁移服务器时连数据库一起搬，或抄进 .env）
      subject: env.VAPID_SUBJECT || (env.FEEDBACK_EMAIL ? 'mailto:' + env.FEEDBACK_EMAIL : publicUrl || 'mailto:admin@localhost'), // 推送服务出问题时联系谁（苹果要求是 mailto: 或 https:）
      tickSeconds: num(env.PUSH_TICK_SECONDS, 60),          // 多久检查一次“谁到点了”；0 = 不自动发（测试用）
      allowHttp: bool(env.PUSH_ALLOW_HTTP),                 // 只用于本机测试：允许 http:// 的推送地址（真实推送服务都是 https）
    },
    license: {                                              // v1.9 授权（第二阶段）
      publicKey: env.LICENSE_PUBLIC_KEY || '',              // 激活码公钥（hex）；不填 = 用 App 内置的那把（public/js/licensekey.js）
      privateKey: env.LICENSE_PRIVATE_KEY || '',            // 可选，64 位 hex；付款后自动签发激活码才需要。不填则只开通服务器订阅授权
      maxDevices: num(env.LICENSE_MAX_DEVICES, 3),          // 一个账户的会员最多几台设备
      trialUses: num(env.TRIAL_USES, 7),                    // 试用次数（和 public/js/billing.js 的 TRIAL_USES 保持一致）
      sessionGapMin: num(env.TRIAL_SESSION_GAP_MIN, 30),    // 停下多少分钟再学算新的一次（和 billing.js 的 SESSION_GAP_MIN 一致）
      adminToken: env.LICENSE_ADMIN_TOKEN || env.ADMIN_TOKEN || '', // 管理口令：开通订阅、作废激活码（不填 = 用 ADMIN_TOKEN；都不填 = 管理接口关闭）
      revoked: list(env.LICENSE_REVOKED).map(Number).filter(n => n > 0), // 作废的激活码编号，逗号分隔
    },
    billing: {                                              // v1.10 付费与推荐（默认全部关闭，不影响免费使用）
      enabled: bool(env.BILLING_ENABLED),                   // 总开关；不填 / 0 = 关。也可在看板打开（存 kv，优先于此项）
      smsProvider: (env.SMS_PROVIDER || 'off').toLowerCase(), // off | console（只写日志，不真发短信）| http
      smsUrl: env.SMS_API_URL || '',
      smsKey: env.SMS_API_KEY || '',
      payProvider: (env.PAY_PROVIDER || 'none').toLowerCase(), // none | manual | stripe | apple | google（未开通的通道不会收款）
      phonePepper: env.BILLING_PHONE_PEPPER || '',
      firstWeekDays: num(env.BILLING_FIRST_WEEK_DAYS, 7),
      firstWeekCheckins: num(env.BILLING_FIRST_WEEK_CHECKINS, 3),
      checkinGoal: num(env.BILLING_CHECKIN_GOAL, 10),
      rewardHoldDays: num(env.BILLING_REWARD_HOLD_DAYS, 30),
      discountPercent: num(env.BILLING_DISCOUNT_PERCENT, 20),
    },
    adminToken: env.ADMIN_TOKEN || '',                      // v1.9.2 总管理口令：GET /api/v1/admin/stats、管理看板 /admin/stats；也可以查看反馈、管理激活码（那两个单独口令没填时）
    telemetry: env.TELEMETRY_ENABLED === undefined ? true : bool(env.TELEMETRY_ENABLED), // 接收匿名使用统计（POST /api/v1/telemetry）；0 = 关
    statsTzOffsetMin: num(env.STATS_TZ_OFFSET_MIN, 480),    // 看板按哪个时区算“今天”（分钟，默认 480 = 北京时间）
    feedbackAdminToken: env.FEEDBACK_ADMIN_TOKEN || env.ADMIN_TOKEN || '',     // 查看反馈的管理口令（GET /api/v1/feedback，Authorization: Bearer 口令）；不填 = 不开放查看接口
    ai: {                                                   // v1.9.4 内置 AI（服务器代理）：没填自己密钥的用户经服务器用 AI。看板「AI 设置」里保存的值优先于这里
      apiKey: String(env.AI_API_KEY || '').trim(),          // 兼容 OpenAI 的密钥（也可以在看板里粘贴保存：存在数据库旁边的 ai-key 文件，权限 0600）
      baseUrl: String(env.AI_BASE_URL || '').trim(),        // 默认 https://api.openai.com/v1
      model: String(env.AI_MODEL || '').trim(),             // 默认 gpt-4o-mini（便宜）
      ttsModel: String(env.AI_TTS_MODEL || '').trim(),      // 默认 gpt-4o-mini-tts
      enabled: env.AI_ENABLED === undefined ? undefined : bool(env.AI_ENABLED), // 总开关；不填 = 有密钥就开
      deviceDaily: num(env.AI_DEVICE_DAILY, 300),           // 每台设备每天最多调用几次（缓存命中不算）
      deviceMonthly: num(env.AI_DEVICE_MONTHLY, 3000),      // 每台设备每月最多几次
      ttsDaily: num(env.AI_TTS_DEVICE_DAILY, 300),          // 每台设备每天最多生成几段 AI 语音
      ipDaily: num(env.AI_IP_DAILY, 2000),                  // 每个 IP 每天最多几次（防止换设备 ID 刷额度）
      monthlyBudgetUsd: num(env.AI_MONTHLY_BUDGET_USD, 20), // 全站每月花费上限（美元，按价目表估算），到了就自动改用免费翻译
      maxInputChars: num(env.AI_MAX_INPUT_CHARS, 8000),     // 单次输入上限（字符）
      perMinIp: num(env.AI_PER_MIN_IP, 60), perMinDevice: num(env.AI_PER_MIN_DEVICE, 30), // 每分钟限流
      origins: list(env.AI_ALLOWED_ORIGINS),                // 额外允许使用内置 AI 的网页来源（本站、ALLOWED_ORIGINS、App 客户端已默认允许）
    },
    mail: {
      provider: (env.MAIL_PROVIDER || 'console').toLowerCase(), // console（打印在日志，原型）| smtp | http
      from: env.MAIL_FROM || '自主学 <no-reply@localhost>',
      subject: env.MAIL_SUBJECT || '自主学 验证码',
      smtp: { host: env.SMTP_HOST || '', port: num(env.SMTP_PORT, 587), secure: bool(env.SMTP_SECURE), starttls: env.SMTP_STARTTLS === undefined ? true : bool(env.SMTP_STARTTLS), user: env.SMTP_USER || '', pass: env.SMTP_PASS || '', heloName: env.SMTP_HELO || 'zizhuxue-sync', rejectUnauthorized: env.SMTP_TLS_INSECURE ? !bool(env.SMTP_TLS_INSECURE) : true },
      http: { url: env.MAIL_API_URL || '', key: env.MAIL_API_KEY || '', format: (env.MAIL_API_FORMAT || 'resend').toLowerCase() },
    },
  };
  return cfg;
}

/** 启动前检查：配置有明显问题时给出中文提示（不阻止原型运行，只告警） */
export function checkConfig(cfg) {
  const warn = [];
  if (cfg.mail.provider === 'console') warn.push('邮件：MAIL_PROVIDER=console，验证码只打印在服务器日志（仅适合原型/内测）');
  if (cfg.mail.provider === 'smtp' && !cfg.mail.smtp.host) warn.push('邮件：MAIL_PROVIDER=smtp 但没填 SMTP_HOST');
  if (cfg.mail.provider === 'http' && !cfg.mail.http.url) warn.push('邮件：MAIL_PROVIDER=http 但没填 MAIL_API_URL');
  if (cfg.allowedOrigins.includes('*')) warn.push('跨域：ALLOWED_ORIGINS=*（任何网页都能调用接口；正式上线请填网页地址）');
  if (!cfg.adminToken) warn.push('ADMIN_TOKEN 未设置：管理看板 /admin/stats 和 /api/v1/admin/stats 关闭');
  else if (cfg.adminToken.length < 16) warn.push('ADMIN_TOKEN 太短（建议 24 位以上随机字符）');
  if (cfg.ai.apiKey && !cfg.adminToken) warn.push('AI_API_KEY 已设置但没有 ADMIN_TOKEN：看不到 AI 花费统计，也不能在看板里改 AI 设置');
  if (cfg.billing?.enabled && cfg.billing?.smsProvider === 'off') warn.push('BILLING_ENABLED 已打开但短信通道是 off：好友完不成手机验证（不要为此去注册付费短信服务，用看板手工处理或 SMS_PROVIDER=console 做测试）');
  if (cfg.billing?.enabled && (!cfg.billing?.payProvider || cfg.billing.payProvider === 'none' || cfg.billing.payProvider === 'off')) warn.push('BILLING_ENABLED 已打开但付款通道未开通：在线不能收款，只能在看板手工登记付款');
  if (cfg.license?.privateKey && !/^[0-9a-f]{64}$/i.test(cfg.license.privateKey.trim())) warn.push('LICENSE_PRIVATE_KEY 格式不对（应为 64 位 hex），付款后无法自动签发激活码');
  if (!cfg.publicUrl) warn.push('PUBLIC_URL 未设置（正式上线请填 https:// 开头的对外地址）');
  else if (!/^https:\/\//.test(cfg.publicUrl)) warn.push('PUBLIC_URL 不是 https（手机浏览器要求 HTTPS 才能安装和稳定使用）');
  return warn;
}
