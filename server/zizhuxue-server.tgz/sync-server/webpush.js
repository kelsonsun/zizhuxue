// v1.8 Web Push（零依赖，只用 node:crypto）：
//   · VAPID（RFC 8292）：ES256 签名的 JWT，告诉推送服务“是哪个服务器在发”；
//   · 消息加密（RFC 8291 + RFC 8188 aes128gcm）：只有订阅的那台设备能解开，苹果 / 谷歌 / Mozilla 的推送服务看不到内容。
// iOS 16.4+ 加到主屏幕的网页、安卓 Chrome、桌面 Chrome / Edge / Firefox / Safari 都走这套标准。
import crypto from 'node:crypto';

export const b64u = buf => Buffer.from(buf).toString('base64url');
export const unb64u = s => Buffer.from(String(s).replace(/=+$/, ''), 'base64url');

/** 生成一对 VAPID 密钥：publicKey = 65 字节未压缩公钥（base64url，前端 subscribe 用），privateKey = 32 字节 d（base64url） */
export function generateVapidKeys() {
  const e = crypto.createECDH('prime256v1'); e.generateKeys();
  return { publicKey: b64u(e.getPublicKey()), privateKey: b64u(e.getPrivateKey()) };
}
/** 原始密钥 → KeyObject（签名用） */
function privKeyObject(publicKey, privateKey) {
  const pub = unb64u(publicKey); if (pub.length !== 65 || pub[0] !== 4) throw new Error('VAPID 公钥格式不对（应为 65 字节未压缩点）');
  return crypto.createPrivateKey({ key: { kty: 'EC', crv: 'P-256', d: b64u(unb64u(privateKey)), x: b64u(pub.subarray(1, 33)), y: b64u(pub.subarray(33)) }, format: 'jwk' });
}
/** VAPID 授权头：Authorization: vapid t=<JWT>, k=<公钥> */
export function vapidAuth(endpoint, { publicKey, privateKey, subject }, nowS = Math.floor(Date.now() / 1000)) {
  const aud = new URL(endpoint).origin;
  const head = b64u(JSON.stringify({ typ: 'JWT', alg: 'ES256' })), body = b64u(JSON.stringify({ aud, exp: nowS + 12 * 3600, sub: subject || 'mailto:admin@localhost' }));
  const sig = crypto.sign('sha256', Buffer.from(head + '.' + body), { key: privKeyObject(publicKey, privateKey), dsaEncoding: 'ieee-p1363' });
  return `vapid t=${head}.${body}.${b64u(sig)}, k=${publicKey}`;
}
/** 校验 VAPID JWT（测试 / 自检用）：返回 claims，签名不对抛错 */
export function verifyVapid(header, publicKey) {
  const m = /^vapid t=([^,\s]+),\s*k=(\S+)$/.exec(header || ''); if (!m) throw new Error('不是 vapid 头');
  const [h, b, s] = m[1].split('.'); const pub = unb64u(m[2]);
  if (m[2] !== publicKey) throw new Error('公钥不匹配');
  const key = crypto.createPublicKey({ key: { kty: 'EC', crv: 'P-256', x: b64u(pub.subarray(1, 33)), y: b64u(pub.subarray(33)) }, format: 'jwk' });
  if (!crypto.verify('sha256', Buffer.from(h + '.' + b), { key, dsaEncoding: 'ieee-p1363' }, unb64u(s))) throw new Error('VAPID 签名不对');
  return JSON.parse(unb64u(b).toString());
}
const hkdf = (salt, ikm, info, len) => Buffer.from(crypto.hkdfSync('sha256', ikm, salt, info, len));
/**
 * 加密一条推送（aes128gcm，单记录）。p256dh / auth 来自浏览器的 PushSubscription.keys。
 * 返回完整请求体：salt(16) | rs(4) | idlen(1)=65 | 发送方临时公钥(65) | 密文+tag
 */
export function encrypt(payload, p256dh, auth, { salt = crypto.randomBytes(16), ephemeral = null } = {}) {
  const ua = unb64u(p256dh), secret = unb64u(auth);
  if (ua.length !== 65) throw new Error('p256dh 格式不对'); if (secret.length < 16) throw new Error('auth 格式不对');
  const as = ephemeral || crypto.createECDH('prime256v1'); if (!ephemeral) as.generateKeys();
  const asPub = as.getPublicKey(); const shared = as.computeSecret(ua);
  const ikm = hkdf(secret, shared, Buffer.concat([Buffer.from('WebPush: info\0'), ua, asPub]), 32);
  const cek = hkdf(salt, ikm, Buffer.from('Content-Encoding: aes128gcm\0'), 16), nonce = hkdf(salt, ikm, Buffer.from('Content-Encoding: nonce\0'), 12);
  const plain = Buffer.concat([Buffer.from(typeof payload === 'string' ? payload : JSON.stringify(payload)), Buffer.from([2])]); // 0x02 = 最后一条记录
  if (plain.length > 3993) throw new Error('推送内容太长（最多约 3.9KB）');
  const c = crypto.createCipheriv('aes-128-gcm', cek, nonce); const ct = Buffer.concat([c.update(plain), c.final(), c.getAuthTag()]);
  const rs = Buffer.alloc(4); rs.writeUInt32BE(4096);
  return Buffer.concat([salt, rs, Buffer.from([65]), asPub, ct]);
}
/** 接收端解密（浏览器做的事；这里给测试 / 自检用）：ua = 接收端 ECDH（含私钥），auth = 16 字节 */
export function decrypt(body, uaEcdh, auth) {
  const salt = body.subarray(0, 16), idlen = body[20], asPub = body.subarray(21, 21 + idlen), ct = body.subarray(21 + idlen);
  const ua = uaEcdh.getPublicKey(); const shared = uaEcdh.computeSecret(asPub);
  const ikm = hkdf(unb64u(auth), shared, Buffer.concat([Buffer.from('WebPush: info\0'), ua, asPub]), 32);
  const cek = hkdf(salt, ikm, Buffer.from('Content-Encoding: aes128gcm\0'), 16), nonce = hkdf(salt, ikm, Buffer.from('Content-Encoding: nonce\0'), 12);
  const d = crypto.createDecipheriv('aes-128-gcm', cek, nonce); d.setAuthTag(ct.subarray(ct.length - 16));
  const plain = Buffer.concat([d.update(ct.subarray(0, ct.length - 16)), d.final()]);
  let end = plain.length - 1; while (end >= 0 && plain[end] === 0) end--; // 去掉填充，最后是 0x02 分隔符
  if (plain[end] !== 2) throw new Error('填充格式不对');
  return plain.subarray(0, end).toString('utf8');
}
/**
 * 发一条推送。sub = {endpoint, keys:{p256dh, auth}}。返回 {status, gone}：gone = 404/410（订阅已失效，调用方应删除）
 * fetchImpl 可注入（测试）。TTL：推送服务最多替我们保留多久（秒）——提醒过时就没意义，默认 4 小时。
 */
export async function sendPush(sub, payload, vapid, { ttl = 4 * 3600, urgency = 'normal', topic, fetchImpl = fetch, nowS } = {}) {
  const body = encrypt(payload, sub.keys.p256dh, sub.keys.auth);
  const headers = { TTL: String(ttl), Urgency: urgency, 'Content-Encoding': 'aes128gcm', 'Content-Type': 'application/octet-stream', Authorization: vapidAuth(sub.endpoint, vapid, nowS) };
  if (topic) headers.Topic = topic; // 同一 topic 的旧消息会被新消息替换（还没送达时）
  const r = await fetchImpl(sub.endpoint, { method: 'POST', headers, body });
  return { status: r.status, ok: r.status >= 200 && r.status < 300, gone: r.status === 404 || r.status === 410, text: r.ok ? '' : await r.text().catch(() => '') };
}
