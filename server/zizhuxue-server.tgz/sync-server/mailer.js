// 发验证码邮件的适配器。接口：{ kind, send({ to, subject, text }) → Promise }。
//  · console：打印在服务器日志（原型/内测，不真的发邮件）
//  · smtp：标准 SMTP（支持 465 直连 TLS、587 STARTTLS、AUTH PLAIN/LOGIN），零依赖，可接任何邮箱服务商
//  · http：HTTP 接口（默认 Resend 格式 {from,to,subject,text}，Bearer 密钥；也可 MAIL_API_FORMAT=json 发通用 JSON）
//  · 也可以在 createSyncServer({ mailer }) 里传入自己写的对象
import net from 'node:net'; import tls from 'node:tls'; import os from 'node:os';

export function createMailer(mail, log = console.log) {
  if (mail.provider === 'smtp') return smtpMailer(mail);
  if (mail.provider === 'http') return httpMailer(mail);
  return { kind: 'server-log', send: async ({ to, text }) => { log(`[邮件模拟] 发给 ${to}：${text}`); } };
}

function httpMailer(mail) {
  return {
    kind: 'email',
    async send({ to, subject, text }) {
      const { url, key, format } = mail.http;
      const body = format === 'resend' ? { from: mail.from, to: [to], subject, text } : { from: mail.from, to, subject, text };
      const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', ...(key ? { Authorization: 'Bearer ' + key } : {}) }, body: JSON.stringify(body) });
      if (!r.ok) throw new Error('邮件接口返回 ' + r.status + '：' + (await r.text()).slice(0, 200));
    },
  };
}

const b64 = s => Buffer.from(s, 'utf8').toString('base64');
const encWord = s => /^[\x20-\x7e]*$/.test(s) ? s : '=?UTF-8?B?' + b64(s) + '?=';
const encAddr = a => { const m = /^(.*)<([^>]+)>\s*$/.exec(a); return m ? `${encWord(m[1].trim())} <${m[2]}>` : a; };
const bare = a => (/<([^>]+)>/.exec(a) || [, a])[1].trim();

export function buildMessage({ from, to, subject, text, date = new Date(), id = Date.now().toString(36) }) {
  const body = b64(text).replace(/.{1,76}/g, '$&\r\n');
  return [`From: ${encAddr(from)}`, `To: ${to}`, `Subject: ${encWord(subject)}`, `Date: ${date.toUTCString()}`, `Message-ID: <${id}@zizhuxue>`, 'MIME-Version: 1.0',
    'Content-Type: text/plain; charset=UTF-8', 'Content-Transfer-Encoding: base64', '', body].join('\r\n');
}

/** 极简 SMTP 客户端：一封信一个连接 */
export function smtpMailer(mail) {
  const o = mail.smtp;
  return {
    kind: 'email',
    send: ({ to, subject, text }) => new Promise((resolve, reject) => {
      let sock = o.secure ? tls.connect({ host: o.host, port: o.port, servername: o.host, rejectUnauthorized: o.rejectUnauthorized }) : net.connect({ host: o.host, port: o.port });
      sock.setTimeout(20000, () => fail(new Error('SMTP 超时')));
      let buf = '', waiter = null, done = false;
      const fail = e => { if (done) return; done = true; try { sock.destroy(); } catch { } reject(e); };
      const onData = d => { buf += d.toString('utf8'); const lines = buf.split('\r\n'); if (lines.length < 2) return; // 等完整回复（最后一行 "250 " 而不是 "250-"）
        const last = lines[lines.length - 2]; if (/^\d{3} /.test(last)) { const all = buf; buf = ''; const w = waiter; waiter = null; w?.(all); } };
      const attach = s => { s.on('data', onData); s.on('error', fail); };
      attach(sock);
      const read = () => new Promise(r => { waiter = r; });
      const cmd = async (line, expect) => { if (line != null) sock.write(line + '\r\n'); const res = await read(); const code = +res.slice(0, 3); if (!expect.includes(code)) throw new Error(`SMTP ${line?.split(' ')[0] || '连接'} 失败：${res.trim().split('\r\n').pop()}`); return res; };
      (async () => {
        await cmd(null, [220]);
        let ehlo = await cmd('EHLO ' + (o.heloName || os.hostname()), [250]);
        if (!o.secure && o.starttls && /STARTTLS/i.test(ehlo)) {
          await cmd('STARTTLS', [220]); sock.removeListener('data', onData);
          sock = tls.connect({ socket: sock, servername: o.host, rejectUnauthorized: o.rejectUnauthorized }); attach(sock);
          await new Promise((r, j) => { sock.once('secureConnect', r); sock.once('error', j); });
          ehlo = await cmd('EHLO ' + (o.heloName || os.hostname()), [250]);
        }
        if (o.user) {
          if (/AUTH[ =][^\r\n]*PLAIN/i.test(ehlo)) await cmd('AUTH PLAIN ' + b64(`\0${o.user}\0${o.pass}`), [235]);
          else { await cmd('AUTH LOGIN', [334]); await cmd(b64(o.user), [334]); await cmd(b64(o.pass), [235]); }
        }
        await cmd(`MAIL FROM:<${bare(mail.from)}>`, [250]);
        await cmd(`RCPT TO:<${to}>`, [250, 251]);
        await cmd('DATA', [354]);
        const msg = buildMessage({ from: mail.from, to, subject, text }).replace(/\r\n\./g, '\r\n..');
        await cmd(msg + '\r\n.', [250]);
        sock.write('QUIT\r\n'); done = true; sock.end(); resolve();
      })().catch(fail);
    }),
  };
}
