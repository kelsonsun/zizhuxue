// v1.8 服务器端提醒计划（纯函数，可单测）：每分钟看一遍订阅，按“用户当地时间”决定给谁发、发哪种语气。
import { reminder } from '../public/js/rewards.js';
import { KINDS, normPrefs, inQuiet, minOf } from '../public/js/remindplan.js';

/** 某个时刻在用户时区的 {date:'YYYY-MM-DD', min: 当天第几分钟, hour}。优先用 IANA 时区名（夏令时自动对），没有就用分钟偏移（getTimezoneOffset，UTC − 本地） */
export function localNow(nowMs, { tz, tzOffset = 0 } = {}) {
  if (tz) {
    try {
      const p = Object.fromEntries(new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(new Date(nowMs)).map(x => [x.type, x.value]));
      return { date: `${p.year}-${p.month}-${p.day}`, hour: +p.hour, min: +p.hour * 60 + +p.minute };
    } catch { /* 时区名无效：退回偏移 */ }
  }
  const d = new Date(nowMs - tzOffset * 60000);
  return { date: d.toISOString().slice(0, 10), hour: d.getUTCHours(), min: d.getUTCHours() * 60 + d.getUTCMinutes() };
}
export const parseAt = at => { const m = /^([01]\d|2[0-3]):([0-5]\d)$/.exec(String(at || '')); return m ? +m[1] * 60 + +m[2] : null; };
export const LATE_MIN = 23 * 60; // 23:00 “最后一次”提醒
const WINDOW = 120;                // 服务器停过一会儿：到点后 2 小时内补发，再晚就不发了（提醒过时没意义）
const daySeed = date => Math.floor(Date.parse(date + 'T00:00:00Z') / 86400000);

/**
 * 决定现在该给这条订阅发什么。sub：{at, tz, tz_offset, late, streak, met_date, sent_date, late_date}
 * 返回 null 或 {kind:'main'|'late', date, payload:{title, body, tone, tag, url, kind, date}}
 */
export function due(sub, nowMs) {
  const at = parseAt(sub.at); if (at == null) return null;
  const L = localNow(nowMs, { tz: sub.tz, tzOffset: sub.tz_offset || 0 });
  if (sub.met_date === L.date) return null; // 今天已打卡：不打扰
  const mk = (kind, hour) => { const r = reminder(hour, { met: false, streak: sub.streak || 0 }, daySeed(L.date) + (kind === 'late' ? 1 : 0)); return { kind, date: L.date, payload: { title: '自主学 · 学习提醒', body: r.text, tone: r.tone, tag: 'zzx-remind', url: './#/', kind, date: L.date } }; };
  if (sub.late && at < LATE_MIN && L.min >= LATE_MIN && sub.late_date !== L.date) return mk('late', 23);
  if (L.min >= at && L.min < at + WINDOW && sub.sent_date !== L.date && !(sub.late && L.min >= LATE_MIN)) return mk('main', L.hour);
  return null;
}

// ———— v1.11 网页推送强提醒：四种提醒 + 免打扰 + 每日上限 + 间隔（纯函数，可单测） ————
export const GAP_MIN = 45;           // 两条提醒之间至少隔 45 分钟（防轰炸）
export const PRIORITY = ['streak', 'evening', 'review', 'daily']; // 同时到点时先发哪种（其余的等间隔过了、还在 2 小时窗口里再发）
/** 某个日期的到期卡数：due 是 {日期: 到那天为止到期张数}；没有这一天就用之前最近的一天（到期数只会增加） */
export function dueOn(due, date) {
  if (!due || typeof due !== 'object') return 0; if (due[date] != null) return Math.max(0, +due[date] || 0);
  const ks = Object.keys(due).filter(k => k <= date).sort(); return ks.length ? Math.max(0, +due[ks.at(-1)] || 0) : 0;
}
const pick = (arr, seed) => arr[Math.abs(seed) % arr.length];
/** 文案：简短有力。ctx = {count 到期张数, streak 连续天数, freezes 冰块数}；seed 让每天换一句 */
export function copy(kind, ctx = {}, seed = 0) {
  const n = ctx.count || 0, s = ctx.streak || 0;
  if (kind === 'review') return { title: `📚 ${n} 张卡到期了`, body: pick(['趁还记得，3 分钟复习掉，越拖越难记。', '到期不复习就会忘，现在点开刷完它。', '复习的最佳时间就是现在，点开就练。'], seed) };
  if (kind === 'streak') return { title: `🔥 连续 ${s} 天，今天要断了！`, body: ctx.freezes > 0 ? '今天不学会用掉 1 个冰块。现在学几题，保住它！' : pick(['还差几题就保住，现在就学！', `${s} 天的坚持别在今天断掉，点开学 5 分钟。`], seed) };
  if (kind === 'evening') return { title: '🌙 今天还没学英语', body: pick(['睡前 5 分钟，今天就不算白过。', '一题都还没做，现在学几句再睡。', '今天还剩一点时间，学 5 分钟就够。'], seed) };
  if (kind === 'test') return { title: '自主学 · 提醒已开启 ✅', body: '这是一条测试提醒。到点我会准时来叫你学习。' };
  return { title: '⏰ 该学英语了', body: s > 0 ? pick([`连续 ${s} 天了，今天继续！10 分钟就够。`, `第 ${s + 1} 天，现在开始，学完就打卡。`], seed) : pick(['今天的英语还没学，10 分钟就够，现在开始！', '学英语就靠每天一点点，现在点开学 10 分钟。', '说好的每天学一会儿，现在就来！'], seed) };
}
export const URL_OF = { review: './#/review', streak: './#/review', evening: './#/', daily: './#/', test: './#/me' };
/**
 * v1.11 决定现在该给这条订阅发什么。sub：push_subs 一行（prefs 是 JSON），sent：今天（用户当地日期）已发过的 [{kind, ts(秒)}]
 * 规则：今天已打卡（学够了）→ 什么都不催；每天最多 cap 条；免打扰时段不发；两条之间至少隔 GAP_MIN 分钟；
 *       每种每天最多一次，到点后 2 小时内补发（服务器停过）；复习提醒要有到期卡；连续打卡提醒要有连续天数；晚间提醒要今天一题没做。
 * 返回 null 或 {kind, date, payload}
 */
export function dueV2(sub, nowMs, sent = []) {
  let prefs; try { prefs = normPrefs(typeof sub.prefs === 'string' ? JSON.parse(sub.prefs) : sub.prefs || {}); } catch { return null; }
  const L = localNow(nowMs, { tz: sub.tz, tzOffset: sub.tz_offset || 0 });
  if (sub.met_date === L.date) return null;
  if (sent.length >= prefs.cap) return null;
  if (inQuiet(L.min, prefs.quiet)) return null;
  const last = Math.max(0, ...sent.map(x => x.ts || 0)); if (last && nowMs / 1000 - last < GAP_MIN * 60) return null;
  const done = new Set(sent.map(x => x.kind)); let due = {}; try { due = JSON.parse(sub.due_json || '{}'); } catch { }
  const count = dueOn(due, L.date), streak = sub.streak || 0, studied = sub.studied_date === L.date;
  const ok = { daily: true, review: count > 0, streak: streak > 0, evening: !studied };
  for (const kind of PRIORITY) {
    const p = prefs[kind]; if (!p.on || done.has(kind) || !ok[kind]) continue;
    const at = minOf(p.at); if (!(L.min >= at && L.min < at + WINDOW)) continue;
    const c = copy(kind, { count, streak, freezes: sub.freezes || 0 }, daySeed(L.date) + KINDS.indexOf(kind));
    return { kind, date: L.date, payload: { ...c, tag: 'zzx-' + kind, url: URL_OF[kind], kind, date: L.date, ...(kind === 'review' ? { count } : {}), ...(kind === 'streak' ? { streak } : {}), sticky: kind === 'streak' || kind === 'evening' } };
  }
  return null;
}
