// v1.8 服务器端提醒计划（纯函数，可单测）：每分钟看一遍订阅，按“用户当地时间”决定给谁发、发哪种语气。
import { reminder } from '../public/js/rewards.js';

/** 某个时刻在用户时区的 {date:'YYYY-MM-DD', min: 当天第几分钟, hour}。优先用 IANA 时区名（夏令时自动对），没有就用分钟偏移（getTimezoneOffset，UTC − 本地） */
export function localNow(nowMs, { tz, tzOffset = 0 } = {}) {
  if (tz) {
    try {
      const p = Object.fromEntries(new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(new Date(nowMs)).map(x => [x.type, x.value]));
      return { date: `${p.year}-${p.month}-${p.day}`, hour: +p.hour, min: +p.hour * 60 + +p.minute };
    } catch { /* 时区名无效：退回偏移 */ }
  }
  const d = new Date(nowMs - tzOffset * 60000);
  return { date: d.toISOString().slice(0, 10), hour: d.getUTCHours(), min: d.getUTCHours() * 60 + d.getUTCMinutes() };
}
export const parseAt = at => { const m = /^([01]\d|2[0-3]):([0-5]\d)$/.exec(String(at || '')); return m ? +m[1] * 60 + +m[2] : null; };
export const LATE_MIN = 23 * 60; // 23:00 “最后一次”提醒
const WINDOW = 120;                // 服务器停过一会儿：到点后 2 小时内补发，再晚就不发了（提醒过时没意义）
const daySeed = date => Math.floor(Date.parse(date + 'T00:00:00Z') / 86400000);

/**
 * 决定现在该给这条订阅发什么。sub：{at, tz, tz_offset, late, streak, met_date, sent_date, late_date}
 * 返回 null 或 {kind:'main'|'late', date, payload:{title, body, tone, tag, url, kind, date}}
 */
export function due(sub, nowMs) {
  const at = parseAt(sub.at); if (at == null) return null;
  const L = localNow(nowMs, { tz: sub.tz, tzOffset: sub.tz_offset || 0 });
  if (sub.met_date === L.date) return null; // 今天已打卡：不打扰
  const mk = (kind, hour) => { const r = reminder(hour, { met: false, streak: sub.streak || 0 }, daySeed(L.date) + (kind === 'late' ? 1 : 0)); return { kind, date: L.date, payload: { title: '自主学 · 学习提醒', body: r.text, tone: r.tone, tag: 'zzx-remind', url: './#/', kind, date: L.date } }; };
  if (sub.late && at < LATE_MIN && L.min >= LATE_MIN && sub.late_date !== L.date) return mk('late', 23);
  if (L.min >= at && L.min < at + WINDOW && sub.sent_date !== L.date && !(sub.late && L.min >= LATE_MIN)) return mk('main', L.hour);
  return null;
}
