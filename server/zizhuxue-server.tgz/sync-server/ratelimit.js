// 内存限流（单实例够用；多实例部署时应换成 Redis 等共享存储，接口不变）。
export function createLimiter() {
  const hits = new Map(); // key → 时间戳数组（秒）
  let sweep = 0;
  /** 记一次并判断是否超限：返回 0 表示放行，否则返回需要等待的秒数 */
  function take(key, [max, win], now = Date.now() / 1000) {
    if (!max) return 0;
    if (now - sweep > 60) { sweep = now; for (const [k, a] of hits) if (!a.length || now - a[a.length - 1] > 3600) hits.delete(k); }
    const a = (hits.get(key) || []).filter(t => now - t < win);
    if (a.length >= max) { hits.set(key, a); return Math.max(1, Math.ceil(win - (now - a[0]))); }
    a.push(now); hits.set(key, a); return 0;
  }
  return { take, reset: () => hits.clear() };
}
