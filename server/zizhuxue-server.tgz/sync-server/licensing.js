// v1.9 第二阶段：账号、云同步、授权放在同一台同步服务器上（未部署）。
//   · 试用次数：服务器按账户和设备各记一份，取最大（清本机数据、换账户都不会重置）
//   · 激活码：服务器也用同一把公钥验证，绑定到账户（一个码只能绑一个账户），作废的码不认
//   · 订阅状态：管理员接口手动开通 / 续费（以后接支付回调时改这里）
//   · 设备数限制：一个账户的会员最多在 LICENSE_MAX_DEVICES 台设备上用，超出的设备显示“超出设备数”，可在已有设备上移除旧设备
import crypto from 'node:crypto'; import fs from 'node:fs'; import path from 'node:path';
import * as C from '../public/js/licensecode.js';
import * as T from '../public/js/trial.js'; // 计次规则和客户端共用（sessionsFromTimes）

export const MIGRATION = `CREATE TABLE IF NOT EXISTS licenses(serial INT PRIMARY KEY, plan TEXT, exp_day INT, account_id TEXT, activated INT, revoked INT DEFAULT 0, note TEXT);
   CREATE INDEX IF NOT EXISTS lic_acc ON licenses(account_id);
   CREATE TABLE IF NOT EXISTS license_devices(account_id TEXT, device_id TEXT, first INT, last INT, PRIMARY KEY(account_id, device_id));
   CREATE TABLE IF NOT EXISTS trials(subject TEXT PRIMARY KEY, used INT, last INT, first INT, updated INT);
   CREATE TABLE IF NOT EXISTS subscriptions(account_id TEXT PRIMARY KEY, plan TEXT, exp_day INT, source TEXT, note TEXT, updated INT);`;
/** 迁移 6（v1.9 补）：试用记录加每次计次的时间（按“停下超过 30 分钟才算新的一次”合并多台设备） */
export const MIGRATION_6 = 'ALTER TABLE trials ADD COLUMN log TEXT;';
const RANK = { basic: 1, ai: 2 };
const NAMES = { basic: '基础版', ai: '含 AI 版' };
/** 默认公钥：和 App 内置的同一把（public/js/licensekey.js）；也可用 LICENSE_PUBLIC_KEY 覆盖 */
export function defaultPublicKey() { try { return /'([0-9a-f]{64})'/.exec(fs.readFileSync(path.join(import.meta.dirname, '../public/js/licensekey.js'), 'utf8'))[1]; } catch { return ''; } }

export function createLicensing({ q, cfg, clock, err, limit }) {
  const L = cfg.license; const pub = L.publicKey ? C.fromHex(L.publicKey) : null;
  const nowS = () => Math.floor(clock() / 1000);
  const today = () => Math.floor((clock() - Date.UTC(2020, 0, 1)) / 864e5);
  const need = user => { if (!user) throw err(401, '未登录', 'unauth'); return user; };
  const admin = req => {
    const tok = (/^Bearer (\S+)$/.exec(req.headers.authorization || '') || [])[1] || '';
    if (!L.adminToken || tok.length !== L.adminToken.length || !crypto.timingSafeEqual(Buffer.from(tok), Buffer.from(L.adminToken))) throw err(401, '需要管理口令', 'unauth');
  };
  const trialOf = s => { const r = q('SELECT used,last,first,log FROM trials WHERE subject=?').get(s); return r ? { ...r, log: JSON.parse(r.log || '[]') } : { used: 0, last: 0, first: 0, log: [] }; };
  const putTrial = (s, t) => q('INSERT INTO trials(subject,used,last,first,updated,log) VALUES(?,?,?,?,?,?) ON CONFLICT(subject) DO UPDATE SET used=excluded.used,last=excluded.last,first=excluded.first,updated=excluded.updated,log=excluded.log').run(s, t.used, t.last, t.first, nowS(), JSON.stringify(t.log || []));
  const revoked = serial => L.revoked.includes(serial) || !!q('SELECT revoked FROM licenses WHERE serial=?').get(serial)?.revoked;
  /** 这个账户现在有效的会员（激活码 + 订阅里最好的那个） */
  function entitlement(acc) {
    const t = today(), opts = [];
    for (const r of q('SELECT * FROM licenses WHERE account_id=? AND revoked=0').all(acc)) if (!L.revoked.includes(r.serial) && r.exp_day >= t) opts.push({ plan: r.plan, expDay: r.exp_day, source: 'code', serial: r.serial });
    const s = q('SELECT * FROM subscriptions WHERE account_id=?').get(acc); if (s && s.plan && s.exp_day >= t) opts.push({ plan: s.plan, expDay: s.exp_day, source: 'subscription' });
    opts.sort((a, b) => (RANK[b.plan] - RANK[a.plan]) || (b.expDay - a.expDay));
    return { best: opts[0] || null, serials: opts.filter(o => o.serial).map(o => o.serial) };
  }
  /** 给这台设备占一个名额；满了返回 false */
  function seat(acc, dev) {
    const have = q('SELECT 1 FROM license_devices WHERE account_id=? AND device_id=?').get(acc, dev);
    if (have) { q('UPDATE license_devices SET last=? WHERE account_id=? AND device_id=?').run(nowS(), acc, dev); return true; }
    const n = q('SELECT COUNT(*) n FROM license_devices WHERE account_id=?').get(acc).n;
    if (n >= L.maxDevices) return false;
    q('INSERT INTO license_devices VALUES(?,?,?,?)').run(acc, dev, nowS(), nowS()); return true;
  }
  function status(user) {
    const acc = user.account_id, dev = user.device_id, { best, serials } = entitlement(acc);
    const deviceOk = best ? seat(acc, dev) : true;
    const devices = q('SELECT d.device_id id, d.first, d.last, v.name FROM license_devices d LEFT JOIN devices v ON v.id=d.device_id WHERE d.account_id=? ORDER BY d.last DESC').all(acc).map(d => ({ id: d.id, name: d.name || '', first: d.first * 1000, last: d.last * 1000, me: d.id === dev }));
    const ta = trialOf('a:' + acc), td = trialOf('d:' + dev);
    const trial = { used: Math.max(ta.used, td.used), last: Math.max(ta.last, td.last), first: Math.min(...[ta.first, td.first].filter(Boolean), Infinity) === Infinity ? 0 : Math.min(...[ta.first, td.first].filter(Boolean)) };
    return { ok: true, plan: best?.plan || null, planName: best ? NAMES[best.plan] : null, expDay: best ? (best.expDay === C.FOREVER ? null : best.expDay) : null, expires: best && best.expDay !== C.FOREVER ? C.ymdOf(best.expDay) : null, source: best?.source || null, serials, deviceOk, devices, maxDevices: L.maxDevices, trial, trialUses: L.trialUses, serverTime: clock() };
  }
  return {
    status,
    routes: {
      // 试用次数对账：客户端报本机记录，服务器按账户和设备各存一份，都取最大，再把最大值还给客户端
      // 试用次数对账：客户端报本机记录（次数、最后学习时间、每次计次的时间），服务器按账户和设备各存一份。
      // 次数和客户端同一套规则：计次时间相隔不到 sessionGapMin 分钟的算同一次（多台设备同时在学不重复算），再和各处报的次数取最大
      'POST /trial/sync': ({ user, body, ip }) => {
        need(user); limit('lic:' + ip, cfg.rate.licensePerIp, '请求太频繁');
        const n = (x, max) => Math.max(0, Math.min(max, Math.floor(+x || 0)));
        const inc = { used: n(body.used, 1e6), last: n(body.last, clock() + 864e5), first: n(body.first, clock() + 864e5), log: (Array.isArray(body.log) ? body.log : []).slice(-1000).map(x => n(x, clock() + 864e5)).filter(Boolean) };
        const subs = ['a:' + user.account_id, 'd:' + user.device_id].map(s => ({ s, t: trialOf(s) }));
        const log = [...new Set([...inc.log, ...subs.flatMap(x => x.t.log)])].sort((a, b) => a - b).slice(-1000);
        const firsts = [inc.first, ...subs.map(x => x.t.first)].filter(Boolean);
        const out = { used: Math.max(inc.used, ...subs.map(x => x.t.used), T.sessionsFromTimes(log, L.sessionGapMin)), last: Math.max(inc.last, ...subs.map(x => x.t.last)), first: firsts.length ? Math.min(...firsts) : 0, log };
        for (const { s } of subs) putTrial(s, out);
        return { ok: true, trial: out, max: L.trialUses };
      },
      'POST /license/activate': ({ user, body, ip }) => {
        need(user); limit('lic:' + ip, cfg.rate.licensePerIp, '尝试次数太多');
        if (!pub) throw err(503, '服务器没配置激活码公钥', 'no_key');
        const r = C.readCode(body.code, pub); if (!r.ok) throw err(400, r.msg, 'bad_code');
        if (revoked(r.serial)) throw err(403, `这个激活码（#${r.serial}）已作废`, 'revoked');
        if (r.expDay < today()) throw err(400, `这个激活码已在 ${r.expires} 到期`, 'expired');
        const row = q('SELECT * FROM licenses WHERE serial=?').get(r.serial);
        if (row && row.account_id && row.account_id !== user.account_id) throw err(409, '这个激活码已经绑定到另一个账户了。一个码只能给一个账户用；如有疑问请联系我们。', 'used_elsewhere');
        if (!row) q('INSERT INTO licenses(serial,plan,exp_day,account_id,activated) VALUES(?,?,?,?,?)').run(r.serial, r.plan, r.expDay, user.account_id, nowS());
        else if (!row.account_id) q('UPDATE licenses SET account_id=?, activated=? WHERE serial=?').run(user.account_id, nowS(), r.serial);
        const s = status(user);
        if (!s.deviceOk) throw err(403, `这个账户的会员已经在 ${L.maxDevices} 台设备上使用了。请在其中一台的「我的 → 会员与激活」里移除不用的设备，再来激活。`, 'device_limit');
        return s;
      },
      'GET /license/status': ({ user }) => status(need(user)),
      // 移除一台设备的名额（只能移除自己账户下的）
      'POST /license/release': ({ user, body }) => { need(user); q('DELETE FROM license_devices WHERE account_id=? AND device_id=?').run(user.account_id, String(body.deviceId || '')); return status(user); },
      // ---- 管理员（LICENSE_ADMIN_TOKEN）----
      'POST /admin/subscription': ({ req, body }) => {
        admin(req);
        const acc = body.accountId || q('SELECT id FROM accounts WHERE email=?').get(String(body.email || '').trim().toLowerCase())?.id; if (!acc) throw err(404, '没有这个账户');
        if (!body.plan) { q('DELETE FROM subscriptions WHERE account_id=?').run(acc); return { ok: true, removed: true }; }
        if (!RANK[body.plan]) throw err(400, 'plan 只能是 basic / ai');
        const expDay = body.expires ? C.dayOf(body.expires) : C.FOREVER; if (Number.isNaN(expDay)) throw err(400, 'expires 格式 YYYY-MM-DD');
        q('INSERT INTO subscriptions VALUES(?,?,?,?,?,?) ON CONFLICT(account_id) DO UPDATE SET plan=excluded.plan,exp_day=excluded.exp_day,source=excluded.source,note=excluded.note,updated=excluded.updated').run(acc, body.plan, expDay, String(body.source || 'manual'), String(body.note || ''), nowS());
        return { ok: true, accountId: acc, plan: body.plan, expires: body.expires || null };
      },
      'POST /admin/revoke': ({ req, body }) => {
        admin(req); const serial = Math.floor(+body.serial); if (!(serial > 0)) throw err(400, 'serial 无效');
        q('INSERT INTO licenses(serial,revoked,note) VALUES(?,1,?) ON CONFLICT(serial) DO UPDATE SET revoked=1').run(serial, String(body.note || ''));
        return { ok: true, serial };
      },
      'GET /admin/licenses': ({ req }) => { admin(req); return { items: q('SELECT l.*, a.email FROM licenses l LEFT JOIN accounts a ON a.id=l.account_id ORDER BY serial').all(), subscriptions: q('SELECT s.*, a.email FROM subscriptions s LEFT JOIN accounts a ON a.id=s.account_id').all() }; },
    },
  };
}
