// 「自主学」自托管同步服务器。零依赖：Node 22.5+ 自带 node:sqlite，数据存一个 SQLite 文件。
// 启动：node sync-server/server.js [端口]；所有配置来自环境变量 / sync-server/.env（见 .env.example），换正式服务器只改配置。
// 同一端口提供：/api/v1/*（同步接口）、/healthz（健康检查）、应用本身（public/ 静态文件，SERVE_APP=0 可关）。
// 邮箱验证码：MAIL_PROVIDER=console 时打印在日志（原型）；smtp / http 时真的发邮件（见 mailer.js）。
import http from 'node:http'; import crypto from 'node:crypto'; import fs from 'node:fs'; import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { mergeRecord, sameRecord } from '../public/js/syncmerge.js';
import { createServer as createStatic } from '../server.js';
import { loadConfig, loadDotEnv, checkConfig } from './config.js';
import { createMailer } from './mailer.js';
import { createLimiter } from './ratelimit.js';
import { migrate, LATEST } from './migrations.js';
import * as WP from './webpush.js';
import { due as pushDue, parseAt } from './reminders.js';
import { createLicensing, defaultPublicKey } from './licensing.js';
import { createTelemetry, DASHBOARD_HTML, DASHBOARD_MANIFEST } from './telemetry.js';
import { createAI } from './ai.js';
import { createBilling } from './billing.js';

const STORES = new Set(['materials', 'cards', 'reviews']);
const H = s => crypto.createHash('sha256').update(s).digest('hex');
const rand = (n = 24) => crypto.randomBytes(n).toString('base64url');
const PAIR_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'; // 去掉易混淆的 0/O/1/I/L
const pairCode = () => { let s = ''; for (const b of crypto.randomBytes(8)) s += PAIR_ALPHABET[b % PAIR_ALPHABET.length]; return s.slice(0, 4) + '-' + s.slice(4); };
const API_VERSION = 2;

/**
 * 创建同步服务器。opts 里的项覆盖环境变量配置（测试用）：
 *   dbFile, accessTtl, refreshTtl, refreshGrace, serveApp, pageSize, allowedOrigins, publicUrl, trustProxy, rate, mail, log, mailer, now
 */
export function createSyncServer(opts = {}) {
  const base = loadConfig(opts.env || process.env);
  const cfg = { ...base, ...Object.fromEntries(Object.entries(opts).filter(([k, v]) => v !== undefined && !['log', 'mailer', 'env', 'now', 'aiFetch'].includes(k))) };
  cfg.rate = { ...base.rate, ...(opts.rate || {}) }; cfg.mail = { ...base.mail, ...(opts.mail || {}) }; cfg.push = { ...base.push, ...(opts.push || {}) }; cfg.license = { ...base.license, ...(opts.license || {}) }; cfg.ai = { ...base.ai, ...(opts.ai || {}) }; cfg.billing = { ...base.billing, ...(opts.billing || {}) }; if (!cfg.license.publicKey) cfg.license.publicKey = defaultPublicKey();
  if (!cfg.feedbackAdminToken) cfg.feedbackAdminToken = cfg.adminToken || ''; if (!cfg.license.adminToken) cfg.license.adminToken = cfg.adminToken || ''; // v1.9.2 ADMIN_TOKEN 兼任
  if (typeof cfg.allowedOrigins === 'string') cfg.allowedOrigins = cfg.allowedOrigins.split(',').map(s => s.trim()).filter(Boolean);
  const log = opts.log || console.log;
  const mailer = opts.mailer || createMailer(cfg.mail, log);
  const limiter = createLimiter();
  const clock = opts.now || (() => Date.now());

  if (cfg.dbFile !== ':memory:') fs.mkdirSync(path.dirname(cfg.dbFile), { recursive: true });
  const db = new DatabaseSync(cfg.dbFile);
  db.exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;');
  const mig = migrate(db, log);
  const q = sql => db.prepare(sql);
  const nowS = () => Math.floor(clock() / 1000);
  const tx = fn => { db.exec('BEGIN IMMEDIATE'); try { const r = fn(); db.exec('COMMIT'); return r; } catch (e) { db.exec('ROLLBACK'); throw e; } };
  // v1.8 推送：VAPID 密钥（环境变量优先；没配就自动生成一次，存在数据库 kv 表里，重启不变）
  const vapid = (() => {
    if (!cfg.push.enabled) return null;
    if (cfg.push.publicKey && cfg.push.privateKey) return { publicKey: cfg.push.publicKey, privateKey: cfg.push.privateKey, subject: cfg.push.subject, source: 'env' };
    const row = q("SELECT v FROM kv WHERE k='vapid'").get(); if (row) return { ...JSON.parse(row.v), subject: cfg.push.subject, source: 'db' };
    const k = WP.generateVapidKeys(); q("INSERT INTO kv(k,v) VALUES('vapid',?)").run(JSON.stringify(k));
    log('推送：已自动生成 VAPID 密钥并存进数据库（换服务器时连数据库一起迁移；也可以把公钥/私钥写进 .env 的 VAPID_PUBLIC_KEY / VAPID_PRIVATE_KEY）');
    return { ...k, subject: cfg.push.subject, source: 'generated' };
  })();
  const pushFetch = opts.pushFetch || fetch;
  const nextSeq = () => { q("INSERT INTO counters(k,v) VALUES('seq',1) ON CONFLICT(k) DO UPDATE SET v=v+1").run(); return q("SELECT v FROM counters WHERE k='seq'").get().v; };

  /** 发一组新令牌。keepRefresh：刚被轮换掉的旧刷新令牌（保留到宽限期结束） */
  function issueTokens(accountId, deviceId, deviceName, keepRefresh = null) {
    q('INSERT INTO devices(id,account_id,name,created,last_seen) VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET account_id=excluded.account_id, name=excluded.name, last_seen=excluded.last_seen').run(deviceId, accountId, deviceName || '', nowS(), nowS());
    if (keepRefresh) { q('DELETE FROM tokens WHERE device_id=? AND hash<>?').run(deviceId, keepRefresh); q('UPDATE tokens SET rotated_until=? WHERE hash=?').run(nowS() + cfg.refreshGrace, keepRefresh); }
    else q('DELETE FROM tokens WHERE device_id=?').run(deviceId); // 一台设备只保留一组令牌
    const at = 'at_' + rand(), rt = 'rt_' + rand(32);
    q('INSERT INTO tokens(hash,kind,account_id,device_id,expires) VALUES(?,?,?,?,?)').run(H(at), 'access', accountId, deviceId, nowS() + cfg.accessTtl);
    q('INSERT INTO tokens(hash,kind,account_id,device_id,expires) VALUES(?,?,?,?,?)').run(H(rt), 'refresh', accountId, deviceId, nowS() + cfg.refreshTtl);
    const acc = q('SELECT email FROM accounts WHERE id=?').get(accountId);
    return { accountId, email: acc?.email || null, accessToken: at, accessExpires: (nowS() + cfg.accessTtl) * 1000, refreshToken: rt };
  }
  function auth(req) {
    const m = /^Bearer (\S+)$/.exec(req.headers.authorization || ''); if (!m) return null;
    const t = q("SELECT * FROM tokens WHERE hash=? AND kind='access'").get(H(m[1]));
    if (!t || t.expires < nowS()) return null;
    q('UPDATE devices SET last_seen=? WHERE id=?').run(nowS(), t.device_id);
    return t;
  }
  const err = (status, message, code, extra) => Object.assign(new Error(message), { status, code, ...extra });
  const limit = (key, rule, msg) => { const wait = limiter.take(key, rule, clock() / 1000); if (wait) throw err(429, `${msg}，请 ${wait > 90 ? Math.ceil(wait / 60) + ' 分钟' : wait + ' 秒'}后再试`, 'rate_limited', { retryAfter: wait }); };
  const validEmail = e => typeof e === 'string' && /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e) && e.length < 200;
  const validDev = d => typeof d === 'string' && /^[A-Za-z0-9_-]{6,80}$/.test(d);

  const lic = createLicensing({ q, cfg, clock, err, limit: (k, r, m) => limit(k, r, m) });
  const tel = createTelemetry({ q, cfg, clock, err, limit: (k, r, m) => limit(k, r, m), tx, log });
  const aiSvc = createAI({ q, cfg, clock, err, limit: (k, r, m) => limit(k, r, m), tx, log, devHash: tel.devHash, needAdmin: tel.needAdmin, fetchImpl: opts.aiFetch });
  const bill = createBilling({ q, cfg, clock, err, limit: (k, r, m) => limit(k, r, m), log, tx });
  const routes = {
    ...lic.routes,
    ...tel.routes, // v1.9.2 POST /telemetry（匿名统计上报）、GET /admin/stats（ADMIN_TOKEN）
    ...aiSvc.routes, // v1.9.4 内置 AI：GET /ai/status、POST /ai/run、POST /ai/speech；管理 GET/POST /admin/ai、POST /admin/ai/test
    ...bill.routes, // v1.10 付费与推荐
    'GET /admin/stats': ({ req, ip }) => { tel.needAdmin(req, ip); bill.releaseDueRewards(); return { ...tel.stats(), ai: aiSvc.stats(), billing: bill.routes['GET /admin/billing']({ req }) }; },
    'GET /health': () => ({ ok: true, app: 'zizhuxue-sync', version: API_VERSION, schema: LATEST, time: clock(), publicUrl: cfg.publicUrl || null, mail: mailer.kind, push: !!vapid, license: !!cfg.license.publicKey, telemetry: !!cfg.telemetry }),
    // ① 邮箱 + 一次性验证码
    'POST /auth/email/start': async ({ body, ip }) => {
      const email = String(body.email || '').trim().toLowerCase(); if (!validEmail(email)) throw err(400, '邮箱格式不对');
      const old = q('SELECT sent FROM email_codes WHERE email=?').get(email);
      if (old && nowS() - old.sent < cfg.rate.emailCooldown) throw err(429, `发送太频繁，请 ${cfg.rate.emailCooldown} 秒后再试`, 'rate_limited', { retryAfter: cfg.rate.emailCooldown - (nowS() - old.sent) });
      limit('ip:' + ip, cfg.rate.emailPerIp, '这个网络请求验证码太多次了');
      limit('em:' + email, cfg.rate.emailPerAddress, '这个邮箱请求验证码太多次了');
      const code = String(crypto.randomInt(0, 1e6)).padStart(6, '0');
      const mins = Math.round(cfg.codeTtl / 60);
      const text = `你的「自主学」验证码：${code}（${mins} 分钟内有效）。如果不是你本人操作，请忽略这封邮件。` + (cfg.publicUrl ? `\n${cfg.publicUrl}` : '');
      try { await mailer.send({ to: email, subject: cfg.mail.subject, text }); }
      catch (e) { log('发送验证码邮件失败', e.message); throw err(502, '验证码邮件没发出去，请稍后再试（服务器邮件配置有问题）', 'mail_failed'); }
      q('INSERT OR REPLACE INTO email_codes VALUES(?,?,?,?,?)').run(email, H(email + ':' + code), nowS() + cfg.codeTtl, 0, nowS());
      if (mailer.kind === 'server-log') log(`[邮件模拟] 发给 ${email} 的验证码：${code}（${mins} 分钟内有效；正式版需配置 MAIL_PROVIDER）`);
      return { ok: true, expiresIn: cfg.codeTtl, delivery: mailer.kind };
    },
    'POST /auth/email/verify': ({ body, ip }) => {
      limit('vf:' + ip, cfg.rate.verifyPerIp, '尝试次数太多');
      const email = String(body.email || '').trim().toLowerCase(), code = String(body.code || '').trim();
      if (!validDev(body.deviceId)) throw err(400, '设备 ID 无效');
      const row = q('SELECT * FROM email_codes WHERE email=?').get(email);
      if (!row || row.expires < nowS()) throw err(400, '验证码已过期，请重新获取', 'expired');
      if (row.attempts >= 5) throw err(429, '错误次数太多，请重新获取验证码', 'locked');
      if (row.code_hash !== H(email + ':' + code)) { q('UPDATE email_codes SET attempts=attempts+1 WHERE email=?').run(email); throw err(400, '验证码不对', 'bad_code'); }
      q('DELETE FROM email_codes WHERE email=?').run(email);
      let acc = q('SELECT id FROM accounts WHERE email=?').get(email);
      if (!acc) { acc = { id: 'u_' + rand(12) }; q('INSERT INTO accounts VALUES(?,?,?)').run(acc.id, email, nowS()); }
      return issueTokens(acc.id, body.deviceId, body.deviceName);
    },
    // ② 已绑定设备生成配对码（可显示为二维码），另一台设备输入/扫码即加入同一账户
    'POST /pair/start': ({ user }) => {
      if (!user) throw err(401, '未登录', 'unauth');
      const code = pairCode(); q('INSERT INTO pair_codes(code,account_id,expires) VALUES(?,?,?)').run(code, user.account_id, nowS() + 600);
      log(`[配对] 账户 ${user.account_id} 生成配对码 ${code}`);
      return { code, expiresIn: 600 };
    },
    'POST /pair/claim': ({ body, ip }) => {
      limit('pr:' + ip, cfg.rate.pairPerIp, '尝试次数太多');
      if (!validDev(body.deviceId)) throw err(400, '设备 ID 无效');
      const code = String(body.code || '').toUpperCase().replace(/[^A-Z0-9]/g, '').replace(/^(.{4})(.{4})$/, '$1-$2');
      const row = q('SELECT * FROM pair_codes WHERE code=?').get(code);
      if (!row || row.used || row.expires < nowS()) throw err(400, '配对码无效或已过期', 'bad_pair');
      q('UPDATE pair_codes SET used=1 WHERE code=?').run(code);
      return issueTokens(row.account_id, body.deviceId, body.deviceName);
    },
    // ③ 长期保持登录：访问令牌 1 小时，刷新令牌 365 天（每次刷新轮换并顺延）。
    //    轮换后旧刷新令牌在宽限期内仍可用一次（新令牌在路上丢了时不掉线）；宽限期后再用旧令牌 = 疑似被盗用 → 吊销这台设备的全部令牌。
    'POST /auth/refresh': ({ body }) => {
      const h = H(String(body.refreshToken || ''));
      const r = tx(() => {
        const t = q("SELECT * FROM tokens WHERE hash=? AND kind='refresh'").get(h);
        if (!t || t.expires < nowS()) return { fail: 'refresh_invalid' };
        if (t.rotated_until != null && t.rotated_until < nowS()) { q('DELETE FROM tokens WHERE device_id=?').run(t.device_id); return { fail: 'refresh_reused' }; } // 吊销要提交，不能随异常回滚
        return issueTokens(t.account_id, t.device_id, q('SELECT name FROM devices WHERE id=?').get(t.device_id)?.name, h);
      });
      if (r.fail) throw err(401, '登录已失效，请重新绑定', r.fail);
      return r;
    },
    'POST /auth/logout': ({ user }) => { if (user) q('DELETE FROM tokens WHERE device_id=?').run(user.device_id); return { ok: true }; },
    'GET /devices': ({ user }) => { if (!user) throw err(401, '未登录', 'unauth'); return { devices: q('SELECT id,name,created,last_seen FROM devices WHERE account_id=? ORDER BY last_seen DESC').all(user.account_id), me: user.device_id }; },
    // ④ 增量同步：推本机改动 + 拉游标之后的云端改动（重复推送同一批改动是安全的：合并幂等）
    'POST /sync': ({ user, body }) => {
      if (!user) throw err(401, '未登录', 'unauth');
      const changes = Array.isArray(body.changes) ? body.changes : []; const cursor = Math.max(0, +body.cursor || 0);
      if (changes.length > 2000) throw err(413, '一次改动太多');
      const echo = new Map(), forced = new Map(); let accepted = 0;
      tx(() => {
        for (const c of changes) {
          if (!STORES.has(c.store) || typeof c.id !== 'string' || !c.rec || typeof c.rec !== 'object') continue;
          const row = q('SELECT data FROM records WHERE account_id=? AND store=? AND id=?').get(user.account_id, c.store, c.id);
          const cur = row ? JSON.parse(row.data) : null;
          const merged = mergeRecord(c.store, cur, { ...c.rec, id: c.id });
          const k = c.store + ':' + c.id;
          if (!sameRecord(merged, c.rec)) forced.set(k, { store: c.store, id: c.id, rec: merged }); // 云端有更新的字段：无论游标，都回给这台设备
          if (cur && sameRecord(cur, merged)) { if (!forced.has(k)) echo.set(k, true); continue; }
          const seq = nextSeq(); accepted++;
          q('INSERT INTO records VALUES(?,?,?,?,?) ON CONFLICT(account_id,store,id) DO UPDATE SET data=excluded.data, seq=excluded.seq').run(user.account_id, c.store, c.id, JSON.stringify(merged), seq);
          if (!forced.has(k)) echo.set(k, seq);
        }
      });
      const rows = q('SELECT store,id,data,seq FROM records WHERE account_id=? AND seq>? ORDER BY seq LIMIT ?').all(user.account_id, cursor, cfg.pageSize);
      const out = rows.filter(r => !echo.has(r.store + ':' + r.id) && !forced.has(r.store + ':' + r.id)).map(r => ({ store: r.store, id: r.id, rec: JSON.parse(r.data) })).concat([...forced.values()]);
      const last = rows.length ? rows[rows.length - 1].seq : cursor;
      return { cursor: last, more: rows.length === cfg.pageSize, changes: out, accepted, serverTime: clock() };
    },
    // ⑤ v1.6 用户反馈：不需要登录（绑定了就顺带记账户）；按 IP 限流；截图（JPEG/PNG/WebP，≤1.5MB）存进数据库
    'POST /feedback': async ({ body, ip, user }) => {
      limit('fb:' + ip, cfg.rate.feedbackPerIp, '反馈发得太频繁了');
      const type = String(body.type || ''); if (!['bug', 'idea', 'other'].includes(type)) throw err(400, '反馈类型不对');
      const text = String(body.text || '').trim(); if (text.length < 2 || text.length > 5000) throw err(400, '描述要 2–5000 字');
      const contact = String(body.contact || '').trim().slice(0, 200), page = String(body.page || '').slice(0, 300);
      const env = JSON.stringify({ ...(body.env && typeof body.env === 'object' ? body.env : {}), trail: Array.isArray(body.trail) ? body.trail.slice(-6).map(String) : [] }).slice(0, 4000);
      let shot = null, shotType = null;
      if (body.screenshot) {
        const m = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(String(body.screenshot)); if (!m) throw err(400, '截图格式不对（只收 JPEG/PNG/WebP）');
        shot = Buffer.from(m[2], 'base64'); shotType = m[1]; if (shot.length > 1.5e6) throw err(413, '截图太大（最多 1.5MB）');
      }
      const id = /^fb_[a-z0-9]{4,30}$/.test(String(body.id || '')) ? String(body.id) : 'fb_' + rand(9).toLowerCase().replace(/[^a-z0-9]/g, 'x');
      const exists = q('SELECT id FROM feedback WHERE id=?').get(id); if (exists) return { ok: true, id, duplicate: true }; // 重发同一条：幂等
      q('INSERT INTO feedback(id,created,account_id,type,text,contact,page,env,shot,shot_type,ip_hash) VALUES(?,?,?,?,?,?,?,?,?,?,?)').run(id, nowS(), user?.account_id || null, type, text, contact, page, env, shot, shotType, H('ip:' + ip).slice(0, 16));
      log(`[反馈] ${id} ${type} ${text.slice(0, 40).replace(/\s+/g, ' ')}`);
      if (cfg.feedbackEmail && mailer.kind === 'email') mailer.send({ to: cfg.feedbackEmail, subject: `[自主学反馈] ${type}：${text.slice(0, 30)}`, text: `${text}\n\n联系方式：${contact || '无'}\n页面：${page}\n截图：${shot ? '有（用管理口令查看）' : '无'}\n编号：${id}\n环境：${env}` }).catch(e => log('反馈提醒邮件没发出去', e.message));
      return { ok: true, id };
    },
    // ⑥ v1.8 学习提醒推送（Web Push）。订阅的 endpoint 本身就是“只有这台设备知道”的地址，用它当凭据；不登录也能用（绑定了就顺带记账户）
    'GET /push/vapid': () => { if (!vapid) throw err(404, '这台服务器没开推送（PUSH_ENABLED=0）', 'push_off'); return { publicKey: vapid.publicKey }; },
    'POST /push/subscribe': ({ body, ip, user }) => {
      if (!vapid) throw err(404, '这台服务器没开推送', 'push_off');
      limit('push:' + ip, cfg.rate.pushPerIp, '提醒设置改得太频繁了');
      const sub = body.subscription || {}; const ep = String(sub.endpoint || ''), keys = sub.keys || {};
      let u; try { u = new URL(ep); } catch { throw err(400, '推送地址不对'); }
      if (u.protocol !== 'https:' && !(cfg.push.allowHttp && u.protocol === 'http:')) throw err(400, '推送地址必须是 https');
      if (ep.length > 1000) throw err(400, '推送地址太长');
      let p256, auth; try { p256 = WP.unb64u(keys.p256dh); auth = WP.unb64u(keys.auth); } catch { throw err(400, '推送密钥格式不对'); }
      if (p256.length !== 65 || p256[0] !== 4 || auth.length < 16) throw err(400, '推送密钥格式不对');
      if (parseAt(body.at) == null) throw err(400, '提醒时间格式不对（HH:MM）');
      const tz = typeof body.tz === 'string' && body.tz.length < 60 ? body.tz : null; const off = Math.max(-840, Math.min(840, Math.round(+body.tzOffset || 0)));
      const id = H(ep).slice(0, 32); const old = q('SELECT id FROM push_subs WHERE id=?').get(id);
      const met = /^\d{4}-\d{2}-\d{2}$/.test(body.metDate || '') ? body.metDate : null;
      if (old) q('UPDATE push_subs SET p256dh=?, auth=?, account_id=COALESCE(?,account_id), at=?, tz=?, tz_offset=?, late=?, streak=?, met_date=COALESCE(?,met_date), updated=?, fails=0 WHERE id=?').run(keys.p256dh, keys.auth, user?.account_id || null, body.at, tz, off, body.late ? 1 : 0, Math.max(0, +body.streak || 0), met, nowS(), id);
      else q('INSERT INTO push_subs(id,endpoint,p256dh,auth,account_id,at,tz,tz_offset,late,streak,met_date,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)').run(id, ep, keys.p256dh, keys.auth, user?.account_id || null, body.at, tz, off, body.late ? 1 : 0, Math.max(0, +body.streak || 0), met, nowS(), nowS());
      return { ok: true, id, created: !old };
    },
    'POST /push/unsubscribe': ({ body }) => { const r = q('DELETE FROM push_subs WHERE endpoint=?').run(String(body.endpoint || '')); return { ok: true, removed: r.changes }; },
    // 今天打卡了 / 连续天数变了：告诉服务器，今天就不再提醒
    'POST /push/progress': ({ body }) => {
      const met = /^\d{4}-\d{2}-\d{2}$/.test(body.metDate || '') ? body.metDate : null;
      const r = q('UPDATE push_subs SET met_date=COALESCE(?,met_date), streak=?, updated=? WHERE endpoint=?').run(met, Math.max(0, +body.streak || 0), nowS(), String(body.endpoint || ''));
      if (!r.changes) throw err(404, '没有这个提醒订阅（可能已过期，请在「我的 → 学习提醒」重新打开）', 'no_sub');
      return { ok: true };
    },
    // 发一条测试提醒（设置好后点“试一下”）
    'POST /push/test': async ({ body, ip }) => {
      if (!vapid) throw err(404, '这台服务器没开推送', 'push_off');
      limit('pusht:' + ip, [5, 600], '测试提醒发得太频繁了');
      const row = q('SELECT * FROM push_subs WHERE endpoint=?').get(String(body.endpoint || '')); if (!row) throw err(404, '没有这个提醒订阅', 'no_sub');
      const r = await sendOne(row, { title: '自主学 · 学习提醒', body: '提醒已开启 ✅ 到点我会来叫你学习～', tone: 'test', tag: 'zzx-remind-test', url: './#/', kind: 'test' });
      if (!r.ok) throw err(502, `推送服务返回 ${r.status}${r.gone ? '（订阅已失效，已删除）' : ''}`, 'push_failed');
      return { ok: true, status: r.status };
    },
    // 管理员查看反馈：需要 FEEDBACK_ADMIN_TOKEN；?id= 看单条（含截图 data URL）
    'GET /feedback': ({ req }) => {
      const tok = (/^Bearer (\S+)$/.exec(req.headers.authorization || '') || [])[1] || '';
      if (!cfg.feedbackAdminToken || tok.length !== cfg.feedbackAdminToken.length || !crypto.timingSafeEqual(Buffer.from(tok), Buffer.from(cfg.feedbackAdminToken))) throw err(401, '需要管理口令', 'unauth');
      const u = new URL(req.url, 'http://x'); const id = u.searchParams.get('id');
      const row2 = r => ({ id: r.id, created: r.created * 1000, account: r.account_id, type: r.type, text: r.text, contact: r.contact, page: r.page, env: JSON.parse(r.env || '{}'), hasShot: !!r.shot });
      if (id) { const r = q('SELECT * FROM feedback WHERE id=?').get(id); if (!r) throw err(404, '没有这条反馈'); return { ...row2(r), screenshot: r.shot ? `data:${r.shot_type};base64,${Buffer.from(r.shot).toString('base64')}` : null }; }
      const n = Math.min(200, Math.max(1, +u.searchParams.get('limit') || 50));
      return { items: q('SELECT * FROM feedback ORDER BY created DESC LIMIT ?').all(n).map(row2) };
    },
  };

  async function sendOne(row, payload) {
    let r; try { r = await WP.sendPush({ endpoint: row.endpoint, keys: { p256dh: row.p256dh, auth: row.auth } }, payload, vapid, { fetchImpl: pushFetch, topic: payload.tag?.replace(/[^A-Za-z0-9_-]/g, '').slice(0, 32), urgency: payload.kind === 'late' ? 'high' : 'normal', nowS: nowS() }); }
    catch (e) { r = { status: 0, ok: false, gone: false, text: e.message }; }
    if (r.gone) { q('DELETE FROM push_subs WHERE id=?').run(row.id); log(`[推送] 订阅已失效（${r.status}），已删除 ${row.id}`); }
    else q('UPDATE push_subs SET fails=?, last_status=? WHERE id=?').run(r.ok ? 0 : (row.fails || 0) + 1, r.status, row.id);
    if (!r.ok && !r.gone) log(`[推送] 发送失败 ${row.id}：${r.status} ${String(r.text).slice(0, 120)}`);
    return r;
  }
  /** 检查一遍所有订阅，到点的发提醒。返回本次发出的 [{id, kind, status}]（测试可直接调用 server.pushTick(时刻)） */
  let ticking = false;
  async function pushTick(nowMs = clock()) {
    if (!vapid || ticking) return []; ticking = true; const out = [];
    try {
      for (const row of q('SELECT * FROM push_subs WHERE fails < 20').all()) {
        const d = pushDue(row, nowMs); if (!d) continue;
        q(`UPDATE push_subs SET ${d.kind === 'late' ? 'late_date' : 'sent_date'}=? WHERE id=?`).run(d.date, row.id); // 先记下，失败也不在一分钟后狂发
        const r = await sendOne(row, d.payload); out.push({ id: row.id, kind: d.kind, status: r.status, body: d.payload.body });
      }
    } finally { ticking = false; }
    return out;
  }
  const tickTimer = vapid && cfg.push.tickSeconds > 0 ? setInterval(() => pushTick().catch(e => log('推送检查出错', e)), cfg.push.tickSeconds * 1000) : null; tickTimer?.unref?.();

  const app = cfg.serveApp ? createStatic() : null;
  const anyOrigin = cfg.allowedOrigins.includes('*');
  const corsFor = origin => {
    const h = { 'Access-Control-Allow-Headers': 'Authorization, Content-Type', 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS', 'Access-Control-Max-Age': '86400' };
    if (anyOrigin) return { ...h, 'Access-Control-Allow-Origin': '*' };
    if (origin && cfg.allowedOrigins.includes(origin)) return { ...h, 'Access-Control-Allow-Origin': origin, Vary: 'Origin' };
    return { Vary: 'Origin' };
  };
  const clientIp = req => (cfg.trustProxy && String(req.headers['x-forwarded-for'] || '').split(',')[0].trim()) || req.socket.remoteAddress || '?';
  const deployJs = () => { // v1.9.2：云同步开关（WEB_SYNC）和统计 / 反馈地址分开；统计、反馈总是报到本服务器
    const api = cfg.publicUrl ? cfg.publicUrl.replace(/\/+$/, '') + '/api/v1/' : '/api/v1/', sync = cfg.webSync !== false;
    return `export const SYNC_AVAILABLE = ${sync};\nexport const SYNC_URL = ${JSON.stringify(sync && cfg.publicUrl ? api : '')};\nexport const API_BASE = ${JSON.stringify(api)};\nexport const TELEMETRY_URL = ${JSON.stringify(cfg.telemetry === false ? '' : api + 'telemetry')};\nexport const FEEDBACK_URL = ${JSON.stringify(api + 'feedback')};\nexport const FEEDBACK_EMAIL = ${JSON.stringify(cfg.feedbackEmail || '')};\nexport const AI_URL = ${JSON.stringify(api + 'ai/')};\nexport const BILLING_URL = ${JSON.stringify(api + 'billing/')};\n`;
  };
  // v1.9.2 匿名统计、提交反馈：不用登录、不带 cookie，任何网页（GitHub Pages、App 客户端 app:// / https://localhost）都能发，靠限流防刷
  const PUBLIC_POST = new Set(['/api/v1/telemetry', '/api/v1/feedback']);
  const publicCors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type', 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Access-Control-Max-Age': '86400' };

  const handler = async (req, res) => {
    const url = new URL(req.url, 'http://x');
    if (req.method === 'GET' && url.pathname === '/healthz') { // 给 Docker / 负载均衡用：数据库可读才算健康
      try { q('SELECT 1').get(); res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }).end(JSON.stringify({ ok: true, schema: LATEST })); }
      catch (e) { res.writeHead(503, { 'Content-Type': 'application/json' }).end(JSON.stringify({ ok: false, error: e.message })); }
      return;
    }
    // v1.9.2 管理看板（极简单页；数据从 /api/v1/admin/stats 拿，要 ADMIN_TOKEN）。不进搜索引擎、不缓存
    if (req.method === 'GET' && /^\/admin\/stats\/?$/.test(url.pathname)) {
      res.writeHead(cfg.adminToken ? 200 : 404, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store', 'X-Robots-Tag': 'noindex', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer', 'Content-Security-Policy': "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; img-src 'self'; manifest-src 'self'; base-uri 'none'; form-action 'none'" });
      res.end(cfg.adminToken ? DASHBOARD_HTML : '<!doctype html><meta charset="utf-8"><p>管理看板没开：请在服务器 .env 里设置 ADMIN_TOKEN 后重启。</p>'); return;
    }
    // v1.9.3 看板加到手机主屏：manifest 和图标（不需要口令，里面没有任何数据）
    if (req.method === 'GET' && url.pathname === '/admin/manifest.webmanifest') { res.writeHead(200, { 'Content-Type': 'application/manifest+json; charset=utf-8', 'Cache-Control': 'public, max-age=3600', 'X-Robots-Tag': 'noindex' }).end(DASHBOARD_MANIFEST); return; }
    { const ic = /^\/admin\/(icon-192|icon-512|apple-touch-icon)\.png$/.exec(url.pathname);
      if (req.method === 'GET' && ic) { let b; try { b = fs.readFileSync(path.join(import.meta.dirname, 'admin', ic[1] + '.png')); } catch { res.writeHead(404).end(); return; } res.writeHead(200, { 'Content-Type': 'image/png', 'Cache-Control': 'public, max-age=86400', 'X-Robots-Tag': 'noindex' }).end(b); return; } }
    // 同端口提供应用时，告诉前端“这里有同步服务器”（静态部署时这个文件是 false → 云同步显示“未开通”）
    if (app && req.method === 'GET' && url.pathname.endsWith('/js/deploy.js')) { res.writeHead(200, { 'Content-Type': 'text/javascript; charset=utf-8', 'Cache-Control': 'no-cache' }).end(deployJs()); return; }
    if (!url.pathname.startsWith('/api/v1/')) { if (app) return app.emit('request', req, res); res.writeHead(404).end(); return; }
    const origin = req.headers.origin;
    const sameOrigin = !!origin && [`http://${req.headers.host}`, `https://${req.headers.host}`, cfg.publicUrl && new URL(cfg.publicUrl).origin].includes(origin); // 同端口提供的网页自己调用接口
    const isPublic = PUBLIC_POST.has(url.pathname) && (req.method === 'POST' || (req.method === 'OPTIONS' && String(req.headers['access-control-request-method'] || 'POST').toUpperCase() === 'POST'));
    const isAi = url.pathname.startsWith('/api/v1/ai/'); // v1.9.4 内置 AI：本站、ALLOWED_ORIGINS、App 客户端（app:// / https://localhost / capacitor://）
    const aiStatus = isAi && url.pathname === '/api/v1/ai/status' && (req.method === 'GET' || req.method === 'OPTIONS'); // 状态谁都能看（不含密钥；不允许的网页看到的是“关着”）
    const cors = sameOrigin ? { Vary: 'Origin' } : aiStatus ? { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET, OPTIONS', 'Access-Control-Max-Age': '86400' } : isAi ? (origin && aiSvc.originOk(origin, false) ? { 'Access-Control-Allow-Origin': origin, 'Access-Control-Allow-Headers': 'Content-Type', 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS', 'Access-Control-Max-Age': '86400', Vary: 'Origin' } : { Vary: 'Origin' }) : isPublic ? publicCors : corsFor(origin);
    if (req.method === 'OPTIONS') { res.writeHead(origin && !sameOrigin && !cors['Access-Control-Allow-Origin'] ? 403 : 204, cors).end(); return; }
    const send = (st, obj, extra = {}) => { res.writeHead(st, { ...cors, ...extra, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(obj)); };
    const ip = clientIp(req);
    try {
      if (origin && !sameOrigin && !cors['Access-Control-Allow-Origin']) throw err(403, '这个网页地址没有被允许访问同步服务器（ALLOWED_ORIGINS）', 'origin_denied');
      limit('api:' + ip, cfg.rate.apiPerIp, '请求太频繁');
      const fn = routes[req.method + ' ' + url.pathname.slice(7)]; if (!fn) throw err(404, '没有这个接口');
      let body = {};
      if (req.method === 'POST') {
        const chunks = []; let n = 0; for await (const ch of req) { n += ch.length; if (n > cfg.maxBodyMb * 1e6) throw err(413, '数据太大'); chunks.push(ch); }
        try { body = chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}; } catch { throw err(400, '请求格式不对', 'bad_json'); }
      }
      const out = await fn({ req, body, ip, user: auth(req), origin, sameOrigin });
      if (out?.__raw) { res.writeHead(200, { ...cors, ...(out.__raw.headers || {}), 'Content-Type': out.__raw.type, 'Content-Length': String(out.__raw.body.length), 'Cache-Control': 'no-store' }); res.end(out.__raw.body); return; } // v1.9.4 AI 语音（音频）
      send(200, out);
    } catch (e) { if (!e.status) log('同步服务器错误', e); send(e.status || 500, { error: e.status ? e.message : '服务器内部错误', code: e.code || 'error' }, e.retryAfter ? { 'Retry-After': String(e.retryAfter) } : {}); }
  };
  const server = http.createServer(handler);
  Object.assign(server, { db, config: cfg, migrated: mig, limiter, mailer, pushTick, vapid, telemetry: tel, ai: aiSvc, billing: bill });
  server.on('close', () => { if (tickTimer) clearInterval(tickTimer); try { db.close(); } catch { } });
  return server;
}

if (process.argv[1] === import.meta.filename) {
  loadDotEnv(path.join(import.meta.dirname, '.env'));
  const cfg = loadConfig(); const port = +process.argv[2] || cfg.port;
  for (const w of checkConfig(cfg)) console.warn('⚠️ ', w);
  const srv = createSyncServer();
  srv.listen(port, cfg.host, () => console.log(`自主学 同步服务器已启动：http://localhost:${port}/  接口 /api/v1/  健康检查 /healthz  数据库 ${cfg.dbFile}（结构版本 ${LATEST}）`));
  const stop = () => { console.log('正在关闭…'); srv.close(() => process.exit(0)); setTimeout(() => process.exit(0), 5000).unref(); };
  process.on('SIGTERM', stop); process.on('SIGINT', stop);
}
