// 数据库迁移：用 SQLite 的 PRAGMA user_version 记录已执行到第几步。每步只执行一次，按顺序执行，在事务里完成。
// 加新字段/新表时：在 MIGRATIONS 末尾追加一步，不要改已有的步骤。
import { MIGRATION as LICENSE_MIGRATION, MIGRATION_6 } from './licensing.js';
import { MIGRATION_7 } from './telemetry.js';
export const MIGRATIONS = [
  // 1：v1.2 原型的表结构（旧数据库 user_version=0，这些语句都是 IF NOT EXISTS，可安全重放）
  `CREATE TABLE IF NOT EXISTS accounts(id TEXT PRIMARY KEY, email TEXT UNIQUE, created INT);
   CREATE TABLE IF NOT EXISTS devices(id TEXT PRIMARY KEY, account_id TEXT, name TEXT, created INT, last_seen INT);
   CREATE TABLE IF NOT EXISTS email_codes(email TEXT PRIMARY KEY, code_hash TEXT, expires INT, attempts INT, sent INT);
   CREATE TABLE IF NOT EXISTS pair_codes(code TEXT PRIMARY KEY, account_id TEXT, expires INT, used INT DEFAULT 0, attempts INT DEFAULT 0);
   CREATE TABLE IF NOT EXISTS tokens(hash TEXT PRIMARY KEY, kind TEXT, account_id TEXT, device_id TEXT, expires INT);
   CREATE TABLE IF NOT EXISTS records(account_id TEXT, store TEXT, id TEXT, data TEXT, seq INT, PRIMARY KEY(account_id, store, id));
   CREATE INDEX IF NOT EXISTS rec_seq ON records(account_id, seq);
   CREATE TABLE IF NOT EXISTS counters(k TEXT PRIMARY KEY, v INT);`,
  // 2（v1.3）：刷新令牌轮换宽限期 + 常用查询索引
  `ALTER TABLE tokens ADD COLUMN rotated_until INT;
   CREATE INDEX IF NOT EXISTS tok_dev ON tokens(device_id);
   CREATE INDEX IF NOT EXISTS dev_acc ON devices(account_id);`,
  // 3（v1.6）：用户反馈（bug/建议/其他），截图以 BLOB 存
  `CREATE TABLE IF NOT EXISTS feedback(id TEXT PRIMARY KEY, created INT, account_id TEXT, type TEXT, text TEXT, contact TEXT, page TEXT, env TEXT, shot BLOB, shot_type TEXT, ip_hash TEXT);
   CREATE INDEX IF NOT EXISTS fb_created ON feedback(created);`,
  // 4（v1.8）：学习提醒推送订阅（每台设备一条，按 endpoint 去重）+ 通用键值（存自动生成的 VAPID 密钥）
  `CREATE TABLE IF NOT EXISTS push_subs(id TEXT PRIMARY KEY, endpoint TEXT, p256dh TEXT, auth TEXT, account_id TEXT, at TEXT, tz TEXT, tz_offset INT, late INT, streak INT,
     met_date TEXT, sent_date TEXT, late_date TEXT, created INT, updated INT, fails INT DEFAULT 0, last_status INT);
   CREATE TABLE IF NOT EXISTS kv(k TEXT PRIMARY KEY, v TEXT);`,
  // 5（v1.9）：授权——激活码绑定账户、设备名额、试用次数（按账户 / 设备）、订阅
  LICENSE_MIGRATION,
  // 6（v1.9 补）：试用记录加计次时间日志
  MIGRATION_6,
  // 7（v1.9.2）：匿名使用统计（telemetry 事件表 + telemetry_devices 每台匿名设备一行）
  MIGRATION_7,
];
export const LATEST = MIGRATIONS.length;

export function migrate(db, log = () => { }) {
  const cur = db.prepare('PRAGMA user_version').get().user_version;
  for (let v = cur; v < MIGRATIONS.length; v++) {
    db.exec('BEGIN IMMEDIATE');
    try { db.exec(MIGRATIONS[v]); db.exec(`PRAGMA user_version = ${v + 1}`); db.exec('COMMIT'); log(`数据库迁移：${v} → ${v + 1}`); }
    catch (e) { db.exec('ROLLBACK'); throw new Error(`数据库迁移到第 ${v + 1} 步失败：${e.message}`); }
  }
  return { from: cur, to: MIGRATIONS.length };
}
