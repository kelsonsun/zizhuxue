// v1.10 付费与好友推荐。价格、邀请、有效注册、优惠码、付款/退款、邀请人满 30 天发放奖励。
// 付款通道（苹果 / Google Play / Stripe）和短信默认都未开通：做成可接入适配层，绝不假装能收款或能发短信。
// 配置默认关闭，不影响现有免费使用。看板可打开总开关、改价格表、手工登记付款和退款。
import crypto from 'node:crypto';
import * as C from '../public/js/licensecode.js';
import * as P from '../public/js/pricetable.js';

export const MIGRATION_9 = `
  CREATE TABLE IF NOT EXISTS price_table(
    region TEXT PRIMARY KEY, name TEXT, currency TEXT, symbol TEXT, decimals INT,
    year TEXT, month TEXT, year_cents INT, month_cents INT, store_tax INT DEFAULT 0, note TEXT, sort INT, updated INT);
  CREATE TABLE IF NOT EXISTS billing_users(
    id TEXT PRIMARY KEY, phone_hash TEXT UNIQUE, phone_tail TEXT,
    invited_by TEXT, invite_used TEXT, device_id TEXT, pay_account TEXT,
    phone_verified INT DEFAULT 0, phone_verified_at INT, registered_at INT,
    checkin_n INT DEFAULT 0, valid INT DEFAULT 0, valid_at INT, invalid_reason TEXT,
    plan TEXT, exp_day INT, created INT, updated INT);
  CREATE INDEX IF NOT EXISTS bu_device ON billing_users(device_id);
  CREATE INDEX IF NOT EXISTS bu_inviter ON billing_users(invited_by);
  CREATE TABLE IF NOT EXISTS invite_codes(
    code TEXT PRIMARY KEY, user_id TEXT, created INT, disabled INT DEFAULT 0);
  CREATE INDEX IF NOT EXISTS ic_user ON invite_codes(user_id);
  CREATE TABLE IF NOT EXISTS phone_codes(
    phone_hash TEXT PRIMARY KEY, code_hash TEXT, expires INT, attempts INT, sent INT, purpose TEXT);
  CREATE TABLE IF NOT EXISTS billing_tokens(
    hash TEXT PRIMARY KEY, user_id TEXT, device_id TEXT, expires INT);
  CREATE INDEX IF NOT EXISTS bt_user ON billing_tokens(user_id);
  CREATE TABLE IF NOT EXISTS coupons(
    code TEXT PRIMARY KEY, kind TEXT, owner_id TEXT, source_user_id TEXT, order_id TEXT,
    percent_off INT DEFAULT 20, status TEXT, granted_at INT, redeemed_at INT, cancelled_at INT, note TEXT, created INT, updated INT);
  CREATE INDEX IF NOT EXISTS cp_owner ON coupons(owner_id);
  CREATE TABLE IF NOT EXISTS orders(
    id TEXT PRIMARY KEY, user_id TEXT, period TEXT, region TEXT, currency TEXT,
    list_cents INT, pay_cents INT, percent_off INT DEFAULT 0, coupon_code TEXT,
    provider TEXT, provider_ref TEXT, pay_account TEXT, status TEXT,
    paid_at INT, refunded_at INT, exp_day INT, license_serial INT, license_code TEXT, note TEXT, created INT, updated INT);
  CREATE INDEX IF NOT EXISTS od_user ON orders(user_id);
  CREATE INDEX IF NOT EXISTS od_status ON orders(status);
  CREATE TABLE IF NOT EXISTS checkins(
    user_id TEXT, day TEXT, n INT, goal INT, met INT, reported INT, PRIMARY KEY(user_id, day));
  CREATE TABLE IF NOT EXISTS billing_events(
    id INTEGER PRIMARY KEY AUTOINCREMENT, at INT, kind TEXT, user_id TEXT, ref TEXT, detail TEXT);
`;

const AB = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
const H = s => crypto.createHash('sha256').update(s).digest('hex');
const rand = (n = 16) => crypto.randomBytes(n).toString('base64url');
const idOf = p => p + '_' + rand(9);
const codeOf = (prefix, n = 6) => {
  const b = crypto.randomBytes(n); let s = '';
  for (let i = 0; i < n; i++) s += AB[b[i] % AB.length];
  return prefix + s;
};

/** 把用户输入的手机号规范成 E.164；不行返回 '' */
export function normalizePhone(raw) {
  let s = String(raw || '').trim().replace(/[\s\-().]/g, '');
  if (s.startsWith('00')) s = '+' + s.slice(2);
  if (/^1[3-9]\d{9}$/.test(s)) s = '+86' + s;
  if (/^86[1][3-9]\d{9}$/.test(s)) s = '+' + s;
  if (!/^\+[1-9]\d{6,14}$/.test(s)) return '';
  return s;
}
export const maskPhone = e164 => {
  const d = String(e164 || '').replace(/\D/g, '');
  return d.length >= 4 ? '…' + d.slice(-4) : '…';
};

/** 注册日（含）起 firstWeekDays 个日历日的日期列表（YYYY-MM-DD，按 UTC 日或给定时区偏移分钟） */
export function firstWeekDates(regMs, days = 7, tzMin = 0) {
  const n = Math.max(1, Math.min(30, +days || 7));
  const start = new Date(regMs + tzMin * 60000);
  const ymd = (d) => d.toISOString().slice(0, 10);
  const out = [];
  for (let i = 0; i < n; i++) {
    const d = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth(), start.getUTCDate() + i));
    out.push(ymd(d));
  }
  return out;
}

export function seedPriceRows(nowS, table = P.DEFAULT_PRICES) {
  return table.map((r, i) => ({
    region: r.region, name: r.name, currency: r.currency, symbol: r.symbol, decimals: r.decimals,
    year: r.year, month: r.month, year_cents: r.yearCents, month_cents: r.monthCents,
    store_tax: r.storeTax ? 1 : 0, note: r.note || '', sort: i, updated: nowS,
  }));
}

export function rowFromDb(r) {
  return { region: r.region, name: r.name, currency: r.currency, symbol: r.symbol, decimals: r.decimals,
    year: r.year, month: r.month, yearCents: r.year_cents, monthCents: r.month_cents, storeTax: !!r.store_tax, note: r.note || '' };
}

const defaultRules = {
  enabled: false,
  firstWeekDays: 7,
  firstWeekCheckins: 3,
  checkinGoal: 10,
  rewardHoldDays: P.REWARD_HOLD_DAYS,
  discountPercent: P.DISCOUNT_PERCENT,
  tzOffsetMin: 0, // 首周日期按用户上报的本地日期，不按服务器时区猜
};

export function createBilling({ q, cfg, clock, err, limit, log = () => { }, tx }) {
  const B = { ...defaultRules, ...(cfg.billing || {}) };
  const nowS = () => Math.floor(clock() / 1000);
  const todayYmd = (tzMin = 0) => new Date(clock() + tzMin * 60000).toISOString().slice(0, 10);
  const ev = (kind, userId, ref, detail) => q('INSERT INTO billing_events(at,kind,user_id,ref,detail) VALUES(?,?,?,?,?)').run(nowS(), kind, userId || '', ref || '', typeof detail === 'string' ? detail : JSON.stringify(detail || {}));
  const kvGet = (k, d) => { const r = q('SELECT v FROM kv WHERE k=?').get(k); return r ? r.v : d; };
  const kvSet = (k, v) => q('INSERT INTO kv(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v').run(k, String(v));
  const num = (v, d) => { const n = +v; return Number.isFinite(n) ? n : d; };
  const bool = v => v === true || v === 1 || v === '1' || v === 'true';

  function rules() {
    return {
      enabled: bool(kvGet('billing.enabled', B.enabled ? '1' : '0')),
      firstWeekDays: Math.max(1, Math.min(30, num(kvGet('billing.firstWeekDays', B.firstWeekDays), B.firstWeekDays))),
      firstWeekCheckins: Math.max(1, Math.min(30, num(kvGet('billing.firstWeekCheckins', B.firstWeekCheckins), B.firstWeekCheckins))),
      checkinGoal: Math.max(1, Math.min(100, num(kvGet('billing.checkinGoal', B.checkinGoal), B.checkinGoal))),
      rewardHoldDays: Math.max(0, Math.min(365, num(kvGet('billing.rewardHoldDays', B.rewardHoldDays), B.rewardHoldDays))),
      discountPercent: Math.max(0, Math.min(90, num(kvGet('billing.discountPercent', B.discountPercent), B.discountPercent))),
      smsProvider: (cfg.billing?.smsProvider || 'off'),
      payProvider: (cfg.billing?.payProvider || 'none'),
    };
  }
  function needOn() { if (!rules().enabled) throw err(503, '付费与推荐功能尚未开放（可在管理看板打开）。现在所有学习功能仍免费。', 'billing_off'); }

  function pepper() {
    let p = cfg.billing?.phonePepper || kvGet('billing.pepper', '');
    if (!p) { p = crypto.randomBytes(16).toString('hex'); kvSet('billing.pepper', p); }
    return p;
  }
  const phoneHash = e164 => H('zzx-phone-v1:' + pepper() + ':' + e164);

  function ensurePrices() {
    if (!q('SELECT 1 FROM price_table LIMIT 1').get()) {
      const ins = q('INSERT INTO price_table(region,name,currency,symbol,decimals,year,month,year_cents,month_cents,store_tax,note,sort,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)');
      for (const r of seedPriceRows(nowS())) ins.run(r.region, r.name, r.currency, r.symbol, r.decimals, r.year, r.month, r.year_cents, r.month_cents, r.store_tax, r.note, r.sort, r.updated);
    }
  }
  function priceTable() {
    ensurePrices();
    return q('SELECT * FROM price_table ORDER BY sort, region').all().map(rowFromDb);
  }
  const rowOf = region => P.rowOf(priceTable(), region);

  function admin(req) {
    const want = cfg.adminToken || cfg.billing?.adminToken || '';
    if (!want) throw err(404, '管理看板没开：服务器没设置 ADMIN_TOKEN', 'admin_off');
    const u = new URL(req.url, 'http://x');
    const tok = (/^Bearer (\S+)$/.exec(req.headers.authorization || '') || [])[1] || u.searchParams.get('token') || '';
    if (!tok || tok.length !== want.length || !crypto.timingSafeEqual(Buffer.from(tok), Buffer.from(want))) throw err(401, '需要管理口令', 'unauth');
  }

  function userOfToken(req) {
    const m = /^Bearer (\S+)$/.exec(req.headers.authorization || ''); if (!m) return null;
    const t = q('SELECT * FROM billing_tokens WHERE hash=?').get(H(m[1]));
    if (!t || t.expires < nowS()) return null;
    const u = q('SELECT * FROM billing_users WHERE id=?').get(t.user_id); return u || null;
  }
  const needUser = req => { const u = userOfToken(req); if (!u) throw err(401, '请先完成手机验证', 'unauth'); return u; };

  function issueToken(userId, deviceId) {
    const tok = rand(24), exp = nowS() + 120 * 86400;
    q('DELETE FROM billing_tokens WHERE user_id=? AND device_id=?').run(userId, deviceId || '');
    q('INSERT INTO billing_tokens VALUES(?,?,?,?)').run(H(tok), userId, deviceId || '', exp);
    return { token: tok, expires: exp * 1000 };
  }

  function privateKey() {
    const hex = (cfg.license?.privateKey || cfg.billing?.privateKey || '').trim();
    if (/^[0-9a-f]{64}$/i.test(hex)) return C.fromHex(hex);
    return null;
  }
  function nextSerial() {
    const n = Math.max(
      +(kvGet('billing.serial', '1000000')),
      (q('SELECT MAX(license_serial) n FROM orders').get()?.n || 0) + 1,
      (q('SELECT MAX(serial) n FROM licenses').get()?.n || 0) + 1,
    );
    kvSet('billing.serial', n + 1);
    return n;
  }

  /** 付款成功后：延长会员、尽量签发激活码、处理优惠码与邀请人待发放奖励 */
  function fulfill(order, { licenseCode } = {}) {
    let u = q('SELECT * FROM billing_users WHERE id=?').get(order.user_id);
    const days = order.period === 'month' ? P.MONTH_DAYS : P.YEAR_DAYS;
    const today = C.localDay(clock()); // 用“今天”的日历日（测试可拨钟）
    const cur = u.exp_day && u.exp_day >= today ? u.exp_day : today;
    const expDay = cur + days;
    let serial = order.license_serial || null, code = licenseCode || order.license_code || '';
    const seed = privateKey();
    if (!code && seed) {
      serial = nextSerial();
      code = C.makeCode(seed, { plan: 'basic', expires: C.ymdOf(expDay), serial });
    }
    if (code && !serial) {
      try { const r = C.readCode(code, C.fromHex(cfg.license?.publicKey || '') || undefined); if (r.ok) serial = r.serial; } catch { }
    }
    q("UPDATE billing_users SET plan=?, exp_day=?, pay_account=COALESCE(NULLIF(?, ''),pay_account), updated=? WHERE id=?").run('basic', expDay, order.pay_account || '', nowS(), u.id);
    if (serial && code) {
      const pub = cfg.license?.publicKey; let parsed = null;
      try { parsed = pub ? C.readCode(code, C.fromHex(pub)) : { ok: true, plan: 'basic', expDay, serial }; } catch { parsed = { ok: true, plan: 'basic', expDay, serial }; }
      if (parsed?.ok) {
        const row = q('SELECT * FROM licenses WHERE serial=?').get(serial);
        if (!row) q('INSERT INTO licenses(serial,plan,exp_day,account_id,activated,note) VALUES(?,?,?,?,?,?)').run(serial, parsed.plan || 'basic', parsed.expDay || expDay, null, nowS(), 'order:' + order.id);
        // 没有云账户也能先把码发给用户在本机激活
      }
    }
    q('UPDATE orders SET status=?, paid_at=?, exp_day=?, license_serial=?, license_code=?, updated=? WHERE id=?').run('paid', nowS(), expDay, serial, code || '', nowS(), order.id);
    if (order.coupon_code) {
      const cp = q('SELECT * FROM coupons WHERE code=?').get(order.coupon_code);
      if (cp) q('UPDATE coupons SET status=?, redeemed_at=?, order_id=?, updated=? WHERE code=?').run('redeemed', nowS(), order.id, nowS(), cp.code);
    }
    // 同一付款账户不算有效邀请：记录原因、不发邀请人奖励（优惠码若已用于本单，价已记下，不自动改价）
    const acc = String(order.pay_account || '').trim();
    if (acc && payTaken(acc, u.id) && u.invited_by) {
      q("UPDATE billing_users SET invalid_reason=COALESCE(invalid_reason,'duplicate_pay'), valid=0, updated=? WHERE id=?").run(nowS(), u.id);
      ev('invalid_reg', u.id, u.invite_used || '', { reason: 'duplicate_pay', payAccount: acc.slice(0, 8) });
      u = q('SELECT * FROM billing_users WHERE id=?').get(u.id);
    }
    // 被邀请人付款：给邀请人生成一张待发放的 8 折券（满 30 天且未退款才发放）
    if (u.invited_by && u.valid && u.invalid_reason !== 'duplicate_pay') {
      const existing = q("SELECT * FROM coupons WHERE kind='referral_inviter' AND source_user_id=? AND owner_id=?").get(u.id, u.invited_by);
      if (!existing) {
        const rc = uniqueCoupon();
        q('INSERT INTO coupons(code,kind,owner_id,source_user_id,order_id,percent_off,status,note,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?)')
          .run(rc, 'referral_inviter', u.invited_by, u.id, order.id, rules().discountPercent, 'pending', '好友付款后满 ' + rules().rewardHoldDays + ' 天且未退款才发放', nowS(), nowS());
        ev('reward_pending', u.invited_by, rc, { invitee: u.id, order: order.id });
      }
    }
    ev('order_paid', u.id, order.id, { period: order.period, payCents: order.pay_cents, serial, hasCode: !!code });
    return q('SELECT * FROM orders WHERE id=?').get(order.id);
  }

  function uniqueCoupon() {
    for (let i = 0; i < 20; i++) { const c = codeOf('ZZXC-'); if (!q('SELECT 1 FROM coupons WHERE code=?').get(c)) return c; }
    throw err(500, '优惠码生成失败');
  }
  function uniqueInvite() {
    for (let i = 0; i < 20; i++) { const c = codeOf('ZZXF-'); if (!q('SELECT 1 FROM invite_codes WHERE code=?').get(c)) return c; }
    throw err(500, '邀请码生成失败');
  }

  function releaseDueRewards() {
    const r = rules(); const hold = r.rewardHoldDays * 86400;
    const due = q("SELECT c.*, o.paid_at, o.status AS ostatus, o.refunded_at FROM coupons c JOIN orders o ON o.id=c.order_id WHERE c.kind='referral_inviter' AND c.status='pending'").all();
    let n = 0;
    for (const c of due) {
      if (c.ostatus === 'refunded' || c.refunded_at) {
        q("UPDATE coupons SET status='cancelled', cancelled_at=?, note=?, updated=? WHERE code=?").run(nowS(), '好友已退款，邀请奖励取消', nowS(), c.code);
        ev('reward_cancelled', c.owner_id, c.code, { reason: 'refund' });
        continue;
      }
      if (c.ostatus === 'paid' && c.paid_at && nowS() - c.paid_at >= hold) {
        q("UPDATE coupons SET status='granted', granted_at=?, updated=? WHERE code=?").run(nowS(), nowS(), c.code);
        ev('reward_granted', c.owner_id, c.code, { holdDays: r.rewardHoldDays });
        n++;
      }
    }
    return n;
  }

  function cancelRewardsForOrder(orderId, reason) {
    const rows = q("SELECT * FROM coupons WHERE order_id=? AND kind='referral_inviter'").all(orderId);
    for (const c of rows) {
      if (c.status === 'redeemed') {
        q("UPDATE coupons SET status='clawback', cancelled_at=?, note=?, updated=? WHERE code=?").run(nowS(), '好友退款，已用掉的邀请奖励需手工处理：' + (reason || ''), nowS(), c.code);
        ev('reward_clawback', c.owner_id, c.code, { order: orderId, reason });
      } else {
        q("UPDATE coupons SET status='cancelled', cancelled_at=?, note=?, updated=? WHERE code=?").run(nowS(), '好友退款，邀请奖励取消', nowS(), c.code);
        ev('reward_cancelled', c.owner_id, c.code, { order: orderId, reason });
      }
    }
  }

  function evaluateValid(u) {
    if (u.valid) return u;
    const r = rules();
    if (!u.registered_day) u.registered_day = kvGet('billing.regday.' + u.id, null);
    const dates = firstWeekDates((u.registered_at || 0) * 1000, r.firstWeekDays, 0);
    const startDay = u.registered_day || dates[0];
    const window = [];
    const t0 = new Date(startDay + 'T00:00:00Z');
    for (let i = 0; i < r.firstWeekDays; i++) {
      const d = new Date(t0.getTime() + i * 864e5);
      window.push(d.toISOString().slice(0, 10));
    }
    const rows = q('SELECT * FROM checkins WHERE user_id=?').all(u.id);
    const met = rows.filter(x => x.met && window.includes(x.day)).length;
    q('UPDATE billing_users SET checkin_n=?, updated=? WHERE id=?').run(met, nowS(), u.id);
    if (u.invalid_reason) return q('SELECT * FROM billing_users WHERE id=?').get(u.id);
    if (met >= r.firstWeekCheckins && u.phone_verified && u.invited_by) {
      const coupon = uniqueCoupon();
      q("INSERT INTO coupons(code,kind,owner_id,source_user_id,percent_off,status,note,created,updated) VALUES(?,?,?,?,?,?,'有效注册后生成，付款享 8 折（不与其他优惠叠加）',?,?)")
        .run(coupon, 'referral_invitee', u.id, u.invited_by, r.discountPercent, 'issued', nowS(), nowS());
      q('UPDATE billing_users SET valid=1, valid_at=?, checkin_n=?, updated=? WHERE id=?').run(nowS(), met, nowS(), u.id);
      ev('valid_reg', u.id, coupon, { checkins: met, inviter: u.invited_by });
    }
    return q('SELECT * FROM billing_users WHERE id=?').get(u.id);
  }

  function viewUser(u, { withSecrets = false } = {}) {
    if (!u) return null;
    releaseDueRewards();
    const u2 = evaluateValid(u);
    const invites = q('SELECT code, created, disabled FROM invite_codes WHERE user_id=?').all(u2.id);
    const coupons = q('SELECT code, kind, percent_off, status, granted_at, redeemed_at, note, created FROM coupons WHERE owner_id=? ORDER BY created').all(u2.id);
    const orders = q('SELECT id, period, region, currency, list_cents, pay_cents, percent_off, coupon_code, status, paid_at, refunded_at, exp_day, license_serial, created FROM orders WHERE user_id=? ORDER BY created').all(u2.id);
    const mine = q('SELECT COUNT(*) n FROM billing_users WHERE invited_by=?').get(u2.id).n;
    const validN = q('SELECT COUNT(*) n FROM billing_users WHERE invited_by=? AND valid=1').get(u2.id).n;
    const lastPaid = orders.filter(o => o.status === 'paid').slice(-1)[0];
    const licenseCode = withSecrets ? (lastPaid ? q('SELECT license_code FROM orders WHERE id=?').get(lastPaid.id)?.license_code : '') : undefined;
    return {
      id: u2.id, phoneTail: u2.phone_tail, invitedBy: u2.invited_by || null, inviteUsed: u2.invite_used || null,
      phoneVerified: !!u2.phone_verified, valid: !!u2.valid, validAt: u2.valid_at ? u2.valid_at * 1000 : null,
      invalidReason: u2.invalid_reason || null, checkins: u2.checkin_n, plan: u2.plan || null,
      expDay: u2.exp_day || null, expires: u2.exp_day ? C.ymdOf(u2.exp_day) : null,
      invites, coupons, orders, invited: mine, invitedValid: validN,
      licenseCode: licenseCode || undefined,
    };
  }

  function inviteByCode(code) {
    const c = String(code || '').toUpperCase().replace(/\s+/g, '');
    if (!c) return null;
    return q('SELECT * FROM invite_codes WHERE code=? AND disabled=0').get(c);
  }

  function deviceTaken(deviceId, exceptId) {
    if (!deviceId) return false;
    const r = q('SELECT id, invited_by, valid FROM billing_users WHERE device_id=? AND id<>?').get(deviceId, exceptId || '');
    return !!r;
  }
  function payTaken(payAccount, exceptId) {
    if (!payAccount) return false;
    const r = q('SELECT id FROM billing_users WHERE pay_account=? AND id<>?').get(payAccount, exceptId || '');
    return !!r;
  }

  // ---- SMS / Pay adapters ----
  async function sendSms(e164, code) {
    const p = rules().smsProvider;
    if (p === 'off' || !p) throw err(503, '短信验证尚未开通，不能发送验证码。开通前不会向任何短信服务注册或付费。', 'sms_off');
    if (p === 'console') {
      log(`[短信模拟] 发给 ${maskPhone(e164)} 的验证码：${code}（仅测试 / 日志，不是真短信）`);
      kvSet('billing.lastOtp.' + phoneHash(e164), JSON.stringify({ code, at: nowS(), phoneTail: maskPhone(e164) }));
      return { ok: true, via: 'console' };
    }
    if (p === 'http') {
      const url = cfg.billing?.smsUrl || '';
      if (!url) throw err(503, '短信通道 http 已选，但还没配置 SMS_API_URL。', 'sms_off');
      const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', ...(cfg.billing?.smsKey ? { Authorization: 'Bearer ' + cfg.billing.smsKey } : {}) }, body: JSON.stringify({ to: e164, text: `自主学验证码 ${code}，10 分钟内有效。` }) });
      if (!r.ok) throw err(502, '短信服务返回 ' + r.status, 'sms_failed');
      return { ok: true, via: 'http' };
    }
    throw err(503, '未配置的短信通道：' + p, 'sms_off');
  }

  async function chargeOrder(order) {
    const p = rules().payProvider;
    if (p === 'none' || p === 'off' || !p) return { ok: false, code: 'pay_unavailable', error: '在线付款尚未开通（苹果、Google Play、Stripe 都还没办）。价格和优惠可以先看，付款由管理员在看板登记后发放授权。' };
    if (p === 'manual') return { ok: false, code: 'pay_unavailable', error: '当前只支持管理员在看板手工登记付款，不能在网页上直接扣款。' };
    if (p === 'stripe' || p === 'apple' || p === 'google') {
      return { ok: false, code: 'not_configured', error: ({ stripe: 'Stripe', apple: '苹果内购', google: 'Google Play 内购' }[p]) + '尚未开通，不能收款。测试通过后再办。' };
    }
    return { ok: false, code: 'not_configured', error: '未配置的付款通道：' + p };
  }

  function quote(user, { period, region, coupon }) {
    if (!PERIODS_OK(period)) throw err(400, '请选择月付或年付', 'bad_period');
    const row = rowOf(region);
    const list = P.periodCents(row, period);
    let percent = 0, couponCode = '', already = false;
    if (coupon) {
      const cp = q('SELECT * FROM coupons WHERE code=?').get(String(coupon).toUpperCase().replace(/\s+/g, ''));
      if (!cp) throw err(400, '没有这个优惠码', 'bad_coupon');
      if (user && cp.owner_id !== user.id) throw err(403, '这张优惠码不是给你的', 'coupon_owner');
      if (!['issued', 'granted'].includes(cp.status)) throw err(400, couponStatusMsg(cp.status), 'coupon_state');
      // 不叠加：这张单已有折扣就拒绝第二张；一张单只能用一张券
      if (already) throw err(400, '推荐优惠不与其他优惠叠加，每次付款最多用一张 8 折券', 'no_stack');
      percent = cp.percent_off || rules().discountPercent;
      couponCode = cp.code;
    }
    const off = P.applyOff(list, percent, false);
    return { region: row.region, name: row.name, currency: row.currency, symbol: row.symbol, decimals: row.decimals, period, listCents: list, payCents: off.payCents, percent: off.percent, coupon: couponCode || null, list: P.formatCents(list, row), pay: P.formatCents(off.payCents, row), storeTax: !!row.storeTax };
  }
  function PERIODS_OK(p) { return p === 'month' || p === 'year'; }
  function couponStatusMsg(st) {
    return { pending: '这张邀请人优惠还没发放（要等好友付款满 30 天且未退款）', redeemed: '这张优惠码已经用过了', cancelled: '这张优惠码已取消', clawback: '这张优惠码因退款已取消', revoked: '这张优惠码已作废' }[st] || '这张优惠码现在不能用';
  }

  function publicCatalog() {
    ensurePrices();
    const r = rules();
    return {
      ok: true, enabled: r.enabled, sms: r.smsProvider, pay: r.payProvider,
      prices: priceTable(),
      rules: { firstWeekDays: r.firstWeekDays, firstWeekCheckins: r.firstWeekCheckins, checkinGoal: r.checkinGoal, rewardHoldDays: r.rewardHoldDays, discountPercent: r.discountPercent, monthDays: P.MONTH_DAYS, yearDays: P.YEAR_DAYS },
      notes: {
        region: '价格按应用商店地区或你选择的地区显示，不按 IP、不按手机号区分。',
        sms: r.smsProvider === 'off' ? '短信验证尚未开通，不能完成手机验证。' : null,
        pay: (r.payProvider === 'none' || r.payProvider === 'off') ? '在线付款尚未开通（苹果 / Google Play / Stripe 都还没办）。管理员可在看板手工登记付款并发放授权。' : null,
        iosCn: '中国大陆的 iOS 不得在 App 内引导去网页付款。',
        self: '自己注册没有优惠。好友通过邀请注册，完成手机验证和首周打卡后才生成优惠码。',
      },
    };
  }

  function bindInvite(u, inv, deviceId) {
    if (!inv) return u;
    if (inv.user_id === u.id) { q("UPDATE billing_users SET invalid_reason=COALESCE(invalid_reason, 'self_invite'), updated=? WHERE id=?").run(nowS(), u.id); return q('SELECT * FROM billing_users WHERE id=?').get(u.id); }
    if (deviceTaken(deviceId, u.id) || deviceTaken(u.device_id, u.id)) {
      q("UPDATE billing_users SET invited_by=NULL, invite_used=?, invalid_reason='duplicate_device', updated=? WHERE id=?").run(inv.code, nowS(), u.id);
      ev('invalid_reg', u.id, inv.code, { reason: 'duplicate_device' });
      return q('SELECT * FROM billing_users WHERE id=?').get(u.id);
    }
    if (u.invited_by && u.invited_by !== inv.user_id) return u; // 已经绑过别的邀请人，不改
    q('UPDATE billing_users SET invited_by=?, invite_used=?, updated=? WHERE id=?').run(inv.user_id, inv.code, nowS(), u.id);
    return q('SELECT * FROM billing_users WHERE id=?').get(u.id);
  }

  const routes = {
    'GET /billing/catalog': () => publicCatalog(),

    'GET /billing/invite': ({ req }) => {
      const u = new URL(req.url, 'http://x'); const code = (u.searchParams.get('code') || u.searchParams.get('c') || '').toUpperCase();
      const inv = inviteByCode(code);
      if (!inv) throw err(404, '没有这个邀请码', 'bad_invite');
      const host = q('SELECT phone_tail, valid FROM billing_users WHERE id=?').get(inv.user_id);
      return { ok: true, code: inv.code, inviterTail: host?.phone_tail || '好友' };
    },

    'POST /billing/phone/send': async ({ body, ip }) => {
      needOn(); limit('bill-sms:' + ip, cfg.rate?.billingSmsPerIp || [5, 600], '验证码发得太频繁，请稍后再试');
      const e164 = normalizePhone(body.phone); if (!e164) throw err(400, '手机号格式不对。请加国家区号（中国大陆也可以直接填 11 位）。', 'bad_phone');
      const h = phoneHash(e164);
      const prev = q('SELECT * FROM phone_codes WHERE phone_hash=?').get(h);
      if (prev && nowS() - prev.sent < 60) throw err(429, '刚才已经发过了，请 1 分钟后再试', 'rate_limited');
      const code = String(100000 + crypto.randomInt(900000));
      q('INSERT INTO phone_codes(phone_hash,code_hash,expires,attempts,sent,purpose) VALUES(?,?,?,?,?,?) ON CONFLICT(phone_hash) DO UPDATE SET code_hash=excluded.code_hash,expires=excluded.expires,attempts=0,sent=excluded.sent,purpose=excluded.purpose')
        .run(h, H(code), nowS() + 600, 0, nowS(), 'register');
      const r = await sendSms(e164, code);
      return { ok: true, via: r.via, phoneTail: maskPhone(e164), message: r.via === 'console' ? '验证码已写入服务器日志（短信通道是模拟，不是真发短信）。' : '验证码已发送' };
    },

    'POST /billing/phone/verify': ({ body, ip }) => {
      needOn(); limit('bill-ver:' + ip, cfg.rate?.billingVerifyPerIp || [20, 600], '尝试次数太多');
      const e164 = normalizePhone(body.phone); if (!e164) throw err(400, '手机号格式不对', 'bad_phone');
      const h = phoneHash(e164);
      const row = q('SELECT * FROM phone_codes WHERE phone_hash=?').get(h);
      if (!row) throw err(400, '请先获取验证码', 'no_code');
      if (row.expires < nowS()) throw err(400, '验证码已过期，请重新获取', 'expired');
      if (row.attempts >= 5) throw err(429, '尝试次数太多，请重新获取验证码', 'rate_limited');
      q('UPDATE phone_codes SET attempts=attempts+1 WHERE phone_hash=?').run(h);
      if (H(String(body.code || '').trim()) !== row.code_hash) throw err(400, '验证码不对', 'bad_code');
      q('DELETE FROM phone_codes WHERE phone_hash=?').run(h);
      const deviceId = String(body.d || body.deviceId || '').slice(0, 64);
      const inv = inviteByCode(body.inviteCode || body.codeInvite || body.c);
      let u = q('SELECT * FROM billing_users WHERE phone_hash=?').get(h);
      if (!u) {
        const uid = idOf('bu');
        const registeredDay = /^\d{4}-\d{2}-\d{2}$/.test(body.today || '') ? body.today : todayYmd(0);
        q('INSERT INTO billing_users(id,phone_hash,phone_tail,device_id,phone_verified,phone_verified_at,registered_at,created,updated) VALUES(?,?,?,?,1,?,?,?,?)')
          .run(uid, h, maskPhone(e164), deviceId || null, nowS(), nowS(), nowS(), nowS());
        // 把注册日（用户本地）记在 kv，供首周窗口使用
        kvSet('billing.regday.' + uid, registeredDay);
        q('UPDATE billing_users SET updated=? WHERE id=?').run(nowS(), uid);
        u = q('SELECT * FROM billing_users WHERE id=?').get(uid);
        ev('register', uid, inv?.code || '', { deviceId, self: !inv });
      } else {
        q('UPDATE billing_users SET phone_verified=1, phone_verified_at=COALESCE(phone_verified_at,?), device_id=COALESCE(device_id,?), updated=? WHERE id=?').run(nowS(), deviceId || null, nowS(), u.id);
        u = q('SELECT * FROM billing_users WHERE id=?').get(u.id);
      }
      // 把 registered_day 挂到对象上（存在 kv）
      u.registered_day = kvGet('billing.regday.' + u.id, null);
      if (inv) u = bindInvite(u, inv, deviceId);
      else if (!u.invited_by) ev('self_register', u.id, '', { note: '自己注册无优惠' });
      const tok = issueToken(u.id, deviceId);
      // 给每个已验证用户发一个邀请码（自己分享用）
      if (!q('SELECT 1 FROM invite_codes WHERE user_id=?').get(u.id)) {
        const ic = uniqueInvite();
        q('INSERT INTO invite_codes(code,user_id,created,disabled) VALUES(?,?,?,0)').run(ic, u.id, nowS());
      }
      u = evaluateValid(q('SELECT * FROM billing_users WHERE id=?').get(u.id));
      return { ok: true, ...tok, me: viewUser(u, { withSecrets: true }) };
    },

    'GET /billing/me': ({ req }) => { releaseDueRewards(); const u = needUser(req); return { ok: true, me: viewUser(u, { withSecrets: true }), catalog: publicCatalog() }; },

    'POST /billing/checkin': ({ req, body }) => {
      needOn(); const u = needUser(req);
      const day = String(body.day || '');
      if (!/^\d{4}-\d{2}-\d{2}$/.test(day)) throw err(400, '日期格式应为 YYYY-MM-DD', 'bad_day');
      const r = rules();
      const n = Math.max(0, Math.min(10000, Math.floor(+body.n || 0)));
      const goal = r.checkinGoal;
      const met = n >= goal ? 1 : 0; // 服务器用统一目标，不跟客户端自报的 goal，防止把目标改小来刷
      q('INSERT INTO checkins(user_id,day,n,goal,met,reported) VALUES(?,?,?,?,?,?) ON CONFLICT(user_id,day) DO UPDATE SET n=MAX(checkins.n,excluded.n), goal=excluded.goal, met=CASE WHEN MAX(checkins.n,excluded.n)>=excluded.goal THEN 1 ELSE 0 END, reported=excluded.reported')
        .run(u.id, day, n, goal, met, nowS());
      const u2 = evaluateValid(q('SELECT * FROM billing_users WHERE id=?').get(u.id));
      return { ok: true, met: !!met, me: viewUser(u2) };
    },

    'POST /billing/quote': ({ req, body }) => {
      const u = userOfToken(req); // 没登录也可以看原价；有券要登录
      if (body.coupon && !u) throw err(401, '使用优惠码请先完成手机验证', 'unauth');
      return { ok: true, ...quote(u, body) };
    },

    'POST /billing/order': ({ req, body, ip }) => {
      needOn(); limit('bill-od:' + ip, cfg.rate?.billingOrderPerIp || [20, 600], '下单太频繁');
      const u = needUser(req);
      const qte = quote(u, body);
      const id = idOf('od');
      q('INSERT INTO orders(id,user_id,period,region,currency,list_cents,pay_cents,percent_off,coupon_code,provider,pay_account,status,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
        .run(id, u.id, qte.period, qte.region, qte.currency, qte.listCents, qte.payCents, qte.percent, qte.coupon || '', rules().payProvider, String(body.payAccount || '').slice(0, 80), 'draft', nowS(), nowS());
      ev('order_draft', u.id, id, qte);
      return { ok: true, orderId: id, ...qte, payAvailable: false, payMessage: '在线付款尚未开通。请让管理员在看板登记付款后发放授权。' };
    },

    'POST /billing/pay': async ({ req, body }) => {
      needOn(); const u = needUser(req);
      const od = q('SELECT * FROM orders WHERE id=? AND user_id=?').get(String(body.orderId || ''), u.id);
      if (!od) throw err(404, '没有这个订单', 'no_order');
      if (od.status === 'paid') return { ok: true, already: true, order: publicOrder(od), me: viewUser(u, { withSecrets: true }) };
      if (od.status === 'refunded') throw err(400, '这个订单已退款', 'refunded');
      if (body.payAccount && payTaken(body.payAccount, u.id) && u.invited_by) {
        q("UPDATE billing_users SET invalid_reason='duplicate_pay', updated=? WHERE id=?").run(nowS(), u.id);
      }
      const ch = await chargeOrder(od);
      if (!ch.ok) return { ok: false, code: ch.code, error: ch.error, orderId: od.id };
      // 真收款通道将来在这里接回调；现在不会走到成功
      const paid = fulfill({ ...od, pay_account: body.payAccount || od.pay_account });
      return { ok: true, order: publicOrder(paid), me: viewUser(q('SELECT * FROM billing_users WHERE id=?').get(u.id), { withSecrets: true }) };
    },

    // ---- admin ----
    'GET /admin/billing': ({ req }) => {
      admin(req); releaseDueRewards(); ensurePrices();
      return {
        ok: true, rules: rules(), prices: priceTable(),
        users: q('SELECT id, phone_tail, invited_by, invite_used, device_id, pay_account, phone_verified, valid, invalid_reason, checkin_n, plan, exp_day, created FROM billing_users ORDER BY created DESC LIMIT 200').all()
          .map(u => ({ ...u, expires: u.exp_day ? C.ymdOf(u.exp_day) : null, phone_verified: !!u.phone_verified, valid: !!u.valid })),
        coupons: q('SELECT * FROM coupons ORDER BY created DESC LIMIT 200').all(),
        orders: q('SELECT id,user_id,period,region,currency,list_cents,pay_cents,percent_off,coupon_code,provider,pay_account,status,paid_at,refunded_at,exp_day,license_serial,note,created FROM orders ORDER BY created DESC LIMIT 200').all(),
        invites: q('SELECT i.code, i.user_id, i.created, i.disabled, u.phone_tail FROM invite_codes i LEFT JOIN billing_users u ON u.id=i.user_id ORDER BY i.created DESC LIMIT 200').all(),
        events: q('SELECT * FROM billing_events ORDER BY id DESC LIMIT 80').all(),
      };
    },

    'POST /admin/billing/config': ({ req, body }) => {
      admin(req);
      if (body.enabled !== undefined) kvSet('billing.enabled', bool(body.enabled) ? '1' : '0');
      for (const k of ['firstWeekDays', 'firstWeekCheckins', 'checkinGoal', 'rewardHoldDays', 'discountPercent']) {
        if (body[k] !== undefined) kvSet('billing.' + k, +body[k]);
      }
      ev('admin_config', '', '', body);
      return { ok: true, rules: rules() };
    },

    'POST /admin/billing/prices': ({ req, body }) => {
      admin(req); ensurePrices();
      const rows = Array.isArray(body.rows) ? body.rows : (body.region ? [body] : []);
      if (!rows.length) throw err(400, '请提交价格表');
      const upd = q('INSERT INTO price_table(region,name,currency,symbol,decimals,year,month,year_cents,month_cents,store_tax,note,sort,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(region) DO UPDATE SET name=excluded.name,currency=excluded.currency,symbol=excluded.symbol,decimals=excluded.decimals,year=excluded.year,month=excluded.month,year_cents=excluded.year_cents,month_cents=excluded.month_cents,store_tax=excluded.store_tax,note=excluded.note,sort=excluded.sort,updated=excluded.updated');
      for (const r of rows) {
        if (!r.region) throw err(400, '缺少地区代码');
        upd.run(r.region, r.name || r.region, r.currency || 'USD', r.symbol || '', +r.decimals || 0, String(r.year ?? ''), String(r.month ?? ''), +r.yearCents || +r.year_cents || 0, +r.monthCents || +r.month_cents || 0, r.storeTax || r.store_tax ? 1 : 0, r.note || '', +r.sort || 0, nowS());
      }
      ev('admin_prices', '', '', { n: rows.length });
      return { ok: true, prices: priceTable() };
    },

    'POST /admin/billing/pay': ({ req, body }) => {
      admin(req); needOnOrAdmin();
      let od = body.orderId ? q('SELECT * FROM orders WHERE id=?').get(body.orderId) : null;
      let u = body.userId ? q('SELECT * FROM billing_users WHERE id=?').get(body.userId) : null;
      if (!u && body.phone) { const e = normalizePhone(body.phone); if (e) u = q('SELECT * FROM billing_users WHERE phone_hash=?').get(phoneHash(e)); }
      if (!od) {
        if (!u) throw err(404, '没有这个用户，请先让对方完成手机验证，或提供订单编号', 'no_user');
        if (body.payAccount && payTaken(body.payAccount, u.id) && u.invited_by) {
          q("UPDATE billing_users SET invalid_reason='duplicate_pay', updated=? WHERE id=?").run(nowS(), u.id);
        }
        const qte = quote(u, { period: body.period || 'year', region: body.region || 'CN', coupon: body.coupon || '' });
        const id = idOf('od');
        q('INSERT INTO orders(id,user_id,period,region,currency,list_cents,pay_cents,percent_off,coupon_code,provider,pay_account,status,note,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
          .run(id, u.id, qte.period, qte.region, qte.currency, qte.listCents, qte.payCents, qte.percent, qte.coupon || '', 'manual', String(body.payAccount || '').slice(0, 80), 'draft', String(body.note || '看板手工登记'), nowS(), nowS());
        od = q('SELECT * FROM orders WHERE id=?').get(id);
      }
      if (od.status === 'paid') return { ok: true, already: true, order: publicOrder(od, true) };
      if (body.payAccount) q('UPDATE orders SET pay_account=?, updated=? WHERE id=?').run(String(body.payAccount).slice(0, 80), nowS(), od.id);
      const paid = fulfill({ ...od, pay_account: body.payAccount || od.pay_account }, { licenseCode: body.licenseCode || '' });
      return { ok: true, order: publicOrder(paid, true), me: viewUser(q('SELECT * FROM billing_users WHERE id=?').get(paid.user_id), { withSecrets: true }) };
    },

    'POST /admin/billing/refund': ({ req, body }) => {
      admin(req);
      const od = q('SELECT * FROM orders WHERE id=?').get(String(body.orderId || ''));
      if (!od) throw err(404, '没有这个订单', 'no_order');
      if (od.status === 'refunded') return { ok: true, already: true, order: publicOrder(od, true) };
      if (od.status !== 'paid') throw err(400, '只能退已付款的订单', 'bad_state');
      q("UPDATE orders SET status='refunded', refunded_at=?, note=?, updated=? WHERE id=?").run(nowS(), String(body.note || '看板退款'), nowS(), od.id);
      if (od.license_serial) q('UPDATE licenses SET revoked=1, note=? WHERE serial=?').run('refund:' + od.id, od.license_serial);
      const u = q('SELECT * FROM billing_users WHERE id=?').get(od.user_id);
      // 会员到期：若没有其他已付款未退款订单覆盖，则收回本单延长的天数
      const others = q("SELECT MAX(exp_day) e FROM orders WHERE user_id=? AND status='paid' AND id<>?").get(u.id, od.id)?.e;
      q('UPDATE billing_users SET exp_day=?, plan=?, updated=? WHERE id=?').run(others || 0, others ? u.plan : null, nowS(), u.id);
      cancelRewardsForOrder(od.id, body.note || 'refund');
      ev('order_refunded', u.id, od.id, { serial: od.license_serial });
      return { ok: true, order: publicOrder(q('SELECT * FROM orders WHERE id=?').get(od.id), true) };
    },

    'POST /admin/billing/coupon-revoke': ({ req, body }) => {
      admin(req);
      const c = q('SELECT * FROM coupons WHERE code=?').get(String(body.code || '').toUpperCase().replace(/\s+/g, ''));
      if (!c) throw err(404, '没有这个优惠码');
      q("UPDATE coupons SET status='revoked', cancelled_at=?, note=?, updated=? WHERE code=?").run(nowS(), String(body.note || '作废（禁止转卖或违规）'), nowS(), c.code);
      ev('coupon_revoked', c.owner_id, c.code, body.note || '');
      return { ok: true };
    },

    'POST /admin/billing/checkin': ({ req, body }) => {
      admin(req);
      const u = q('SELECT * FROM billing_users WHERE id=?').get(String(body.userId || ''));
      if (!u) throw err(404, '没有这个用户');
      const day = String(body.day || '');
      if (!/^\d{4}-\d{2}-\d{2}$/.test(day)) throw err(400, '日期格式应为 YYYY-MM-DD');
      const r = rules(); const n = Math.max(r.checkinGoal, Math.floor(+body.n || r.checkinGoal));
      q('INSERT INTO checkins(user_id,day,n,goal,met,reported) VALUES(?,?,?,?,1,?) ON CONFLICT(user_id,day) DO UPDATE SET n=excluded.n, goal=excluded.goal, met=1, reported=excluded.reported')
        .run(u.id, day, n, r.checkinGoal, nowS());
      const u2 = evaluateValid(q('SELECT * FROM billing_users WHERE id=?').get(u.id));
      return { ok: true, me: viewUser(u2) };
    },

    'GET /admin/billing/test-otp': ({ req }) => {
      admin(req);
      if (rules().smsProvider !== 'console') throw err(403, '只有短信通道为 console（模拟）时才能查看验证码', 'sms_not_console');
      const e164 = normalizePhone(new URL(req.url, 'http://x').searchParams.get('phone') || '');
      if (!e164) throw err(400, '请提供手机号');
      const raw = kvGet('billing.lastOtp.' + phoneHash(e164), '');
      if (!raw) throw err(404, '还没有验证码');
      return { ok: true, ...JSON.parse(raw) };
    },
  };

  function needOnOrAdmin() { /* 管理员登记付款时，即使总开关关着也允许（方便预演）；但 needOn 的公开接口仍关闭 */ }

  function publicOrder(od, adminView = false) {
    if (!od) return null;
    const row = rowOf(od.region);
    return {
      id: od.id, userId: od.user_id, period: od.period, region: od.region, currency: od.currency,
      listCents: od.list_cents, payCents: od.pay_cents, percent: od.percent_off, coupon: od.coupon_code || null,
      provider: od.provider, status: od.status, paidAt: od.paid_at ? od.paid_at * 1000 : null,
      refundedAt: od.refunded_at ? od.refunded_at * 1000 : null, expDay: od.exp_day, expires: od.exp_day ? C.ymdOf(od.exp_day) : null,
      licenseSerial: od.license_serial || null, licenseCode: adminView ? (od.license_code || '') : (od.license_code || ''),
      list: P.formatCents(od.list_cents, row), pay: P.formatCents(od.pay_cents, row), note: od.note || '',
    };
  }

  // evaluateValid 要用 registered_day
  const _eval = evaluateValid;
  function evaluateValidWrapped(u) {
    if (u && !u.registered_day) u.registered_day = kvGet('billing.regday.' + u.id, null);
    return _eval(u);
  }
  // monkey-patch calls already use evaluateValid; set registered_day inside evaluateValid start — already tries u.registered_day.
  // Hook kv at start of original: I already have `const startDay = u.registered_day || dates[0];`
  // Need to load it:
  const originalEval = evaluateValid;
  // re-wrap existing function body via loading kv in viewUser/evaluateValid:
  // Patch: before evaluateValid in this closure, we already can set it in a wrapper assigned... 
  // Actually I'll just load kv at the beginning by replacing usages. Easier to patch evaluateValid's first lines — already has u.registered_day || dates[0].
  // In viewUser we call evaluateValid(u) without registered_day. Fix viewUser/checkin to set it — I did not in all paths.
  // Add helper:
  function loadUser(id) {
    const u = q('SELECT * FROM billing_users WHERE id=?').get(id);
    if (u) u.registered_day = kvGet('billing.regday.' + u.id, null);
    return u;
  }

  return {
    routes, rules, priceTable, releaseDueRewards, publicCatalog, fulfill,
    adapters: { sendSms, chargeOrder },
    // test helpers
    _internal: { normalizePhone, firstWeekDates, phoneHash, loadUser, viewUser, evaluateValid: (u) => { if (u && !u.registered_day) u.registered_day = kvGet('billing.regday.' + u.id, null); return evaluateValid(u); }, quote, rules },
  };
}
