// v1.9.4 内置 AI（服务器代理）：普通用户不用配任何密钥，打开即用 AI；密钥只在服务器上，绝不下发前端。
// · 只接受 {task, args}：提示词由服务器按 public/js/aiprompts.js（前后端共用）自己拼，不能当通用聊天代理用。
// · 结果缓存（同样输入不重复花钱）；每台匿名设备每天 / 每月额度；全站每月花费上限；每分钟限流；Origin 校验；单次输入长度上限。
// · 超额 / 失败：返回带 code 的中文错误，前端翻译自动改用免费翻译，其他功能如实提示。
// · 密钥：看板「AI 设置」粘贴保存（数据库旁边的 ai-key 文件，权限 0600），或 .env 的 AI_API_KEY；接口、日志、看板里永远只显示末 4 位。
// · 统计（看板）：按天 / 功能 / 状态汇总调用次数、token、估算花费（按价目表估算，不是账单）；失败原因；匿名设备只存加盐哈希。
import crypto from 'node:crypto'; import fs from 'node:fs'; import path from 'node:path';
import * as P from '../public/js/aiprompts.js';
import { dayOf } from './telemetry.js';

/** 迁移 8：只新建表（IF NOT EXISTS），不动已有数据 */
export const MIGRATION_8 = `CREATE TABLE IF NOT EXISTS ai_daily(day TEXT NOT NULL, dev TEXT NOT NULL, task TEXT NOT NULL, status TEXT NOT NULL, n INT DEFAULT 0, pt INT DEFAULT 0, ct INT DEFAULT 0, chars INT DEFAULT 0, cost REAL DEFAULT 0, PRIMARY KEY(day, dev, task, status));
   CREATE INDEX IF NOT EXISTS ai_daily_dev ON ai_daily(dev, day);
   CREATE TABLE IF NOT EXISTS ai_cache(k TEXT PRIMARY KEY, task TEXT, v TEXT, created INT, hits INT DEFAULT 0);
   CREATE INDEX IF NOT EXISTS ai_cache_created ON ai_cache(created);
   CREATE TABLE IF NOT EXISTS ai_tts(k TEXT PRIMARY KEY, audio BLOB, mime TEXT, bytes INT, created INT, hits INT DEFAULT 0);
   CREATE INDEX IF NOT EXISTS ai_tts_created ON ai_tts(created);
   CREATE TABLE IF NOT EXISTS ai_errors(id INTEGER PRIMARY KEY AUTOINCREMENT, at INT, day TEXT, task TEXT, code TEXT, msg TEXT);`;

/** 价目表（美元 / 每 100 万 token：输入、输出）。只用来估算，实际以服务商账单为准 */
export const PRICES = {
  'gpt-4o-mini': [0.15, 0.6], 'gpt-4.1-nano': [0.1, 0.4], 'gpt-4.1-mini': [0.4, 1.6], 'gpt-5-nano': [0.05, 0.4], 'gpt-5-mini': [0.25, 2.0], 'gpt-4.1': [2.0, 8.0], 'gpt-4o': [2.5, 10.0],
};
export const TTS_PRICE_PER_M_CHARS = 15; // gpt-4o-mini-tts / tts-1 约每 100 万字符 15 美元（估算）
export const priceOf = model => PRICES[model] || PRICES[Object.keys(PRICES).find(k => String(model).startsWith(k + '-'))] || PRICES['gpt-4o-mini'];
export const costOf = (model, pt, ct) => { const [a, b] = priceOf(model); return (pt * a + ct * b) / 1e6; };
export const TASK_NAMES = { ...Object.fromEntries(Object.entries(P.TASKS).map(([k, v]) => [k, v.name || k])), test: '测试连接', speech: 'AI 语音' };
export const APP_ORIGINS = ['app://zizhuxue', 'capacitor://localhost', 'https://localhost']; // 电脑客户端、iOS / 安卓 App
export const DEFAULTS = { baseUrl: P.DEFAULT_BASE, model: P.DEFAULT_MODEL, ttsModel: P.AI_TTS_MODEL, deviceDaily: 300, deviceMonthly: 3000, ttsDaily: 300, ipDaily: 2000, monthlyBudgetUsd: 20, maxInputChars: 8000 };
const LIMIT_KEYS = ['deviceDaily', 'deviceMonthly', 'ttsDaily', 'ipDaily', 'monthlyBudgetUsd', 'maxInputChars'];
const ACCENTS = ['auto', 'en-US', 'en-GB', 'en-AU'];
const CACHE_MAX = 50000, TTS_MAX = 2000, ERR_MAX = 500;

/** 把任何可能带密钥的文字洗干净（密钥本身、sk- 开头的串、Bearer 后面的东西） */
export function scrub(s, key = '') {
  let t = String(s ?? '');
  if (key && key.length >= 6) t = t.split(key).join('***');
  return t.replace(/\b(sk|rk|pk|sess)-[A-Za-z0-9_\-]{6,}/g, '$1-***').replace(/Bearer\s+\S+/gi, 'Bearer ***').replace(/(api[_-]?key["'\s:=]+)[^\s"',}]{6,}/gi, '$1***').slice(0, 600);
}
export const tail4 = k => k ? '…' + k.slice(-4) : '';

export function createAI({ q, cfg, clock, err, limit, tx, log = () => { }, devHash, needAdmin, fetchImpl = (...a) => fetch(...a) }) {
  const env = cfg.ai || {};
  const off = cfg.statsTzOffsetMin ?? 480;
  const keyFile = cfg.aiKeyFile || (cfg.dbFile && cfg.dbFile !== ':memory:' ? path.join(path.dirname(cfg.dbFile), 'ai-key') : null);
  let memKey = null; // 内存数据库（测试）时看板保存的密钥放内存

  // ———— 设置 ————
  const saved = () => { try { return JSON.parse(q("SELECT v FROM kv WHERE k='ai_settings'").get()?.v || '{}') || {}; } catch { return {}; } };
  const savedKey = () => {
    if (keyFile) { try { return P.normalizeKey(fs.readFileSync(keyFile, 'utf8')); } catch { return ''; } }
    return memKey || '';
  };
  function settings() {
    const s = saved(); const dk = savedKey();
    const pick = k => s[k] !== undefined && s[k] !== null && s[k] !== '' ? s[k] : env[k] !== undefined && env[k] !== '' && env[k] !== null ? env[k] : DEFAULTS[k];
    const key = dk || P.normalizeKey(env.apiKey || '');
    const out = { baseUrl: P.normalizeBase(pick('baseUrl')), model: String(pick('model')), ttsModel: String(pick('ttsModel')), key, keySource: dk ? 'dashboard' : key ? 'env' : '' };
    for (const k of LIMIT_KEYS) out[k] = Math.max(0, Number(pick(k)) || 0);
    out.enabled = s.enabled !== undefined ? !!s.enabled : env.enabled !== undefined ? !!env.enabled : true;
    out.ready = out.enabled && !!key;
    return out;
  }
  function saveKey(k) {
    if (keyFile) {
      if (!k) { try { fs.unlinkSync(keyFile); } catch { } return; }
      fs.mkdirSync(path.dirname(keyFile), { recursive: true });
      const tmp = keyFile + '.tmp'; fs.writeFileSync(tmp, k, { mode: 0o600 }); fs.chmodSync(tmp, 0o600); fs.renameSync(tmp, keyFile);
    } else memKey = k || null;
  }
  const view = (s = settings()) => ({
    enabled: s.enabled, ready: s.ready, hasKey: !!s.key, keyTail: tail4(s.key), keySource: s.keySource, keyFile: s.keySource === 'dashboard' ? keyFile : null,
    baseUrl: s.baseUrl, model: s.model, ttsModel: s.ttsModel, limits: Object.fromEntries(LIMIT_KEYS.map(k => [k, s[k]])),
    defaults: DEFAULTS, models: Object.entries(PRICES).map(([m, [a, b]]) => ({ model: m, input: a, output: b })), ttsPricePerMChars: TTS_PRICE_PER_M_CHARS,
  });

  // ———— 记账 ————
  const today = () => dayOf(clock(), off); const monthOf = d => d.slice(0, 7);
  function record(dev, task, status, { pt = 0, ct = 0, chars = 0, cost = 0 } = {}) {
    q(`INSERT INTO ai_daily(day,dev,task,status,n,pt,ct,chars,cost) VALUES(?,?,?,?,1,?,?,?,?)
       ON CONFLICT(day,dev,task,status) DO UPDATE SET n=n+1, pt=pt+excluded.pt, ct=ct+excluded.ct, chars=chars+excluded.chars, cost=cost+excluded.cost`).run(today(), dev, task, status, pt, ct, chars, cost);
  }
  function recordError(task, code, msg, key) {
    try {
      q('INSERT INTO ai_errors(at,day,task,code,msg) VALUES(?,?,?,?,?)').run(Math.floor(clock() / 1000), today(), task, String(code || 'error').slice(0, 40), scrub(msg, key));
      q('DELETE FROM ai_errors WHERE id <= (SELECT MAX(id) FROM ai_errors) - ?').run(ERR_MAX);
    } catch { }
  }
  const used = (dev, from, to, speech) => q(`SELECT COALESCE(SUM(n),0) n FROM ai_daily WHERE dev=? AND day BETWEEN ? AND ? AND status IN ('ok','fail') AND task ${speech ? '=' : '<>'} 'speech'`).get(dev, from, to).n;
  const monthSpend = () => q("SELECT COALESCE(SUM(cost),0) c FROM ai_daily WHERE day BETWEEN ? AND ?").get(monthOf(today()) + '-01', monthOf(today()) + '-31').c;
  const ipCount = new Map(); // 每个 IP 当天打到上游的次数（内存；重启清零）
  function takeIp(ip, max) {
    const k = today() + '|' + ip; if (ipCount.size > 20000) for (const x of ipCount.keys()) if (!x.startsWith(today())) ipCount.delete(x);
    const n = ipCount.get(k) || 0; if (max && n >= max) return false; ipCount.set(k, n + 1); return true;
  }

  // ———— 访问控制 ————
  /** Origin 校验：只允许本站网页（PUBLIC_URL / 同源）、ALLOWED_ORIGINS / AI_ALLOWED_ORIGINS 里明确列出的网页、App 客户端；POST 必须带 Origin（浏览器总会带） */
  function originOk(origin, sameOrigin) {
    if (sameOrigin) return true; if (!origin) return false;
    if (APP_ORIGINS.includes(origin)) return true;
    if (cfg.publicUrl) { try { if (new URL(cfg.publicUrl).origin === origin) return true; } catch { } }
    return cfg.allowedOrigins.includes(origin) || (env.origins || []).includes(origin); // 注意：ALLOWED_ORIGINS=* 对内置 AI 不算数（要花钱的接口只认明确列出的网页）
  }
  function gate({ body, ip, origin, sameOrigin }, s) {
    if (!originOk(origin, sameOrigin)) throw err(403, '这个网页不能使用内置 AI', 'origin_denied');
    if (!s.ready) throw err(503, '内置 AI 暂时关闭了', 'ai_off');
    const id = String(body.d || ''); if (!/^[A-Za-z0-9_-]{8,64}$/.test(id)) throw err(400, '设备标识不对', 'bad_device');
    const dh = 'ai:' + devHash(id);
    try { limit('aim:' + ip, [env.perMinIp || 60, 60], '用得太快了'); limit('aimd:' + dh, [env.perMinDevice || 30, 60], '用得太快了'); } catch (e) { throw err(429, '用得太快了，请稍等一会儿再试', 'rate_limited', { retryAfter: e.retryAfter }); }
    return dh.slice(3);
  }
  /** 额度：每台设备每天 / 每月、每个 IP 每天、全站每月花费上限 */
  function quota(dev, task, ip, s, speech) {
    const d = today();
    if (speech ? s.ttsDaily && used(dev, d, d, true) >= s.ttsDaily : s.deviceDaily && used(dev, d, d, false) >= s.deviceDaily) { record(dev, task, 'quota'); throw err(429, '今天的免费额度用完了', 'quota_device'); }
    if (!speech && s.deviceMonthly && used(dev, monthOf(d) + '-01', d, false) >= s.deviceMonthly) { record(dev, task, 'quota'); throw err(429, '这个月的免费额度用完了', 'quota_month'); }
    if (s.monthlyBudgetUsd > 0 && monthSpend() >= s.monthlyBudgetUsd) { record(dev, task, 'budget'); throw err(429, '本月内置 AI 总额度已用完', 'budget'); }
    if (!takeIp(ip, s.ipDaily)) { record(dev, task, 'quota'); throw err(429, '今天的免费额度用完了', 'quota_device'); }
  }

  // ———— 调上游 ————
  async function upstream(s, p, body, timeout) {
    const ac = new AbortController(); const to = setTimeout(() => ac.abort(), timeout);
    try { return await fetchImpl(s.baseUrl + p, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + s.key }, body: JSON.stringify(body), signal: ac.signal }); }
    catch (e) {
      let host = s.baseUrl; try { host = new URL(s.baseUrl).host; } catch { }
      throw new P.AIError(e?.name === 'AbortError' ? `AI 服务 ${Math.round(timeout / 1000)} 秒没有响应（超时）` : `服务器连不上 ${host}（${scrub(e?.cause?.code || e?.message || e, s.key)}）`, e?.name === 'AbortError' ? 'TIMEOUT' : 'NETWORK');
    } finally { clearTimeout(to); }
  }
  async function chat(s, b) {
    const call = ({ fmt, temp }) => upstream(s, '/chat/completions', { model: s.model, messages: b.messages, ...(temp ? { temperature: b.temperature } : {}), ...(fmt ? { response_format: { type: 'json_object' } } : {}) }, b.timeout);
    let r = await call({ fmt: true, temp: true });
    for (const opt of [{ fmt: false, temp: true }, { fmt: false, temp: false }]) { if (r.status !== 400 && r.status !== 422) break; r = await call(opt); }
    if (!r.ok) { let j = null; try { j = await r.json(); } catch { } const e = P.explainError(r.status, j, { model: s.model, baseUrl: s.baseUrl }); e.message = scrub(e.message, s.key); throw e; }
    let data; try { data = await r.json(); } catch { throw new P.AIError('AI 服务返回了无法解析的响应（接口地址可能不对）', 'BAD_FORMAT'); }
    const content = data?.choices?.[0]?.message?.content; if (!content) throw new P.AIError('AI 服务没有返回内容', 'BAD_FORMAT');
    return { r: P.extractJSON(content), pt: +data?.usage?.prompt_tokens || 0, ct: +data?.usage?.completion_tokens || 0 };
  }
  const H = x => crypto.createHash('sha256').update(x).digest('hex');
  let inserts = 0;
  const prune = () => { if (++inserts % 200) return; try { q('DELETE FROM ai_cache WHERE k IN (SELECT k FROM ai_cache ORDER BY created ASC LIMIT MAX(0, (SELECT COUNT(*) FROM ai_cache) - ?))').run(CACHE_MAX); q('DELETE FROM ai_tts WHERE k IN (SELECT k FROM ai_tts ORDER BY created ASC LIMIT MAX(0, (SELECT COUNT(*) FROM ai_tts) - ?))').run(TTS_MAX); } catch (e) { log('AI 缓存清理出错', e.message); } };
  /** 上游失败：记原因（洗掉密钥），给前端一个不含内部细节的中文错误 */
  function fail(dev, task, e, s) {
    record(dev, task, 'fail'); recordError(task, e.code || 'error', e.message, s.key);
    log(`内置 AI 调用失败（${task}）：${scrub(e.message, s.key)}`);
    return err(502, '内置 AI 暂时出错了，请稍后再试', 'upstream');
  }

  // ———— 接口 ————
  async function run(ctx) {
    const s = settings(); const dev = gate(ctx, s); const { body, ip } = ctx;
    const task = String(body.task || ''); if (!P.PUBLIC_TASKS.includes(task)) throw err(400, '没有这项 AI 功能', 'bad_task');
    const raw = body.args && typeof body.args === 'object' ? body.args : {};
    if (JSON.stringify(raw).length > s.maxInputChars) throw err(413, '内容太长了', 'too_big');
    const b = P.build(task, raw);
    const ck = H([s.model, task, JSON.stringify(b.args)].join('|'));
    const hit = q('SELECT v FROM ai_cache WHERE k=?').get(ck);
    if (hit) { q('UPDATE ai_cache SET hits=hits+1 WHERE k=?').run(ck); record(dev, task, 'cache'); return { ok: true, r: JSON.parse(hit.v), cached: true }; }
    quota(dev, task, ip, s, false);
    let out; try { out = await chat(s, b); } catch (e) { throw fail(dev, task, e, s); }
    const chars = JSON.stringify(b.args).length, cost = costOf(s.model, out.pt, out.ct);
    tx(() => { record(dev, task, 'ok', { pt: out.pt, ct: out.ct, chars, cost }); q('INSERT OR REPLACE INTO ai_cache(k,task,v,created,hits) VALUES(?,?,?,?,0)').run(ck, task, JSON.stringify(out.r), Math.floor(clock() / 1000)); });
    prune();
    return { ok: true, r: out.r, cached: false };
  }
  async function speech(ctx) {
    const s = settings(); const dev = gate(ctx, s); const { body, ip } = ctx;
    const text = String(body.text || '').trim(); if (!text) throw err(400, '没有要朗读的文字', 'bad_text'); if (text.length > 600) throw err(413, '内容太长了', 'too_big');
    const voice = P.AI_VOICES.includes(body.voice) ? body.voice : 'coral', accent = ACCENTS.includes(body.accent) ? body.accent : 'auto';
    const ck = H([s.ttsModel, voice, accent, text].join('|'));
    const hit = q('SELECT audio, mime FROM ai_tts WHERE k=?').get(ck);
    if (hit) { q('UPDATE ai_tts SET hits=hits+1 WHERE k=?').run(ck); record(dev, 'speech', 'cache'); return { __raw: { body: Buffer.from(hit.audio), type: hit.mime || 'audio/mpeg', headers: { 'X-AI-Cache': 'hit' } } }; }
    quota(dev, 'speech', ip, s, true);
    let buf, mime;
    try {
      const r = await upstream(s, '/audio/speech', P.speechBody({ text, model: s.ttsModel, voice, accent }), 30000);
      if (!r.ok) { let j = null; try { j = await r.json(); } catch { } const e = P.explainError(r.status, j, { model: s.ttsModel, baseUrl: s.baseUrl }); e.message = scrub(e.message, s.key); throw e; }
      buf = Buffer.from(await r.arrayBuffer()); mime = (r.headers.get('content-type') || 'audio/mpeg').split(';')[0];
      if (!buf.length) throw new P.AIError('AI 语音返回了空音频', 'BAD_FORMAT');
    } catch (e) { throw fail(dev, 'speech', e, s); }
    const cost = text.length * TTS_PRICE_PER_M_CHARS / 1e6;
    tx(() => { record(dev, 'speech', 'ok', { chars: text.length, cost }); q('INSERT OR REPLACE INTO ai_tts(k,audio,mime,bytes,created,hits) VALUES(?,?,?,?,?,0)').run(ck, buf, mime, buf.length, Math.floor(clock() / 1000)); });
    prune();
    return { __raw: { body: buf, type: mime, headers: { 'X-AI-Cache': 'miss' } } };
  }
  function status({ origin, sameOrigin } = {}) {
    const s = settings(); const allowed = !origin || originOk(origin, sameOrigin);
    return { ok: true, enabled: s.ready && allowed, ...(allowed ? {} : { reason: 'origin' }), tts: s.ready, model: s.ready ? s.model : null, limits: { deviceDaily: s.deviceDaily, deviceMonthly: s.deviceMonthly, ttsDaily: s.ttsDaily, maxInputChars: s.maxInputChars } };
  }

  // ———— 管理（ADMIN_TOKEN） ————
  function saveSettings(body) {
    const cur = saved(); const next = { ...cur };
    if (body.clearKey) saveKey('');
    if (typeof body.apiKey === 'string' && body.apiKey.trim()) {
      const k = P.normalizeKey(body.apiKey); const bad = P.badKeyChars(k);
      if (bad) throw err(400, `密钥里有不能用的字符：${bad}。请重新粘贴。`, 'bad_key');
      if (k.length < 8 || k.length > 400) throw err(400, '密钥长度不对，请重新粘贴完整的密钥', 'bad_key');
      saveKey(k);
    }
    if (body.baseUrl !== undefined) { const u = String(body.baseUrl || '').trim(); if (u && !/^https?:\/\/[^\s]+$/i.test(u)) throw err(400, '接口地址要以 https:// 开头', 'bad_base'); next.baseUrl = u ? P.normalizeBase(u) : null; }
    for (const k of ['model', 'ttsModel']) if (body[k] !== undefined) { const m = String(body[k] || '').trim(); if (m && !/^[A-Za-z0-9._:\/-]{1,80}$/.test(m)) throw err(400, '模型名格式不对', 'bad_model'); next[k] = m || null; }
    if (body.enabled !== undefined) next.enabled = !!body.enabled;
    for (const k of LIMIT_KEYS) if (body[k] !== undefined && body[k] !== '') { const n = Number(body[k]); if (!Number.isFinite(n) || n < 0 || n > 1e7) throw err(400, '额度要填 0 或正数', 'bad_limit'); next[k] = n; }
    q("INSERT INTO kv(k,v) VALUES('ai_settings',?) ON CONFLICT(k) DO UPDATE SET v=excluded.v").run(JSON.stringify(next));
    return { ok: true, ...view() };
  }
  async function test(body) {
    const s = settings(); const k = typeof body.apiKey === 'string' && body.apiKey.trim() ? P.normalizeKey(body.apiKey) : s.key;
    const t = { ...s, key: k, baseUrl: body.baseUrl ? P.normalizeBase(body.baseUrl) : s.baseUrl, model: String(body.model || '').trim() || s.model };
    if (!t.key) return { ok: false, reason: '还没有密钥：请先粘贴密钥并保存。', code: 'NO_KEY' };
    const bad = P.badKeyChars(t.key); if (bad) return { ok: false, reason: `密钥里有不能用的字符：${bad}。请重新粘贴。`, code: 'KEY_CHARS' };
    const at = clock();
    try {
      const a = await chat(t, P.build('test'));
      if (a.r?.ok !== true) return { ok: false, reason: '能连上，但返回内容不对（模型可能不支持 JSON 输出），请换个模型试试。', code: 'BAD_FORMAT' };
      const b = await chat(t, P.build('translate', { texts: ['Good morning.'], dir: 'en2zh' }));
      record('admin', 'test', 'ok', { pt: a.pt + b.pt, ct: a.ct + b.ct, cost: costOf(t.model, a.pt + b.pt, a.ct + b.ct) });
      return { ok: true, model: t.model, baseUrl: t.baseUrl, keyTail: tail4(t.key), sample: String(b.r?.t?.[0] || ''), ms: clock() - at };
    } catch (e) {
      const reason = scrub(e.message, t.key); recordError('test', e.code, reason, t.key);
      return { ok: false, reason, code: e.code || 'error', model: t.model, baseUrl: t.baseUrl };
    }
  }
  const addDay = (d, n) => new Date(Date.parse(d + 'T00:00:00Z') + n * 864e5).toISOString().slice(0, 10);
  /** 看板统计 */
  function stats() {
    const d = today(), d7 = addDay(d, -6), d30 = addDay(d, -29), m1 = monthOf(d) + '-01'; const s = settings();
    const win = from => {
      const rows = q(`SELECT task, status, SUM(n) n, SUM(pt) pt, SUM(ct) ct, SUM(chars) chars, SUM(cost) cost FROM ai_daily WHERE day BETWEEN ? AND ? AND dev<>'admin' GROUP BY task, status`).all(from, d);
      const t = { calls: 0, ok: 0, cache: 0, fail: 0, quota: 0, budget: 0, pt: 0, ct: 0, cost: 0 }; const by = {};
      for (const r of rows) {
        const x = by[r.task] ||= { task: r.task, name: TASK_NAMES[r.task] || r.task, ok: 0, cache: 0, fail: 0, quota: 0, budget: 0, pt: 0, ct: 0, cost: 0 };
        x[r.status] = (x[r.status] || 0) + r.n; t[r.status] = (t[r.status] || 0) + r.n; for (const k of ['pt', 'ct', 'cost']) { x[k] += r[k] || 0; t[k] += r[k] || 0; }
      }
      t.calls = t.ok + t.cache + t.fail + t.quota + t.budget; t.hitRate = t.ok + t.cache ? t.cache / (t.ok + t.cache) : 0; t.refused = t.quota + t.budget;
      t.users = q(`SELECT COUNT(DISTINCT dev) n FROM ai_daily WHERE day BETWEEN ? AND ? AND dev<>'admin'`).get(from, d).n;
      return { ...t, byTask: Object.values(by).sort((a, b) => (b.ok + b.cache) - (a.ok + a.cache)) };
    };
    const ev = (e, from) => { try { return q('SELECT COUNT(*) n, COUNT(DISTINCT device_hash) u FROM telemetry WHERE event=? AND day BETWEEN ? AND ?').get(e, from, d); } catch { return { n: 0, u: 0 }; } };
    const own = from => ({ ok: ev('ai_own_ok', from).n, fail: ev('ai_own_fail', from).n, users: (() => { try { return q("SELECT COUNT(DISTINCT device_hash) n FROM telemetry WHERE event IN ('ai_own_ok','ai_own_fail') AND day BETWEEN ? AND ?").get(from, d).n; } catch { return 0; } })(), fallback: ev('ai_fallback', from).n, fallbackUsers: ev('ai_fallback', from).u });
    return {
      settings: view(s), today: win(d), last7: win(d7), last30: win(d30), month: { from: m1, spend: monthSpend(), budget: s.monthlyBudgetUsd },
      own: { today: own(d), last7: own(d7), last30: own(d30) },
      errors: q('SELECT code, task, COUNT(*) n, MAX(at) last, (SELECT msg FROM ai_errors e2 WHERE e2.code=e.code ORDER BY id DESC LIMIT 1) msg FROM ai_errors e WHERE day>=? GROUP BY code ORDER BY n DESC LIMIT 20').all(d30).map(r => ({ ...r, last: r.last * 1000 })),
      recentErrors: q('SELECT at, task, code, msg FROM ai_errors ORDER BY id DESC LIMIT 10').all().map(r => ({ ...r, at: r.at * 1000 })),
      topDevices: q(`SELECT dev, SUM(CASE WHEN status IN ('ok','fail') THEN n ELSE 0 END) calls, SUM(CASE WHEN status='cache' THEN n ELSE 0 END) cache, SUM(cost) cost FROM ai_daily WHERE day BETWEEN ? AND ? AND dev<>'admin' GROUP BY dev ORDER BY cost DESC, calls DESC LIMIT 10`).all(d30, d).map(r => ({ dev: r.dev.slice(0, 8), calls: r.calls, cache: r.cache, cost: r.cost })),
      cache: { entries: q('SELECT COUNT(*) n FROM ai_cache').get().n, tts: q('SELECT COUNT(*) n, COALESCE(SUM(bytes),0) b FROM ai_tts').get() },
      estimateNote: '花费按价目表估算（美元），不是服务商账单；以服务商后台为准。',
    };
  }

  const routes = {
    'GET /ai/status': ctx => status(ctx),
    'POST /ai/run': ctx => run(ctx),
    'POST /ai/speech': ctx => speech(ctx),
    'GET /admin/ai': ({ req, ip }) => { needAdmin(req, ip); return { ok: true, ...view() }; },
    'POST /admin/ai': ({ req, ip, body }) => { needAdmin(req, ip); return saveSettings(body || {}); },
    'POST /admin/ai/test': ({ req, ip, body }) => { needAdmin(req, ip); limit('aitest:' + ip, [20, 600], '测试太频繁'); return test(body || {}); },
  };
  return { routes, settings, view, stats, status, originOk, scrubKey: s => scrub(s, settings().key) };
}
