// 在线备份（服务器运行中也可执行，不锁库）：node sync-server/backup.js [输出文件]
// 默认输出到 DB 同目录的 backups/zizhuxue-YYYYMMDD-HHMMSS.db，并只保留最近 BACKUP_KEEP（默认 14）份。
import fs from 'node:fs'; import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { loadConfig, loadDotEnv } from './config.js';

export function backup(dbFile, out) {
  fs.mkdirSync(path.dirname(out), { recursive: true });
  if (fs.existsSync(out)) throw new Error('目标文件已存在：' + out);
  const db = new DatabaseSync(dbFile); try { db.prepare('VACUUM INTO ?').run(out); } finally { db.close(); }
  const chk = new DatabaseSync(out); try { const r = chk.prepare('PRAGMA integrity_check').get(); if (Object.values(r)[0] !== 'ok') throw new Error('备份文件校验失败'); } finally { chk.close(); }
  return out;
}
if (process.argv[1] === import.meta.filename) {
  loadDotEnv(path.join(import.meta.dirname, '.env'));
  const cfg = loadConfig(); const dir = path.join(path.dirname(cfg.dbFile), 'backups');
  const stamp = new Date().toISOString().replace(/[-:]/g, '').replace('T', '-').slice(0, 15);
  const out = process.argv[2] || path.join(dir, `zizhuxue-${stamp}.db`);
  console.log('已备份到', backup(cfg.dbFile, out));
  if (!process.argv[2]) { const keep = +(process.env.BACKUP_KEEP || 14); const all = fs.readdirSync(dir).filter(f => /^zizhuxue-.*\.db$/.test(f)).sort(); for (const f of all.slice(0, Math.max(0, all.length - keep))) fs.unlinkSync(path.join(dir, f)); }
}
