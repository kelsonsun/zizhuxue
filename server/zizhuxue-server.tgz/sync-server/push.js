// v1.11 网页推送强提醒（服务器端）：订阅 / 退订 / 改偏好 / 报进度、后台按用户时区定时发、失效订阅（404/410）自动清理、管理看板统计与测试推送。
// 不用任何第三方或付费推送服务：VAPID 密钥自己生成（首次启动自动生成并存进数据库 kv 表，重启不变），
// 消息用 RFC 8291 加密后直接发给浏览器自带的推送服务（苹果 / 谷歌 / Mozilla / 微软，这是浏览器内置的通道，不需要注册账号）。
// v1.8 的旧订阅（没有 prefs）照旧按“每日一次 + 23 点再提醒”发，兼容旧数据。
import crypto from 'node:crypto';
import * as WP from './webpush.js';
import { due as dueLegacy, dueV2, parseAt, localNow, copy, URL_OF } from './reminders.js';
import { prefsError, normPrefs, KINDS } from '../public/js/remindplan.js';

// 10（v1.11）：推送订阅加偏好（四种提醒、免打扰、每日上限）、当天状态（学过 / 到期卡 / 冰块）、设备与账号关联；发送记录表（每日上限、看板统计）
export const MIGRATION_10 = `ALTER TABLE push_subs ADD COLUMN prefs TEXT;
   ALTER TABLE push_subs ADD COLUMN studied_date TEXT;
   ALTER TABLE push_subs ADD COLUMN due_json TEXT;
   ALTER TABLE push_subs ADD COLUMN freezes INT;
   ALTER TABLE push_subs ADD COLUMN device_hash TEXT;
   ALTER TABLE push_subs ADD COLUMN billing_user TEXT;
   ALTER TABLE push_subs ADD COLUMN platform TEXT;
   ALTER TABLE push_subs ADD COLUMN app_ver TEXT;
   ALTER TABLE push_subs ADD COLUMN last_sent INT;
   CREATE INDEX IF NOT EXISTS ps_ep ON push_subs(endpoint);
   CREATE TABLE IF NOT EXISTS push_log(id INTEGER PRIMARY KEY AUTOINCREMENT, sub_id TEXT, kind TEXT, local_date TEXT, ts INT, status INT, source TEXT);
   CREATE INDEX IF NOT EXISTS pl_sub ON push_log(sub_id, local_date);
   CREATE INDEX IF NOT EXISTS pl_ts ON push_log(ts);`;

const H = s => crypto.createHash('sha256').update(s).digest('hex');
export const serviceOf = ep => { let h = ''; try { h = new URL(ep).hostname; } catch { } return /apple\.com$/.test(h) ? 'apple' : /googleapis\.com$/.test(h) ? 'google' : /mozilla\.com$/.test(h) ? 'mozilla' : /windows\.com$/.test(h) ? 'microsoft' : 'other'; };
export const SERVICE_LABEL = { apple: '苹果（iPhone / iPad / Mac Safari）', google: '谷歌（安卓 / Chrome / Edge）', mozilla: 'Firefox', microsoft: '微软（旧版 Edge）', other: '其他' };
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const keepLogDays = 90;

export function createPush({ q, cfg, clock, err, limit, log = () => { }, pushFetch = fetch, devHash = x => H(x).slice(0, 32), needAdmin, billingUserOf = () => null }) {
  const nowS = () => Math.floor(clock() / 1000);
  // VAPID 密钥：环境变量优先；没配就自动生成一次，存进数据库 kv 表（重启、升级都不变）
  const vapid = (() => {
    if (!cfg.push.enabled) return null;
    if (cfg.push.publicKey && cfg.push.privateKey) return { publicKey: cfg.push.publicKey, privateKey: cfg.push.privateKey, subject: cfg.push.subject, source: 'env' };
    const row = q("SELECT v FROM kv WHERE k='vapid'").get(); if (row) return { ...JSON.parse(row.v), subject: cfg.push.subject, source: 'db' };
    const k = WP.generateVapidKeys(); q("INSERT INTO kv(k,v) VALUES('vapid',?)").run(JSON.stringify(k));
    log('推送：已自动生成 VAPID 密钥并存进数据库（换服务器时连数据库一起迁移；也可以把公钥/私钥写进 .env 的 VAPID_PUBLIC_KEY / VAPID_PRIVATE_KEY）');
    return { ...k, subject: cfg.push.subject, source: 'generated' };
  })();
  const needOn = () => { if (!vapid) throw err(404, '这台服务器没开推送（PUSH_ENABLED=0）', 'push_off'); };
  const byEndpoint = ep => q('SELECT * FROM push_subs WHERE endpoint=?').get(String(ep || ''));
  const needSub = ep => { const r = byEndpoint(ep); if (!r) throw err(404, '没有这个提醒订阅（可能已过期，请在「我的 → 学习提醒」重新打开）', 'no_sub'); return r; };

  /** 本机报来的当天状态 → 要更新的列 */
  function stateCols(b) {
    const o = {};
    if (DATE.test(b.metDate || '')) o.met_date = b.metDate;
    if (DATE.test(b.studiedDate || '')) o.studied_date = b.studiedDate;
    if (b.streak !== undefined) o.streak = Math.max(0, Math.min(100000, Math.round(+b.streak || 0)));
    if (b.freezes !== undefined) o.freezes = Math.max(0, Math.min(1000, Math.round(+b.freezes || 0)));
    if (b.due && typeof b.due === 'object' && !Array.isArray(b.due)) {
      const d = Object.fromEntries(Object.entries(b.due).filter(([k, v]) => DATE.test(k) && Number.isFinite(+v)).slice(0, 16).map(([k, v]) => [k, Math.max(0, Math.min(1e6, Math.round(+v)))]));
      o.due_json = JSON.stringify(d);
    }
    return o;
  }
  const setCols = (id, cols) => { const ks = Object.keys(cols); if (!ks.length) return; q(`UPDATE push_subs SET ${ks.map(k => k + '=?').join(', ')} WHERE id=?`).run(...ks.map(k => cols[k]), id); };
  const tzCols = b => { const o = {}; if (typeof b.tz === 'string' && b.tz.length < 60) o.tz = b.tz; if (b.tzOffset !== undefined) o.tz_offset = Math.max(-840, Math.min(840, Math.round(+b.tzOffset || 0))); return o; };

  async function sendOne(row, payload, { source = 'tick', date, at = clock() } = {}) {
    const d = date || localNow(at, { tz: row.tz, tzOffset: row.tz_offset || 0 }).date; const ts = Math.floor(at / 1000);
    const logId = q('INSERT INTO push_log(sub_id,kind,local_date,ts,status,source) VALUES(?,?,?,?,?,?)').run(row.id, payload.kind || 'test', d, ts, -1, source).lastInsertRowid; // 先记下：发送失败也不会一分钟后狂发
    const ttl = payload.kind === 'test' ? 600 : row.prefs ? 2 * 3600 : 4 * 3600;
    let r; try { r = await WP.sendPush({ endpoint: row.endpoint, keys: { p256dh: row.p256dh, auth: row.auth } }, payload, vapid, { fetchImpl: pushFetch, ttl, topic: payload.tag?.replace(/[^A-Za-z0-9_-]/g, '').slice(0, 32), urgency: ['late', 'streak', 'evening'].includes(payload.kind) ? 'high' : 'normal', nowS: nowS() }); }
    catch (e) { r = { status: 0, ok: false, gone: false, text: e.message }; }
    q('UPDATE push_log SET status=? WHERE id=?').run(r.status, logId);
    if (r.gone) { q('DELETE FROM push_subs WHERE id=?').run(row.id); log(`[推送] 订阅已失效（${r.status}），已删除 ${row.id}`); }
    else q('UPDATE push_subs SET fails=?, last_status=?, last_sent=? WHERE id=?').run(r.ok ? 0 : (row.fails || 0) + 1, r.status, ts, row.id);
    if (!r.ok && !r.gone) log(`[推送] 发送失败 ${row.id}：${r.status} ${String(r.text).slice(0, 120)}`);
    return r;
  }

  const routes = {
    // 订阅的 endpoint 本身就是“只有这台设备知道”的地址，用它当凭据：不登录、首次免登录的设备也能订阅；绑定了云同步 / 手机验证的顺带记上账号
    'GET /push/vapid': () => { needOn(); return { publicKey: vapid.publicKey }; },
    'POST /push/subscribe': ({ body, ip, user }) => {
      needOn(); limit('push:' + ip, cfg.rate.pushPerIp, '提醒设置改得太频繁了');
      const sub = body.subscription || {}; const ep = String(sub.endpoint || ''), keys = sub.keys || {};
      let u; try { u = new URL(ep); } catch { throw err(400, '推送地址不对'); }
      if (u.protocol !== 'https:' && !(cfg.push.allowHttp && u.protocol === 'http:')) throw err(400, '推送地址必须是 https');
      if (ep.length > 1000) throw err(400, '推送地址太长');
      let p256, auth; try { p256 = WP.unb64u(keys.p256dh); auth = WP.unb64u(keys.auth); } catch { throw err(400, '推送密钥格式不对'); }
      if (p256.length !== 65 || p256[0] !== 4 || auth.length < 16) throw err(400, '推送密钥格式不对');
      let prefs = null;
      if (body.prefs !== undefined) { const e = prefsError(body.prefs); if (e) throw err(400, e, 'bad_prefs'); prefs = normPrefs(body.prefs); }
      else if (parseAt(body.at) == null) throw err(400, '提醒时间格式不对（HH:MM）');
      const at = prefs ? prefs.daily.at : body.at;
      const id = H(ep).slice(0, 32); const old = q('SELECT id FROM push_subs WHERE id=?').get(id);
      const tz = typeof body.tz === 'string' && body.tz.length < 60 ? body.tz : null; const off = Math.max(-840, Math.min(840, Math.round(+body.tzOffset || 0)));
      if (old) q('UPDATE push_subs SET p256dh=?, auth=?, account_id=COALESCE(?,account_id), at=?, tz=?, tz_offset=?, late=?, updated=?, fails=0 WHERE id=?').run(keys.p256dh, keys.auth, user?.account_id || null, at, tz, off, !prefs && body.late ? 1 : 0, nowS(), id);
      else q('INSERT INTO push_subs(id,endpoint,p256dh,auth,account_id,at,tz,tz_offset,late,streak,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)').run(id, ep, keys.p256dh, keys.auth, user?.account_id || null, at, tz, off, !prefs && body.late ? 1 : 0, 0, nowS(), nowS());
      const cols = { prefs: prefs ? JSON.stringify(prefs) : null, ...stateCols(body) };
      if (typeof body.deviceId === 'string' && /^[A-Za-z0-9_-]{6,80}$/.test(body.deviceId)) cols.device_hash = devHash(body.deviceId);
      if (typeof body.billingToken === 'string' && body.billingToken) { const bu = billingUserOf(body.billingToken); if (bu) cols.billing_user = bu.id; }
      if (typeof body.platform === 'string' && /^[a-z-]{1,20}$/.test(body.platform)) cols.platform = body.platform;
      if (typeof body.appVersion === 'string' && /^[\d.]{1,12}$/.test(body.appVersion)) cols.app_ver = body.appVersion;
      setCols(id, cols);
      return { ok: true, id, created: !old, ...(prefs ? { prefs } : {}) };
    },
    // 改偏好（时间、开关、免打扰、每日上限）：不用重新订阅
    'POST /push/prefs': ({ body, ip }) => {
      needOn(); limit('push:' + ip, cfg.rate.pushPerIp, '提醒设置改得太频繁了');
      const row = needSub(body.endpoint); const e = prefsError(body.prefs); if (e) throw err(400, e, 'bad_prefs');
      const prefs = normPrefs(body.prefs); setCols(row.id, { prefs: JSON.stringify(prefs), at: prefs.daily.at, late: 0, updated: nowS(), ...tzCols(body), ...stateCols(body) });
      return { ok: true, id: row.id, prefs };
    },
    // 今天学了 / 打卡了 / 到期卡变了：告诉服务器（打卡了今天就不再催）
    'POST /push/progress': ({ body, ip }) => {
      limit('pushp:' + ip, [240, 600], '提醒进度报得太频繁了');
      const row = needSub(body.endpoint); setCols(row.id, { ...stateCols(body), ...tzCols(body), updated: nowS() });
      return { ok: true };
    },
    // 本机核对：服务器上还有没有这条订阅、偏好是什么、上次什么时候发的
    'POST /push/status': ({ body }) => {
      needOn(); const r = byEndpoint(body.endpoint); if (!r) return { ok: true, exists: false };
      return { ok: true, exists: true, id: r.id, prefs: r.prefs ? JSON.parse(r.prefs) : null, lastSent: r.last_sent ? r.last_sent * 1000 : null, lastStatus: r.last_status ?? null };
    },
    'POST /push/unsubscribe': ({ body }) => { const r = q('DELETE FROM push_subs WHERE endpoint=?').run(String(body.endpoint || '')); return { ok: true, removed: r.changes }; },
    // 发一条测试提醒（设置好后点“发一条试试”）。kind = 某种提醒时，发那种的样子（文案预览）
    'POST /push/test': async ({ body, ip }) => {
      needOn(); limit('pusht:' + ip, [5, 600], '测试提醒发得太频繁了');
      const row = needSub(body.endpoint);
      let payload;
      if (KINDS.includes(body.kind)) { let due = {}; try { due = JSON.parse(row.due_json || '{}'); } catch { } const L = localNow(clock(), { tz: row.tz, tzOffset: row.tz_offset || 0 }); const count = Math.max(1, +Object.values(due)[0] || 0); const c = copy(body.kind, { count, streak: Math.max(1, row.streak || 0), freezes: row.freezes || 0 }, 0); payload = { ...c, title: c.title + '（试发）', tag: 'zzx-test', url: URL_OF[body.kind], kind: 'test', of: body.kind, date: L.date }; }
      else { const c = copy('test'); payload = row.prefs ? { ...c, tag: 'zzx-test', url: URL_OF.test, kind: 'test' } : { title: '自主学 · 学习提醒', body: '提醒已开启 ✅ 到点我会来叫你学习～', tone: 'test', tag: 'zzx-remind-test', url: './#/', kind: 'test' }; }
      const r = await sendOne(row, payload, { source: 'test' });
      if (!r.ok) throw err(502, `推送服务返回 ${r.status}${r.gone ? '（订阅已失效，已删除）' : ''}`, 'push_failed');
      return { ok: true, status: r.status };
    },
    // ———— 管理看板（ADMIN_TOKEN） ————
    'GET /admin/push': ({ req, ip }) => { needAdmin(req, ip); return stats(); },
    'POST /admin/push/test': async ({ req, ip, body }) => {
      needAdmin(req, ip); needOn(); limit('pushta:' + ip, [20, 600], '测试推送发得太频繁了');
      const pre = String(body.id || '').trim().toLowerCase(); if (!/^[0-9a-f]{6,32}$/.test(pre)) throw err(400, '请填订阅编号（至少前 6 位）', 'bad_id');
      const rows = q('SELECT * FROM push_subs WHERE id LIKE ? LIMIT 2').all(pre + '%');
      if (!rows.length) throw err(404, '没有这个订阅编号', 'no_sub'); if (rows.length > 1) throw err(400, '编号前几位重复了，请多填几位', 'ambiguous');
      const r = await sendOne(rows[0], { title: '自主学 · 测试推送', body: '这是管理看板发出的测试推送，收到说明这台设备的提醒通道正常 ✅', tag: 'zzx-test', url: URL_OF.test, kind: 'test', of: 'admin' }, { source: 'admin' });
      return { ok: r.ok, status: r.status, gone: r.gone, id: rows[0].id, message: r.ok ? `已发出（推送服务返回 ${r.status}）` : r.gone ? `这台设备的订阅已失效（${r.status}），已自动删除` : `推送服务返回 ${r.status}：${String(r.text || '').slice(0, 120)}` };
    },
  };

  /** 检查一遍所有订阅，到点的发提醒。返回本次发出的 [{id, kind, status, body}]（测试可直接调用 server.pushTick(时刻)） */
  let ticking = false;
  async function tick(nowMs = clock()) {
    if (!vapid || ticking) return []; ticking = true; const out = [];
    try {
      q('DELETE FROM push_log WHERE ts < ?').run(Math.floor(nowMs / 1000) - keepLogDays * 86400);
      for (const row of q('SELECT * FROM push_subs WHERE fails < 20').all()) {
        let d;
        if (row.prefs) {
          const L = localNow(nowMs, { tz: row.tz, tzOffset: row.tz_offset || 0 });
          const sent = q("SELECT kind, ts FROM push_log WHERE sub_id=? AND local_date=? AND source='tick'").all(row.id, L.date);
          d = dueV2(row, nowMs, sent);
        } else {
          d = dueLegacy(row, nowMs); if (d) q(`UPDATE push_subs SET ${d.kind === 'late' ? 'late_date' : 'sent_date'}=? WHERE id=?`).run(d.date, row.id);
        }
        if (!d) continue;
        const r = await sendOne(row, d.payload, { source: 'tick', date: d.date, at: nowMs }); out.push({ id: row.id, kind: d.kind, status: r.status, body: d.payload.body, title: d.payload.title });
      }
    } finally { ticking = false; }
    return out;
  }

  /** 看板统计：订阅数（按推送服务 / 平台 / 打开的提醒种类）、近 7 天每天发了多少（成功 / 失败 / 失效清理）、最近的订阅 */
  function stats(nowMs = clock()) {
    const off = cfg.statsTzOffsetMin ?? 480; const day = ms => new Date(ms + off * 60000).toISOString().slice(0, 10);
    const subs = q('SELECT id, endpoint, prefs, tz, platform, app_ver, created, updated, last_sent, last_status, fails, account_id, billing_user, device_hash FROM push_subs ORDER BY created DESC').all();
    const by = {}; const kinds = Object.fromEntries(KINDS.map(k => [k, 0])); let v2 = 0;
    for (const s of subs) { const sv = serviceOf(s.endpoint); by[sv] = (by[sv] || 0) + 1; if (s.prefs) { v2++; try { const p = JSON.parse(s.prefs); for (const k of KINDS) if (p[k]?.on) kinds[k]++; } catch { } } }
    const since = Math.floor(nowMs / 1000) - 7 * 86400; const logs = q('SELECT kind, ts, status, source FROM push_log WHERE ts >= ?').all(since);
    const days = Array.from({ length: 7 }, (_, i) => day(nowMs - (6 - i) * 86400000)); const per = Object.fromEntries(days.map(d => [d, { date: d, ok: 0, failed: 0, gone: 0, kinds: {} }]));
    for (const l of logs) { const x = per[day(l.ts * 1000)]; if (!x) continue; if (l.status >= 200 && l.status < 300) { x.ok++; x.kinds[l.kind] = (x.kinds[l.kind] || 0) + 1; } else if (l.status === 404 || l.status === 410) x.gone++; else if (l.status !== -1) x.failed++; }
    const active7 = subs.filter(s => (s.updated || 0) >= since).length;
    return {
      enabled: !!vapid, vapid: vapid ? { source: vapid.source, keyTail: vapid.publicKey.slice(-8), subject: vapid.subject } : null,
      total: subs.length, v2, legacy: subs.length - v2, active7, failing: subs.filter(s => s.fails > 0).length,
      services: Object.entries(by).map(([k, n]) => ({ key: k, name: SERVICE_LABEL[k], n })).sort((a, b) => b.n - a.n), kinds, kindLabels: Object.fromEntries(KINDS.map(k => [k, ({ daily: '每日学习', review: '复习到期', streak: '连续将断', evening: '晚间补提醒' })[k]])),
      days: days.map(d => per[d]), sent7: Object.values(per).reduce((a, x) => a + x.ok, 0), gone7: Object.values(per).reduce((a, x) => a + x.gone, 0),
      recent: subs.slice(0, 30).map(s => ({ id: s.id, service: serviceOf(s.endpoint), tz: s.tz, platform: s.platform || '', appVersion: s.app_ver || '', created: s.created * 1000, lastSent: s.last_sent ? s.last_sent * 1000 : null, lastStatus: s.last_status ?? null, fails: s.fails || 0, v2: !!s.prefs, account: !!s.account_id, billing: !!s.billing_user, device: s.device_hash ? s.device_hash.slice(0, 8) : '' })),
    };
  }
  return { routes, tick, stats, sendOne, vapid };
}
