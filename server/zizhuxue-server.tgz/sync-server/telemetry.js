// v1.9.2 匿名使用统计 + 管理看板。只记“哪台匿名设备在哪天做了哪类事”，不记学习内容、姓名、邮箱、IP。
// 设备：前端随机生成的匿名 ID（和云同步的设备 ID 无关），服务器只存它加盐后的哈希（盐在 kv 表里，每台服务器不同）。
// 接口：POST /api/v1/telemetry（不需要登录，限流，一次最多 20 条）；GET /api/v1/admin/stats（ADMIN_TOKEN）；看板页面 GET /admin/stats。
import crypto from 'node:crypto';

export const EVENTS = ['open', 'import', 'study', 'quiz', 'review', 'share'];
export const LEARN = ['study', 'quiz', 'review'];
export const SOURCES = ['wechat', 'qq', 'weibo', 'ios-app', 'android-app', 'desktop-app', 'pwa', 'direct', 'site', 'other'];
export const PLATFORMS = ['ios', 'android', 'mac', 'windows', 'linux', 'other'];
export const SOURCE_NAMES = { wechat: '微信', qq: 'QQ', weibo: '微博', 'ios-app': 'iPhone App', 'android-app': '安卓 App', 'desktop-app': '电脑客户端', pwa: '主屏图标（已安装网页）', direct: '直接打开 / 浏览器', site: '其他网站链接', other: '其他' };
export const EVENT_NAMES = { open: '打开', import: '导入材料', study: '学课文', quiz: '测验', review: '复习', share: '生成分享卡片' };
export const PLATFORM_NAMES = { ios: 'iPhone / iPad', android: '安卓', mac: 'Mac', windows: 'Windows', linux: 'Linux', other: '其他' };
export const MAX_BATCH = 20;

/** 迁移 7：匿名事件表 + 每台匿名设备一行（首次来源、平台、最近版本） */
export const MIGRATION_7 = `CREATE TABLE IF NOT EXISTS telemetry(id INTEGER PRIMARY KEY AUTOINCREMENT, device_hash TEXT NOT NULL, event TEXT NOT NULL, referrer TEXT, ref_domain TEXT, platform TEXT, app_version TEXT, created_at INT NOT NULL, day TEXT NOT NULL);
   CREATE INDEX IF NOT EXISTS telemetry_day ON telemetry(day, event);
   CREATE INDEX IF NOT EXISTS telemetry_dev ON telemetry(device_hash, day);
   CREATE TABLE IF NOT EXISTS telemetry_devices(device_hash TEXT PRIMARY KEY, first_at INT, first_day TEXT, referrer TEXT, ref_domain TEXT, platform TEXT, last_at INT, last_day TEXT, app_version TEXT);`;

const clean = (v, set, d = 'other') => set.includes(v) ? v : d;
const domainOf = s => { const m = /^[a-z0-9.-]{1,100}$/i.exec(String(s || '').trim().toLowerCase().replace(/^www\./, '')); return m && m[0].includes('.') ? m[0] : null; };
export const dayOf = (ms, offMin) => new Date(ms + offMin * 60000).toISOString().slice(0, 10);
const addDay = (d, n) => new Date(Date.parse(d + 'T00:00:00Z') + n * 864e5).toISOString().slice(0, 10);

export function createTelemetry({ q, cfg, clock, err, limit, tx, log = () => { } }) {
  const off = cfg.statsTzOffsetMin ?? 480;
  const salt = (() => { const r = q("SELECT v FROM kv WHERE k='telemetry_salt'").get(); if (r) return r.v; const s = crypto.randomBytes(24).toString('hex'); q("INSERT INTO kv(k,v) VALUES('telemetry_salt',?)").run(s); return s; })();
  const devHash = id => crypto.createHash('sha256').update(salt + ':' + id).digest('hex').slice(0, 32);
  const tokenOk = t => { const a = cfg.adminToken || ''; return !!a && typeof t === 'string' && t.length === a.length && crypto.timingSafeEqual(Buffer.from(t), Buffer.from(a)); };
  /** 管理口令：Authorization: Bearer 口令，或 ?token=口令 */
  function needAdmin(req, ip) {
    if (!cfg.adminToken) throw err(404, '管理看板没开：服务器没设置 ADMIN_TOKEN', 'admin_off');
    const u = new URL(req.url, 'http://x'); const t = (/^Bearer (\S+)$/.exec(req.headers.authorization || '') || [])[1] || u.searchParams.get('token') || '';
    if (!tokenOk(t)) { limit('adminfail:' + ip, [20, 600], '口令错太多次了'); throw err(401, '管理口令不对', 'unauth'); }
  }

  /** 收一批事件（返回收下了几条）。不合规的单条静默丢掉 */
  function ingest(body, ip) {
    if (!cfg.telemetry) return { ok: true, accepted: 0, off: true };
    limit('tel:' + ip, cfg.rate.telemetryPerIp, '上报太频繁');
    if (JSON.stringify(body || {}).length > 6000) throw err(413, '上报数据太大', 'too_big');
    const id = String(body.d || ''); if (!/^[A-Za-z0-9_-]{8,64}$/.test(id)) throw err(400, '设备标识不对', 'bad_device');
    const evs = Array.isArray(body.e) ? body.e : []; if (!evs.length) return { ok: true, accepted: 0 };
    if (evs.length > MAX_BATCH) throw err(413, `一次最多 ${MAX_BATCH} 条`, 'too_many');
    const dh = devHash(id); limit('teld:' + dh, cfg.rate.telemetryPerDevice, '上报太频繁');
    const now = clock(), ver = /^[0-9][0-9.]{0,15}[a-z0-9-]{0,8}$/i.test(String(body.v || '')) ? String(body.v) : null;
    const src = clean(String(body.src || ''), SOURCES), ref = src === 'site' ? domainOf(body.ref) : null, plat = clean(String(body.p || ''), PLATFORMS);
    let n = 0;
    tx(() => {
      for (const x of evs) {
        const ev = typeof x === 'string' ? x : x?.e; if (!EVENTS.includes(ev)) continue;
        let t = +(x?.t) || now; if (t > now + 5 * 60000 || t < now - 7 * 864e5) t = now; // 离线攒下的事件：7 天内按当时的时间算
        const day = dayOf(t, off);
        q('INSERT INTO telemetry(device_hash,event,referrer,ref_domain,platform,app_version,created_at,day) VALUES(?,?,?,?,?,?,?,?)').run(dh, ev, src, ref, plat, ver, Math.floor(t / 1000), day);
        q(`INSERT INTO telemetry_devices(device_hash,first_at,first_day,referrer,ref_domain,platform,last_at,last_day,app_version) VALUES(?,?,?,?,?,?,?,?,?)
           ON CONFLICT(device_hash) DO UPDATE SET first_at=MIN(first_at,excluded.first_at), first_day=MIN(first_day,excluded.first_day),
             last_at=MAX(last_at,excluded.last_at), last_day=MAX(last_day,excluded.last_day), platform=excluded.platform, app_version=COALESCE(excluded.app_version,app_version)`)
          .run(dh, Math.floor(t / 1000), day, src, ref, plat, Math.floor(t / 1000), day, ver);
        n++;
      }
    });
    return { ok: true, accepted: n };
  }

  /** 看板数字（nowMs 可指定，测试用） */
  function stats(nowMs = clock()) {
    const today = dayOf(nowMs, off), yest = addDay(today, -1), d7 = addDay(today, -6), d30 = addDay(today, -29);
    const one = (sql, ...a) => q(sql).get(...a)?.n || 0;
    const active = (from, to = today) => one('SELECT COUNT(DISTINCT device_hash) n FROM telemetry WHERE day BETWEEN ? AND ?', from, to);
    const learnersIn = (from, to = today) => one(`SELECT COUNT(DISTINCT device_hash) n FROM telemetry WHERE event IN ('study','quiz','review') AND day BETWEEN ? AND ?`, from, to);
    const evUsers = ev => one('SELECT COUNT(DISTINCT device_hash) n FROM telemetry WHERE event=?', ev);
    const totalDevices = one('SELECT COUNT(*) n FROM telemetry_devices');
    const learners = one(`SELECT COUNT(DISTINCT device_hash) n FROM telemetry WHERE event IN ('study','quiz','review')`);
    const per = sql => Object.fromEntries(q(sql).all(d30, today).map(r => [r.day, r.n]));
    const act = per('SELECT day, COUNT(DISTINCT device_hash) n FROM telemetry WHERE day BETWEEN ? AND ? GROUP BY day');
    const lrn = per(`SELECT day, COUNT(DISTINCT device_hash) n FROM telemetry WHERE event IN ('study','quiz','review') AND day BETWEEN ? AND ? GROUP BY day`);
    const imp = per(`SELECT day, COUNT(DISTINCT device_hash) n FROM telemetry WHERE event='import' AND day BETWEEN ? AND ? GROUP BY day`);
    const nw = per('SELECT first_day day, COUNT(*) n FROM telemetry_devices WHERE first_day BETWEEN ? AND ? GROUP BY first_day');
    const daily = []; for (let i = 29; i >= 0; i--) { const d = addDay(today, -i); daily.push({ day: d, active: act[d] || 0, learners: lrn[d] || 0, importers: imp[d] || 0, newDevices: nw[d] || 0 }); }
    const dist = (col, names) => q(`SELECT COALESCE(${col},'未知') k, COUNT(*) n FROM telemetry_devices GROUP BY k ORDER BY n DESC`).all().map(r => ({ key: r.k, name: names?.[r.k] || r.k, devices: r.n }));
    const tableN = t => { try { return one(`SELECT COUNT(*) n FROM ${t}`); } catch { return 0; } };
    const dayNum = Math.floor(nowMs / 864e5);
    return {
      generatedAt: nowMs, tzOffsetMin: off, today, telemetry: !!cfg.telemetry,
      totals: {
        devices: totalDevices, today: active(today), yesterday: active(yest, yest), last7: active(d7), last30: active(d30),
        openedToday: one(`SELECT COUNT(DISTINCT device_hash) n FROM telemetry WHERE event='open' AND day=?`, today),
        importers: evUsers('import'), learners, learnersToday: learnersIn(today), learners7: learnersIn(d7), learners30: learnersIn(d30),
        reviewers: evUsers('review'), quizzers: evUsers('quiz'), studiers: evUsers('study'), sharers: evUsers('share'),
        newToday: one('SELECT COUNT(*) n FROM telemetry_devices WHERE first_day=?', today), new7: one('SELECT COUNT(*) n FROM telemetry_devices WHERE first_day>=?', d7),
      },
      funnel: [{ step: '打开过', devices: totalDevices }, { step: '导入过材料', devices: evUsers('import') }, { step: '真正学习过（学课文 / 复习 / 测验）', devices: learners }, { step: '分享过', devices: evUsers('share') }],
      daily,
      sources: dist('referrer', SOURCE_NAMES),
      referrerDomains: q("SELECT ref_domain k, COUNT(*) n FROM telemetry_devices WHERE ref_domain IS NOT NULL GROUP BY ref_domain ORDER BY n DESC LIMIT 10").all().map(r => ({ domain: r.k, devices: r.n })),
      platforms: dist('platform', PLATFORM_NAMES),
      versions: q("SELECT COALESCE(app_version,'未知') k, COUNT(*) n FROM telemetry_devices WHERE last_day>=? GROUP BY k ORDER BY n DESC").all(d30).map(r => ({ version: r.k, devices: r.n })),
      events30: Object.fromEntries(EVENTS.map(e => [e, one('SELECT COUNT(*) n FROM telemetry WHERE event=? AND day>=?', e, d30)])),
      sync: { accounts: tableN('accounts'), devices: tableN('devices'), records: tableN('records'), pushSubs: tableN('push_subs') },
      license: {
        codesActivated: one('SELECT COUNT(*) n FROM licenses WHERE account_id IS NOT NULL'), codesRevoked: (() => { try { return one('SELECT COUNT(*) n FROM licenses WHERE revoked=1'); } catch { return 0; } })(),
        subscriptionsActive: (() => { try { return one('SELECT COUNT(*) n FROM subscriptions WHERE exp_day>=?', dayNum); } catch { return 0; } })(),
        trialDevices: one("SELECT COUNT(*) n FROM trials WHERE subject LIKE 'd:%'"), licensedDevices: tableN('license_devices'),
      },
      feedback: { total: tableN('feedback'), items: q('SELECT id,created,type,text,contact,page FROM feedback ORDER BY created DESC LIMIT 30').all().map(r => ({ id: r.id, created: r.created * 1000, type: r.type, text: String(r.text || '').slice(0, 500), contact: r.contact || '', page: r.page || '' })) },
    };
  }

  const routes = {
    'POST /telemetry': ({ body, ip }) => ingest(body, ip),
    'GET /admin/stats': ({ req, ip }) => { needAdmin(req, ip); return stats(); },
  };
  return { routes, ingest, stats, devHash, needAdmin };
}

/** 管理看板（极简单页，不引用任何外部资源；口令存在这个浏览器的 localStorage 里） */
export const DASHBOARD_HTML = `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow">
<title>自主学 · 管理看板</title><style>
:root{--ac:#1f6f5c;--bg:#f4f1ea;--mu:#6b746f}*{box-sizing:border-box}body{margin:0;font:15px/1.5 -apple-system,"PingFang SC","Noto Sans CJK SC","Microsoft YaHei",sans-serif;background:var(--bg);color:#1d2b27}
header{background:var(--ac);color:#fff;padding:14px 16px;display:flex;align-items:center;gap:10px;flex-wrap:wrap}header h1{font-size:19px;margin:0;flex:1 1 auto;white-space:nowrap}#at{font-size:12px;order:3;flex-basis:100%}@media(min-width:700px){#at{order:0;flex-basis:auto}}header button{background:#fff2;color:#fff;border:1px solid #fff6;border-radius:8px;padding:8px 12px;font-size:14px;min-height:40px}
main{max-width:1080px;margin:0 auto;padding:12px}.card{background:#fff;border-radius:14px;padding:14px 16px;margin:12px 0;box-shadow:0 1px 3px #0001}.card h2{font-size:16px;margin:0 0 10px}
.nums{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px}.num{background:#f2faf7;border-radius:12px;padding:10px 12px}.num b{display:block;font-size:28px;color:var(--ac);line-height:1.2}.num span{color:var(--mu);font-size:13px}
.num.hot{background:#fff7d6}table{width:100%;border-collapse:collapse;font-size:14px}th,td{padding:6px 8px;border-bottom:1px solid #eee;text-align:left;vertical-align:top}th{color:var(--mu);font-weight:600}td.n,th.n{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}
.bar{height:8px;border-radius:4px;background:var(--ac);opacity:.75;min-width:2px}.bar.l{background:#f0a500}.scroll{overflow-x:auto}.muted{color:var(--mu);font-size:13px}.two{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:0 14px}
form{display:flex;gap:8px;flex-wrap:wrap}input{flex:1;min-width:200px;font-size:16px;padding:10px;border:1px solid #ccc;border-radius:10px}form button{background:var(--ac);color:#fff;border:0;border-radius:10px;padding:10px 18px;font-size:16px;min-height:44px}
.err{color:#b42318}.fb{border-bottom:1px solid #eee;padding:8px 0}.fb:last-child{border:0}.tag{display:inline-block;font-size:12px;border-radius:6px;padding:0 6px;background:#eef;margin-right:6px}
</style></head><body><header><h1>自主学 · 管理看板</h1><span id="at" class="muted" style="color:#dff"></span><button id="re" hidden>刷新</button><button id="out" hidden>退出</button></header><main id="m"></main>
<script>
const K='zzx.admin.token', API=new URL('../api/v1/admin/stats', location.href).href, m=document.getElementById('m');
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const u=new URL(location.href); if(u.searchParams.get('token')){localStorage.setItem(K,u.searchParams.get('token'));u.searchParams.delete('token');history.replaceState(null,'',u.pathname+u.search);}
function login(msg){document.getElementById('re').hidden=document.getElementById('out').hidden=true;m.innerHTML='<div class="card"><h2>输入管理口令</h2><p class="muted">口令是服务器 .env 里的 ADMIN_TOKEN。输入一次，这个浏览器会记住（点右上角“退出”清除）。</p><form id="f"><input id="t" type="password" autocomplete="current-password" placeholder="管理口令" required><button>查看</button></form>'+(msg?'<p class="err" id="lerr">'+esc(msg)+'</p>':'')+'</div>';document.getElementById('f').onsubmit=e=>{e.preventDefault();localStorage.setItem(K,document.getElementById('t').value.trim());load();};}
const num=(v,l,hot)=>'<div class="num'+(hot?' hot':'')+'"><b>'+esc(v)+'</b><span>'+esc(l)+'</span></div>';
const dist=(rows,k,label)=>{const mx=Math.max(1,...rows.map(r=>r.devices));return '<table><tr><th>'+label+'</th><th class="n">设备</th><th style="width:40%"></th></tr>'+(rows.length?rows.map(r=>'<tr><td>'+esc(r[k])+'</td><td class="n">'+r.devices+'</td><td><div class="bar" style="width:'+(100*r.devices/mx)+'%"></div></td></tr>').join(''):'<tr><td colspan="3" class="muted">还没有数据</td></tr>')+'</table>';};
async function load(){const t=localStorage.getItem(K);if(!t)return login();m.innerHTML='<p class="muted">加载中…</p>';let r,j;try{r=await fetch(API,{headers:{Authorization:'Bearer '+t},cache:'no-store'});j=await r.json();}catch(e){m.innerHTML='<div class="card err">连不上服务器：'+esc(e.message)+'</div>';return;}
if(r.status===401){localStorage.removeItem(K);return login(j.error||'口令不对');}if(!r.ok){m.innerHTML='<div class="card err">'+esc(j.error||r.status)+'</div>';return;}render(j);}
function render(s){const T=s.totals;document.getElementById('re').hidden=document.getElementById('out').hidden=false;document.getElementById('at').textContent='更新于 '+new Date(s.generatedAt+s.tzOffsetMin*60000).toISOString().slice(0,16).replace('T',' ')+'（按 UTC'+(s.tzOffsetMin>=0?'+':'')+s.tzOffsetMin/60+' 算今天）';
const mx=Math.max(1,...s.daily.map(d=>d.active));
m.innerHTML='<div class="card" id="core"><h2>核心数字</h2><div class="nums">'+num(T.devices,'累计设备（用过的人）',1)+num(T.today,'今天打开')+num(T.yesterday,'昨天打开')+num(T.last7,'近 7 天打开')+num(T.last30,'近 30 天打开')+num(T.learners,'真正学习过的人',1)+num(T.learnersToday,'今天在学')+num(T.learners7,'近 7 天在学')+num(T.importers,'导入过材料')+num(T.newToday,'今天新来')+num(T.new7,'近 7 天新来')+num(T.sharers,'分享过')+'</div>'+(s.telemetry?'':'<p class="err">服务器关了统计（TELEMETRY_ENABLED=0）</p>')+'<p class="muted">“打开”= 这台设备当天打开过自主学；“真正学习”= 学完课文一段、做完一组复习或测验。同一台设备只算 1 人（换手机 / 换浏览器 / 清数据会算新的一台）。</p></div>'
+'<div class="card"><h2>转化</h2><table>'+s.funnel.map(f=>'<tr><td>'+esc(f.step)+'</td><td class="n">'+f.devices+'</td><td class="n muted">'+(s.funnel[0].devices?Math.round(100*f.devices/s.funnel[0].devices):0)+'%</td></tr>').join('')+'</table></div>'
+'<div class="card"><h2>最近 30 天每天</h2><div class="scroll"><table id="daily"><tr><th>日期</th><th class="n">打开</th><th class="n">真正学习</th><th class="n">导入</th><th class="n">新设备</th><th style="min-width:110px"></th></tr>'+s.daily.slice().reverse().map(d=>'<tr><td>'+d.day.slice(5)+'</td><td class="n">'+d.active+'</td><td class="n">'+d.learners+'</td><td class="n">'+d.importers+'</td><td class="n">'+d.newDevices+'</td><td><div class="bar" style="width:'+(100*d.active/mx)+'%"></div><div class="bar l" style="width:'+(100*d.learners/mx)+'%;margin-top:2px"></div></td></tr>').join('')+'</table></div><p class="muted">绿条 = 打开，橙条 = 真正学习</p></div>'
+'<div class="two"><div class="card" id="src"><h2>从哪来（第一次打开时）</h2>'+dist(s.sources,'name','来源')+(s.referrerDomains.length?'<p class="muted">其他网站：'+s.referrerDomains.map(d=>esc(d.domain)+' '+d.devices).join('，')+'</p>':'')+'</div>'
+'<div class="card"><h2>设备类型</h2>'+dist(s.platforms,'name','平台')+'<h2 style="margin-top:14px">版本（近 30 天用过的）</h2>'+dist(s.versions,'version','版本')+'</div></div>'
+'<div class="two"><div class="card"><h2>云同步 / 激活码</h2><table><tr><td>同步账户</td><td class="n">'+s.sync.accounts+'</td></tr><tr><td>同步设备</td><td class="n">'+s.sync.devices+'</td></tr><tr><td>同步记录</td><td class="n">'+s.sync.records+'</td></tr><tr><td>学习提醒订阅</td><td class="n">'+s.sync.pushSubs+'</td></tr><tr><td>已激活的激活码</td><td class="n">'+s.license.codesActivated+'</td></tr><tr><td>作废的激活码</td><td class="n">'+s.license.codesRevoked+'</td></tr><tr><td>有效订阅</td><td class="n">'+s.license.subscriptionsActive+'</td></tr><tr><td>试用对过账的设备</td><td class="n">'+s.license.trialDevices+'</td></tr></table><p class="muted">只统计绑定了云同步的用户；没绑定的激活码在本机离线验证，服务器看不到。</p></div>'
+'<div class="card"><h2>近 30 天事件数</h2><table>'+Object.entries(s.events30).map(([k,v])=>'<tr><td>'+esc({open:'打开',import:'导入材料',study:'学课文',quiz:'测验',review:'复习',share:'生成分享卡片'}[k]||k)+'</td><td class="n">'+v+'</td></tr>').join('')+'</table></div></div>'
+'<div class="card" id="fbl"><h2>用户反馈（共 '+s.feedback.total+' 条，最新 30 条）</h2>'+(s.feedback.items.length?s.feedback.items.map(f=>'<div class="fb"><span class="tag">'+esc({bug:'问题',idea:'建议',other:'其他'}[f.type]||f.type)+'</span><span class="muted">'+new Date(f.created).toLocaleString('zh-CN',{hour12:false})+(f.contact?' · 联系：'+esc(f.contact):'')+'</span><div>'+esc(f.text)+'</div></div>').join(''):'<p class="muted">还没有反馈</p>')+'<p class="muted">截图等详情：GET /api/v1/feedback?id=编号（同一个口令）</p></div>';}
document.getElementById('re').onclick=load;document.getElementById('out').onclick=()=>{localStorage.removeItem(K);login();};load();
</script></body></html>`;
