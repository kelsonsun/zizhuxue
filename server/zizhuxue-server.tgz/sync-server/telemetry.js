// v1.9.2 匿名使用统计 + 管理看板。只记“哪台匿名设备在哪天做了哪类事”，不记学习内容、姓名、邮箱、IP。
// 设备：前端随机生成的匿名 ID（和云同步的设备 ID 无关），服务器只存它加盐后的哈希（盐在 kv 表里，每台服务器不同）。
// 接口：POST /api/v1/telemetry（不需要登录，限流，一次最多 20 条）；GET /api/v1/admin/stats（ADMIN_TOKEN）；看板页面 GET /admin/stats。
import crypto from 'node:crypto';

export const EVENTS = ['open', 'import', 'study', 'quiz', 'review', 'share', 'ai_own_ok', 'ai_own_fail', 'ai_fallback'];
export const LEARN = ['study', 'quiz', 'review'];
export const SOURCES = ['wechat', 'qq', 'weibo', 'ios-app', 'android-app', 'desktop-app', 'pwa', 'direct', 'site', 'other'];
export const PLATFORMS = ['ios', 'android', 'mac', 'windows', 'linux', 'other'];
export const SOURCE_NAMES = { wechat: '微信', qq: 'QQ', weibo: '微博', 'ios-app': 'iPhone App', 'android-app': '安卓 App', 'desktop-app': '电脑客户端', pwa: '主屏图标（已安装网页）', direct: '直接打开 / 浏览器', site: '其他网站链接', other: '其他' };
export const EVENT_NAMES = { open: '打开', import: '导入材料', study: '学课文', quiz: '测验', review: '复习', share: '生成分享卡片', ai_own_ok: '自己密钥调用 AI 成功', ai_own_fail: '自己密钥调用 AI 失败', ai_fallback: '内置 AI 改用免费翻译' };
export const PLATFORM_NAMES = { ios: 'iPhone / iPad', android: '安卓', mac: 'Mac', windows: 'Windows', linux: 'Linux', other: '其他' };
export const MAX_BATCH = 20;

/** 迁移 7：匿名事件表 + 每台匿名设备一行（首次来源、平台、最近版本） */
export const MIGRATION_7 = `CREATE TABLE IF NOT EXISTS telemetry(id INTEGER PRIMARY KEY AUTOINCREMENT, device_hash TEXT NOT NULL, event TEXT NOT NULL, referrer TEXT, ref_domain TEXT, platform TEXT, app_version TEXT, created_at INT NOT NULL, day TEXT NOT NULL);
   CREATE INDEX IF NOT EXISTS telemetry_day ON telemetry(day, event);
   CREATE INDEX IF NOT EXISTS telemetry_dev ON telemetry(device_hash, day);
   CREATE TABLE IF NOT EXISTS telemetry_devices(device_hash TEXT PRIMARY KEY, first_at INT, first_day TEXT, referrer TEXT, ref_domain TEXT, platform TEXT, last_at INT, last_day TEXT, app_version TEXT);`;

const clean = (v, set, d = 'other') => set.includes(v) ? v : d;
const domainOf = s => { const m = /^[a-z0-9.-]{1,100}$/i.exec(String(s || '').trim().toLowerCase().replace(/^www\./, '')); return m && m[0].includes('.') ? m[0] : null; };
export const dayOf = (ms, offMin) => new Date(ms + offMin * 60000).toISOString().slice(0, 10);
const addDay = (d, n) => new Date(Date.parse(d + 'T00:00:00Z') + n * 864e5).toISOString().slice(0, 10);

export function createTelemetry({ q, cfg, clock, err, limit, tx, log = () => { } }) {
  const off = cfg.statsTzOffsetMin ?? 480;
  const salt = (() => { const r = q("SELECT v FROM kv WHERE k='telemetry_salt'").get(); if (r) return r.v; const s = crypto.randomBytes(24).toString('hex'); q("INSERT INTO kv(k,v) VALUES('telemetry_salt',?)").run(s); return s; })();
  const devHash = id => crypto.createHash('sha256').update(salt + ':' + id).digest('hex').slice(0, 32);
  const tokenOk = t => { const a = cfg.adminToken || ''; return !!a && typeof t === 'string' && t.length === a.length && crypto.timingSafeEqual(Buffer.from(t), Buffer.from(a)); };
  /** 管理口令：Authorization: Bearer 口令，或 ?token=口令 */
  function needAdmin(req, ip) {
    if (!cfg.adminToken) throw err(404, '管理看板没开：服务器没设置 ADMIN_TOKEN', 'admin_off');
    const u = new URL(req.url, 'http://x'); const t = (/^Bearer (\S+)$/.exec(req.headers.authorization || '') || [])[1] || u.searchParams.get('token') || '';
    if (!tokenOk(t)) { limit('adminfail:' + ip, [20, 600], '口令错太多次了'); throw err(401, '管理口令不对', 'unauth'); }
  }

  /** 收一批事件（返回收下了几条）。不合规的单条静默丢掉 */
  function ingest(body, ip) {
    if (!cfg.telemetry) return { ok: true, accepted: 0, off: true };
    limit('tel:' + ip, cfg.rate.telemetryPerIp, '上报太频繁');
    if (JSON.stringify(body || {}).length > 6000) throw err(413, '上报数据太大', 'too_big');
    const id = String(body.d || ''); if (!/^[A-Za-z0-9_-]{8,64}$/.test(id)) throw err(400, '设备标识不对', 'bad_device');
    const evs = Array.isArray(body.e) ? body.e : []; if (!evs.length) return { ok: true, accepted: 0 };
    if (evs.length > MAX_BATCH) throw err(413, `一次最多 ${MAX_BATCH} 条`, 'too_many');
    const dh = devHash(id); limit('teld:' + dh, cfg.rate.telemetryPerDevice, '上报太频繁');
    const now = clock(), ver = /^[0-9][0-9.]{0,15}[a-z0-9-]{0,8}$/i.test(String(body.v || '')) ? String(body.v) : null;
    const src = clean(String(body.src || ''), SOURCES), ref = src === 'site' ? domainOf(body.ref) : null, plat = clean(String(body.p || ''), PLATFORMS);
    let n = 0;
    tx(() => {
      for (const x of evs) {
        const ev = typeof x === 'string' ? x : x?.e; if (!EVENTS.includes(ev)) continue;
        let t = +(x?.t) || now; if (t > now + 5 * 60000 || t < now - 7 * 864e5) t = now; // 离线攒下的事件：7 天内按当时的时间算
        const day = dayOf(t, off);
        q('INSERT INTO telemetry(device_hash,event,referrer,ref_domain,platform,app_version,created_at,day) VALUES(?,?,?,?,?,?,?,?)').run(dh, ev, src, ref, plat, ver, Math.floor(t / 1000), day);
        q(`INSERT INTO telemetry_devices(device_hash,first_at,first_day,referrer,ref_domain,platform,last_at,last_day,app_version) VALUES(?,?,?,?,?,?,?,?,?)
           ON CONFLICT(device_hash) DO UPDATE SET first_at=MIN(first_at,excluded.first_at), first_day=MIN(first_day,excluded.first_day),
             last_at=MAX(last_at,excluded.last_at), last_day=MAX(last_day,excluded.last_day), platform=excluded.platform, app_version=COALESCE(excluded.app_version,app_version)`)
          .run(dh, Math.floor(t / 1000), day, src, ref, plat, Math.floor(t / 1000), day, ver);
        n++;
      }
    });
    return { ok: true, accepted: n };
  }

  /** 看板数字（nowMs 可指定，测试用） */
  function stats(nowMs = clock()) {
    const today = dayOf(nowMs, off), yest = addDay(today, -1), d7 = addDay(today, -6), d30 = addDay(today, -29);
    const one = (sql, ...a) => q(sql).get(...a)?.n || 0;
    const active = (from, to = today) => one('SELECT COUNT(DISTINCT device_hash) n FROM telemetry WHERE day BETWEEN ? AND ?', from, to);
    const learnersIn = (from, to = today) => one(`SELECT COUNT(DISTINCT device_hash) n FROM telemetry WHERE event IN ('study','quiz','review') AND day BETWEEN ? AND ?`, from, to);
    const evUsers = ev => one('SELECT COUNT(DISTINCT device_hash) n FROM telemetry WHERE event=?', ev);
    const totalDevices = one('SELECT COUNT(*) n FROM telemetry_devices');
    const learners = one(`SELECT COUNT(DISTINCT device_hash) n FROM telemetry WHERE event IN ('study','quiz','review')`);
    const per = sql => Object.fromEntries(q(sql).all(d30, today).map(r => [r.day, r.n]));
    const act = per('SELECT day, COUNT(DISTINCT device_hash) n FROM telemetry WHERE day BETWEEN ? AND ? GROUP BY day');
    const lrn = per(`SELECT day, COUNT(DISTINCT device_hash) n FROM telemetry WHERE event IN ('study','quiz','review') AND day BETWEEN ? AND ? GROUP BY day`);
    const imp = per(`SELECT day, COUNT(DISTINCT device_hash) n FROM telemetry WHERE event='import' AND day BETWEEN ? AND ? GROUP BY day`);
    const nw = per('SELECT first_day day, COUNT(*) n FROM telemetry_devices WHERE first_day BETWEEN ? AND ? GROUP BY first_day');
    const daily = []; for (let i = 29; i >= 0; i--) { const d = addDay(today, -i); daily.push({ day: d, active: act[d] || 0, learners: lrn[d] || 0, importers: imp[d] || 0, newDevices: nw[d] || 0 }); }
    const dist = (col, names) => q(`SELECT COALESCE(${col},'未知') k, COUNT(*) n FROM telemetry_devices GROUP BY k ORDER BY n DESC`).all().map(r => ({ key: r.k, name: names?.[r.k] || r.k, devices: r.n }));
    const tableN = t => { try { return one(`SELECT COUNT(*) n FROM ${t}`); } catch { return 0; } };
    const dayNum = Math.floor(nowMs / 864e5);
    return {
      generatedAt: nowMs, tzOffsetMin: off, today, telemetry: !!cfg.telemetry,
      totals: {
        devices: totalDevices, today: active(today), yesterday: active(yest, yest), last7: active(d7), last30: active(d30),
        openedToday: one(`SELECT COUNT(DISTINCT device_hash) n FROM telemetry WHERE event='open' AND day=?`, today),
        importers: evUsers('import'), learners, learnersToday: learnersIn(today), learners7: learnersIn(d7), learners30: learnersIn(d30),
        reviewers: evUsers('review'), quizzers: evUsers('quiz'), studiers: evUsers('study'), sharers: evUsers('share'),
        newToday: one('SELECT COUNT(*) n FROM telemetry_devices WHERE first_day=?', today), new7: one('SELECT COUNT(*) n FROM telemetry_devices WHERE first_day>=?', d7),
      },
      funnel: [{ step: '打开过', devices: totalDevices }, { step: '导入过材料', devices: evUsers('import') }, { step: '真正学习过（学课文 / 复习 / 测验）', devices: learners }, { step: '分享过', devices: evUsers('share') }],
      daily,
      sources: dist('referrer', SOURCE_NAMES),
      referrerDomains: q("SELECT ref_domain k, COUNT(*) n FROM telemetry_devices WHERE ref_domain IS NOT NULL GROUP BY ref_domain ORDER BY n DESC LIMIT 10").all().map(r => ({ domain: r.k, devices: r.n })),
      platforms: dist('platform', PLATFORM_NAMES),
      versions: q("SELECT COALESCE(app_version,'未知') k, COUNT(*) n FROM telemetry_devices WHERE last_day>=? GROUP BY k ORDER BY n DESC").all(d30).map(r => ({ version: r.k, devices: r.n })),
      events30: Object.fromEntries(EVENTS.map(e => [e, one('SELECT COUNT(*) n FROM telemetry WHERE event=? AND day>=?', e, d30)])),
      sync: { accounts: tableN('accounts'), devices: tableN('devices'), records: tableN('records'), pushSubs: tableN('push_subs') },
      license: {
        codesActivated: one('SELECT COUNT(*) n FROM licenses WHERE account_id IS NOT NULL'), codesRevoked: (() => { try { return one('SELECT COUNT(*) n FROM licenses WHERE revoked=1'); } catch { return 0; } })(),
        subscriptionsActive: (() => { try { return one('SELECT COUNT(*) n FROM subscriptions WHERE exp_day>=?', dayNum); } catch { return 0; } })(),
        trialDevices: one("SELECT COUNT(*) n FROM trials WHERE subject LIKE 'd:%'"), licensedDevices: tableN('license_devices'),
      },
      feedback: { total: tableN('feedback'), items: q('SELECT id,created,type,text,contact,page FROM feedback ORDER BY created DESC LIMIT 30').all().map(r => ({ id: r.id, created: r.created * 1000, type: r.type, text: String(r.text || '').slice(0, 500), contact: r.contact || '', page: r.page || '' })) },
    };
  }

  const routes = {
    'POST /telemetry': ({ body, ip }) => ingest(body, ip),
    'GET /admin/stats': ({ req, ip }) => { needAdmin(req, ip); return stats(); },
  };
  return { routes, ingest, stats, devHash, needAdmin };
}

/** 管理看板（极简单页，不引用任何外部资源；口令存在这个浏览器的 localStorage 里） */
export const DASHBOARD_HTML = `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow">
<link rel="manifest" href="/admin/manifest.webmanifest"><link rel="icon" href="/admin/icon-192.png"><link rel="apple-touch-icon" href="/admin/apple-touch-icon.png">
<meta name="theme-color" content="#1f6f5c"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-title" content="自主学看板"><meta name="apple-mobile-web-app-status-bar-style" content="default">
<title>自主学 · 管理看板</title><style>
:root{--ac:#1f6f5c;--bg:#f4f1ea;--mu:#6b746f}*{box-sizing:border-box}body{margin:0;font:15px/1.5 -apple-system,"PingFang SC","Noto Sans CJK SC","Microsoft YaHei",sans-serif;background:var(--bg);color:#1d2b27}
header{background:var(--ac);color:#fff;padding:14px 16px;display:flex;align-items:center;gap:10px;flex-wrap:wrap}header h1{font-size:19px;margin:0;flex:1 1 auto;white-space:nowrap}#at{font-size:12px;order:3;flex-basis:100%}@media(min-width:700px){#at{order:0;flex-basis:auto}}header button{background:#fff2;color:#fff;border:1px solid #fff6;border-radius:8px;padding:8px 12px;font-size:14px;min-height:40px}
main{max-width:1080px;margin:0 auto;padding:12px}.card{background:#fff;border-radius:14px;padding:14px 16px;margin:12px 0;box-shadow:0 1px 3px #0001}.card h2{font-size:16px;margin:0 0 10px}
.nums{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px}.num{background:#f2faf7;border-radius:12px;padding:10px 12px}.num b{display:block;font-size:28px;color:var(--ac);line-height:1.2}.num span{color:var(--mu);font-size:13px}
.num.hot{background:#fff7d6}table{width:100%;border-collapse:collapse;font-size:14px}th,td{padding:6px 8px;border-bottom:1px solid #eee;text-align:left;vertical-align:top}th{color:var(--mu);font-weight:600}td.n,th.n{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}
.bar{height:8px;border-radius:4px;background:var(--ac);opacity:.75;min-width:2px}.bar.l{background:#f0a500}.scroll{overflow-x:auto}.muted{color:var(--mu);font-size:13px}.two{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:0 14px}
form{display:flex;gap:8px;flex-wrap:wrap}input{flex:1;min-width:200px;font-size:16px;padding:10px;border:1px solid #ccc;border-radius:10px}form button{background:var(--ac);color:#fff;border:0;border-radius:10px;padding:10px 18px;font-size:16px;min-height:44px}
.err{color:#b42318}.ok{color:#1f6f5c}.grid2{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:8px 12px}.grid2 label{display:block;font-size:13px;color:var(--mu)}.grid2 input,.grid2 select{width:100%;min-width:0;min-height:44px;font-size:16px;padding:9px;border:1px solid #ccc;border-radius:10px}.btns{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}.btns button{background:var(--ac);color:#fff;border:0;border-radius:10px;padding:10px 16px;font-size:15px;min-height:44px}.btns button.sec{background:#e7eeeb;color:#1d2b27}#aiwin th,#aiwin td,#aitask th,#aitop th{white-space:nowrap}#aitask td:first-child{min-width:7em}.chk{display:flex;align-items:center;gap:8px;margin:8px 0;font-size:15px;min-height:44px}.chk input{width:22px;height:22px;min-width:0;flex:none}.fb{border-bottom:1px solid #eee;padding:8px 0}.fb:last-child{border:0}.tag{display:inline-block;font-size:12px;border-radius:6px;padding:0 6px;background:#eef;margin-right:6px}
</style></head><body><header><h1>自主学 · 管理看板</h1><span id="at" class="muted" style="color:#dff"></span><button id="re" hidden>刷新</button><button id="out" hidden>忘记口令</button></header><main id="m"></main>
<script>
const K='zzx.admin.token', API=new URL('../api/v1/admin/stats', location.href).href, m=document.getElementById('m');
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const u=new URL(location.href); if(u.search){history.replaceState(null,'',u.pathname);} /* v1.9.3 口令不走网址：网址里带的参数一律不用、并从地址栏去掉 */
function login(msg){document.getElementById('re').hidden=document.getElementById('out').hidden=true;m.innerHTML='<div class="card"><h2>输入管理口令</h2><p class="muted">口令是服务器 .env 里的 ADMIN_TOKEN。输入一次，这台手机 / 这个浏览器会一直记住（加到主屏后打开也不用再输）；点右上角“忘记口令”清除。</p><form id="f"><input id="t" type="password" autocomplete="current-password" placeholder="管理口令" required><button>查看</button></form>'+(msg?'<p class="err" id="lerr">'+esc(msg)+'</p>':'')+'</div>';document.getElementById('f').onsubmit=e=>{e.preventDefault();localStorage.setItem(K,document.getElementById('t').value.trim());load();};}
const num=(v,l,hot)=>'<div class="num'+(hot?' hot':'')+'"><b>'+esc(v)+'</b><span>'+esc(l)+'</span></div>';
const dist=(rows,k,label)=>{const mx=Math.max(1,...rows.map(r=>r.devices));return '<table><tr><th>'+label+'</th><th class="n">设备</th><th style="width:40%"></th></tr>'+(rows.length?rows.map(r=>'<tr><td>'+esc(r[k])+'</td><td class="n">'+r.devices+'</td><td><div class="bar" style="width:'+(100*r.devices/mx)+'%"></div></td></tr>').join(''):'<tr><td colspan="3" class="muted">还没有数据</td></tr>')+'</table>';};
async function load(){const t=localStorage.getItem(K);if(!t)return login();m.innerHTML='<p class="muted">加载中…</p>';let r,j;try{r=await fetch(API,{headers:{Authorization:'Bearer '+t},cache:'no-store'});j=await r.json();}catch(e){m.innerHTML='<div class="card err">连不上服务器：'+esc(e.message)+'</div>';return;}
if(r.status===401){localStorage.removeItem(K);return login(j.error||'口令不对');}if(!r.ok){m.innerHTML='<div class="card err">'+esc(j.error||r.status)+'</div>';return;}render(j);}
function render(s){const T=s.totals;document.getElementById('re').hidden=document.getElementById('out').hidden=false;document.getElementById('at').textContent='更新于 '+new Date(s.generatedAt+s.tzOffsetMin*60000).toISOString().slice(0,16).replace('T',' ')+'（按 UTC'+(s.tzOffsetMin>=0?'+':'')+s.tzOffsetMin/60+' 算今天）';
const mx=Math.max(1,...s.daily.map(d=>d.active));
m.innerHTML='<div class="card" id="core"><h2>核心数字</h2><div class="nums">'+num(T.devices,'累计设备（用过的人）',1)+num(T.today,'今天打开')+num(T.yesterday,'昨天打开')+num(T.last7,'近 7 天打开')+num(T.last30,'近 30 天打开')+num(T.learners,'真正学习过的人',1)+num(T.learnersToday,'今天在学')+num(T.learners7,'近 7 天在学')+num(T.importers,'导入过材料')+num(T.newToday,'今天新来')+num(T.new7,'近 7 天新来')+num(T.sharers,'分享过')+'</div>'+(s.telemetry?'':'<p class="err">服务器关了统计（TELEMETRY_ENABLED=0）</p>')+'<p class="muted">“打开”= 这台设备当天打开过自主学；“真正学习”= 学完课文一段、做完一组复习或测验。同一台设备只算 1 人（换手机 / 换浏览器 / 清数据会算新的一台）。</p></div>'
+(s.ai?aiHtml(s.ai):'')+'<div class="card"><h2>转化</h2><table>'+s.funnel.map(f=>'<tr><td>'+esc(f.step)+'</td><td class="n">'+f.devices+'</td><td class="n muted">'+(s.funnel[0].devices?Math.round(100*f.devices/s.funnel[0].devices):0)+'%</td></tr>').join('')+'</table></div>'
+'<div class="card"><h2>最近 30 天每天</h2><div class="scroll"><table id="daily"><tr><th>日期</th><th class="n">打开</th><th class="n">真正学习</th><th class="n">导入</th><th class="n">新设备</th><th style="min-width:110px"></th></tr>'+s.daily.slice().reverse().map(d=>'<tr><td>'+d.day.slice(5)+'</td><td class="n">'+d.active+'</td><td class="n">'+d.learners+'</td><td class="n">'+d.importers+'</td><td class="n">'+d.newDevices+'</td><td><div class="bar" style="width:'+(100*d.active/mx)+'%"></div><div class="bar l" style="width:'+(100*d.learners/mx)+'%;margin-top:2px"></div></td></tr>').join('')+'</table></div><p class="muted">绿条 = 打开，橙条 = 真正学习</p></div>'
+'<div class="two"><div class="card" id="src"><h2>从哪来（第一次打开时）</h2>'+dist(s.sources,'name','来源')+(s.referrerDomains.length?'<p class="muted">其他网站：'+s.referrerDomains.map(d=>esc(d.domain)+' '+d.devices).join('，')+'</p>':'')+'</div>'
+'<div class="card"><h2>设备类型</h2>'+dist(s.platforms,'name','平台')+'<h2 style="margin-top:14px">版本（近 30 天用过的）</h2>'+dist(s.versions,'version','版本')+'</div></div>'
+'<div class="two"><div class="card"><h2>云同步 / 激活码</h2><table><tr><td>同步账户</td><td class="n">'+s.sync.accounts+'</td></tr><tr><td>同步设备</td><td class="n">'+s.sync.devices+'</td></tr><tr><td>同步记录</td><td class="n">'+s.sync.records+'</td></tr><tr><td>学习提醒订阅</td><td class="n">'+s.sync.pushSubs+'</td></tr><tr><td>已激活的激活码</td><td class="n">'+s.license.codesActivated+'</td></tr><tr><td>作废的激活码</td><td class="n">'+s.license.codesRevoked+'</td></tr><tr><td>有效订阅</td><td class="n">'+s.license.subscriptionsActive+'</td></tr><tr><td>试用对过账的设备</td><td class="n">'+s.license.trialDevices+'</td></tr></table><p class="muted">只统计绑定了云同步的用户；没绑定的激活码在本机离线验证，服务器看不到。</p></div>'
+'<div class="card"><h2>近 30 天事件数</h2><table>'+Object.entries(s.events30).map(([k,v])=>'<tr><td>'+esc({open:'打开',import:'导入材料',study:'学课文',quiz:'测验',review:'复习',share:'生成分享卡片',ai_own_ok:'自己密钥调用 AI 成功',ai_own_fail:'自己密钥调用 AI 失败',ai_fallback:'内置 AI 改用免费翻译'}[k]||k)+'</td><td class="n">'+v+'</td></tr>').join('')+'</table></div></div>'
+'<div class="card" id="fbl"><h2>用户反馈（共 '+s.feedback.total+' 条，最新 30 条）</h2>'+(s.feedback.items.length?s.feedback.items.map(f=>'<div class="fb"><span class="tag">'+esc({bug:'问题',idea:'建议',other:'其他'}[f.type]||f.type)+'</span><span class="muted">'+new Date(f.created).toLocaleString('zh-CN',{hour12:false})+(f.contact?' · 联系：'+esc(f.contact):'')+'</span><div>'+esc(f.text)+'</div></div>').join(''):'<p class="muted">还没有反馈</p>')+'<p class="muted">截图等详情：GET /api/v1/feedback?id=编号（同一个口令）</p></div>';if(s.ai)bindAi(s.ai.settings);}
/* v1.9.4 内置 AI：统计 + 设置（密钥只在服务器上；这里只显示末 4 位） */
const AIAPI=new URL('../api/v1/admin/ai', location.href).href;
const usd=v=>'$'+(v>=1?v.toFixed(2):v>=0.01?v.toFixed(3):v.toFixed(4));
const pct=v=>Math.round(100*v)+'%';
function aiHtml(a){const S=a.settings,W=[['今天',a.today],['近 7 天',a.last7],['近 30 天',a.last30]],M=a.month,o=a.own.last30;
const st=S.ready?'<b class="ok">已开启</b>':!S.hasKey?'<b class="err">还没有密钥</b>':'<b class="err">已关闭</b>';
const t7={},t1={};a.last7.byTask.forEach(x=>t7[x.task]=x);a.today.byTask.forEach(x=>t1[x.task]=x);
return '<div class="card" id="aist"><h2>内置 AI 用量（花费为估算）</h2><p>状态：'+st+' · 模型 '+esc(S.model)+(S.hasKey?' · 密钥 '+esc(S.keyTail):'')+'</p><div class="nums">'
+num(a.today.ok+a.today.fail,'今天调用 AI（不含缓存）',1)+num(a.last7.ok+a.last7.fail,'近 7 天调用')+num(a.last30.ok+a.last30.fail,'近 30 天调用')
+num(pct(a.last30.hitRate),'缓存命中率（30 天）')+num(a.last30.refused+o.fallback,'改用免费翻译 / 被额度拦下（30 天）')+num(a.last30.fail,'失败次数（30 天）')
+num(a.today.users,'今天用内置 AI 的人')+num(a.last30.users,'近 30 天用内置 AI 的人')+num(usd(M.spend)+' / $'+M.budget,'本月估算花费 / 上限',M.budget&&M.spend>=M.budget*0.8)+num(Math.round((a.last30.pt+a.last30.ct)/1000)+'k','token（30 天，输入+输出）')+'</div>'
+'<div class="scroll"><table id="aiwin"><tr><th>时间</th><th class="n">调用</th><th class="n">缓存命中</th><th class="n">命中率</th><th class="n">失败</th><th class="n">额度 / 上限拦下</th><th class="n">人数</th><th class="n">输入 token</th><th class="n">输出 token</th><th class="n">估算花费</th></tr>'
+W.map(([l,w])=>'<tr><td>'+l+'</td><td class="n">'+(w.ok+w.fail)+'</td><td class="n">'+w.cache+'</td><td class="n">'+pct(w.hitRate)+'</td><td class="n">'+w.fail+'</td><td class="n">'+w.refused+'</td><td class="n">'+w.users+'</td><td class="n">'+w.pt+'</td><td class="n">'+w.ct+'</td><td class="n">'+usd(w.cost)+'</td></tr>').join('')+'</table></div>'
+'<h2 style="margin-top:14px">按功能</h2><div class="scroll"><table id="aitask"><tr><th>功能</th><th class="n">今天</th><th class="n">7 天</th><th class="n">30 天</th><th class="n">缓存（30 天）</th><th class="n">失败</th><th class="n">拦下</th><th class="n">估算花费（30 天）</th></tr>'
+(a.last30.byTask.length?a.last30.byTask.map(x=>'<tr><td>'+esc(x.name)+'</td><td class="n">'+((t1[x.task]||{}).ok||0)+'</td><td class="n">'+((t7[x.task]||{}).ok||0)+'</td><td class="n">'+x.ok+'</td><td class="n">'+x.cache+'</td><td class="n">'+x.fail+'</td><td class="n">'+(x.quota+x.budget)+'</td><td class="n">'+usd(x.cost)+'</td></tr>').join(''):'<tr><td colspan="8" class="muted">还没有调用</td></tr>')+'</table></div>'
+'<div class="two"><div><h2 style="margin-top:14px">失败原因（30 天）</h2><table id="aierr">'+(a.errors.length?a.errors.map(e=>'<tr><td><span class="tag">'+esc(e.code)+'</span>'+esc(e.msg)+'</td><td class="n">'+e.n+'</td></tr>').join(''):'<tr><td class="muted">没有失败</td></tr>')+'</table></div>'
+'<div><h2 style="margin-top:14px">花费最多的 10 台匿名设备（30 天）</h2><table id="aitop"><tr><th>设备（匿名）</th><th class="n">调用</th><th class="n">缓存</th><th class="n">估算</th></tr>'+(a.topDevices.length?a.topDevices.map(d=>'<tr><td>'+esc(d.dev)+'</td><td class="n">'+d.calls+'</td><td class="n">'+d.cache+'</td><td class="n">'+usd(d.cost)+'</td></tr>').join(''):'<tr><td colspan="4" class="muted">还没有</td></tr>')+'</table></div></div>'
+'<p class="muted">自己填密钥的用户（不走服务器，只有次数、没有内容）：近 30 天成功 '+o.ok+' 次、失败 '+o.fail+' 次，'+o.users+' 人；网页里内置 AI 改用免费翻译 '+o.fallback+' 次（'+o.fallbackUsers+' 人）。'+esc(a.estimateNote)+' 价目表（美元 / 每 100 万 token，输入 / 输出）：'+S.models.map(x=>esc(x.model)+' '+x.input+'/'+x.output).join('，')+'；AI 语音约 $'+S.ttsPricePerMChars+' / 100 万字符。不认识的模型按 gpt-4o-mini 估算。</p></div>'
+'<div class="card" id="aiset"><h2>AI 设置</h2><p class="muted">普通用户不用填任何密钥，打开即用这里的 AI。密钥只存在服务器上（数据库旁边的 ai-key 文件，权限 0600），不会发给网页，这里也只显示末 4 位。</p>'
+'<p>当前密钥：<b id="aitail">'+(S.hasKey?esc(S.keyTail)+'（'+(S.keySource==='env'?'来自 .env 的 AI_API_KEY':'看板里保存的')+'）':'没有')+'</b></p>'
+'<label class="chk"><input type="checkbox" id="aien"'+(S.enabled?' checked':'')+'> 开启内置 AI（总开关）</label>'
+'<div class="grid2"><div style="grid-column:1/-1"><label for="aik">粘贴新密钥（留空 = 不改）</label><input id="aik" type="password" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="sk-…"></div>'
+'<div><label for="aimodel">模型</label><select id="aimodel">'+S.models.map(x=>'<option'+(x.model===S.model?' selected':'')+'>'+esc(x.model)+'</option>').join('')+'<option value="__c"'+(S.models.some(x=>x.model===S.model)?'':' selected')+'>自定义…</option></select></div>'
+'<div><label for="aimc">自定义模型名</label><input id="aimc" value="'+(S.models.some(x=>x.model===S.model)?'':esc(S.model))+'" autocapitalize="off" placeholder="如 gpt-4.1-mini"></div>'
+'<div style="grid-column:1/-1"><label for="aibase">接口地址（兼容 OpenAI）</label><input id="aibase" value="'+esc(S.baseUrl)+'" autocapitalize="off" inputmode="url"></div>'
+[['deviceDaily','每台设备每天次数'],['deviceMonthly','每台设备每月次数'],['ttsDaily','每台设备每天语音段数'],['ipDaily','每个 IP 每天次数'],['monthlyBudgetUsd','全站每月花费上限（美元）'],['maxInputChars','单次输入上限（字符）']].map(([k,l])=>'<div><label for="ai_'+k+'">'+l+'</label><input id="ai_'+k+'" inputmode="decimal" value="'+S.limits[k]+'"></div>').join('')
+'</div><p class="muted">0 = 不限。默认：每台设备每天 '+S.defaults.deviceDaily+' 次、每月 '+S.defaults.deviceMonthly+' 次、语音每天 '+S.defaults.ttsDaily+' 段、每个 IP 每天 '+S.defaults.ipDaily+' 次、每月上限 $'+S.defaults.monthlyBudgetUsd+'。缓存命中不算次数。超额或上限到了：网页翻译自动改用免费翻译，其他功能提示原因。</p>'
+'<div class="btns"><button id="aisave">保存</button><button id="aitest" class="sec">测试连接</button><button id="aiclr" class="sec">清除密钥</button></div><p id="aimsg" role="status"></p></div>';}
function aiBody(){const b={enabled:document.getElementById('aien').checked,baseUrl:document.getElementById('aibase').value.trim()};const sel=document.getElementById('aimodel').value;b.model=sel==='__c'?document.getElementById('aimc').value.trim():sel;const k=document.getElementById('aik').value.trim();if(k)b.apiKey=k;
['deviceDaily','deviceMonthly','ttsDaily','ipDaily','monthlyBudgetUsd','maxInputChars'].forEach(x=>{b[x]=document.getElementById('ai_'+x).value.trim();});return b;}
async function aiPost(path,body){const r=await fetch(AIAPI+path,{method:'POST',headers:{Authorization:'Bearer '+localStorage.getItem(K),'Content-Type':'application/json'},body:JSON.stringify(body),cache:'no-store'});const j=await r.json().catch(()=>({}));if(r.status===401){localStorage.removeItem(K);login(j.error||'口令不对');throw new Error('');}if(!r.ok)throw new Error(j.error||('出错 '+r.status));return j;}
function bindAi(S){const msg=(t,c)=>{const e=document.getElementById('aimsg');e.className=c||'';e.textContent=t;};
document.getElementById('aimodel').onchange=e=>{if(e.target.value==='__c')document.getElementById('aimc').focus();};
document.getElementById('aisave').onclick=async()=>{msg('保存中…');try{const j=await aiPost('',aiBody());document.getElementById('aik').value='';document.getElementById('aitail').textContent=j.hasKey?j.keyTail+'（'+(j.keySource==='env'?'来自 .env 的 AI_API_KEY':'看板里保存的')+'）':'没有';msg('✓ 已保存。'+(j.ready?'内置 AI 已开启（模型 '+j.model+'）。建议点「测试连接」确认。':j.hasKey?'内置 AI 现在是关闭的。':'还没有密钥，内置 AI 不会开启。'),'ok');}catch(e){if(e.message)msg('✗ '+e.message,'err');}};
document.getElementById('aitest').onclick=async()=>{msg('测试中…（会发 2 个很短的请求）');const b=aiBody();try{const j=await aiPost('/test',{apiKey:b.apiKey,model:b.model,baseUrl:b.baseUrl});msg(j.ok?'✓ 连接成功：模型 '+j.model+'，密钥 '+j.keyTail+'，试译 “Good morning.” → '+j.sample+(b.apiKey?'（新密钥还没保存，记得点「保存」）':''):'✗ 连接失败：'+j.reason,j.ok?'ok':'err');}catch(e){if(e.message)msg('✗ '+e.message,'err');}};
document.getElementById('aiclr').onclick=async()=>{if(!confirm('清除看板里保存的 AI 密钥？（.env 里的 AI_API_KEY 不受影响）'))return;try{const j=await aiPost('',{clearKey:true});document.getElementById('aitail').textContent=j.hasKey?j.keyTail+'（来自 .env 的 AI_API_KEY）':'没有';msg('已清除看板里保存的密钥。'+(j.hasKey?'现在用 .env 里的密钥。':'内置 AI 已停用。'),'ok');}catch(e){if(e.message)msg('✗ '+e.message,'err');}};}
document.getElementById('re').onclick=load;document.getElementById('out').onclick=()=>{if(!confirm('忘记这台设备上保存的管理口令？下次打开要重新输入。'))return;localStorage.removeItem(K);login('已忘记口令');};load();
</script></body></html>`;

/** v1.9.3 看板可加到手机主屏（PWA）：manifest 和图标不需要口令 */
export const DASHBOARD_MANIFEST = JSON.stringify({
  name: '自主学看板', short_name: '自主学看板', description: '自主学使用统计与用户反馈（管理用）', lang: 'zh-CN',
  id: '/admin/stats', start_url: '/admin/stats', scope: '/admin/', display: 'standalone', background_color: '#f4f1ea', theme_color: '#1f6f5c',
  icons: [{ src: '/admin/icon-192.png', sizes: '192x192', type: 'image/png', purpose: 'any' }, { src: '/admin/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any' }],
});
